﻿namespace Toolbox
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form8));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.bRedefinirSenha = new System.Windows.Forms.Button();
            this.bALterarMeusDados = new System.Windows.Forms.Button();
            this.bMeusDados = new System.Windows.Forms.Button();
            this.bConfiguracao = new System.Windows.Forms.Button();
            this.bRetirarPagamento = new System.Windows.Forms.Button();
            this.bpedidos = new System.Windows.Forms.Button();
            this.bOrcamento = new System.Windows.Forms.Button();
            this.bCadastrarServico = new System.Windows.Forms.Button();
            this.bServicos = new System.Windows.Forms.Button();
            this.bHome = new System.Windows.Forms.Button();
            this.bSair = new System.Windows.Forms.Button();
            this.panelBemVindo = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.pictureBoxWelcome = new System.Windows.Forms.PictureBox();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelAprovar = new System.Windows.Forms.Panel();
            this.bsalvarAprovação = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxDuracao = new System.Windows.Forms.TextBox();
            this.textBoxPreco = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.bGerarPDF = new System.Windows.Forms.Button();
            this.bAjuda = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBoxPesquisar = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.bPesquisar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewORcamentos = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column33 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column34 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelOrçamento = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.panelServico = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.panelCliente = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.bCod = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panelSideMenu.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelBemVindo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).BeginInit();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelAprovar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewORcamentos)).BeginInit();
            this.panel2.SuspendLayout();
            this.panelOrçamento.SuspendLayout();
            this.panelServico.SuspendLayout();
            this.panelCliente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.BackColor = System.Drawing.Color.White;
            this.panelSideMenu.Controls.Add(this.panelButtons);
            this.panelSideMenu.Controls.Add(this.bSair);
            this.panelSideMenu.Controls.Add(this.panelBemVindo);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(280, 900);
            this.panelSideMenu.TabIndex = 4;
            // 
            // panelButtons
            // 
            this.panelButtons.BackColor = System.Drawing.Color.White;
            this.panelButtons.Controls.Add(this.bRedefinirSenha);
            this.panelButtons.Controls.Add(this.bALterarMeusDados);
            this.panelButtons.Controls.Add(this.bMeusDados);
            this.panelButtons.Controls.Add(this.bConfiguracao);
            this.panelButtons.Controls.Add(this.bRetirarPagamento);
            this.panelButtons.Controls.Add(this.bpedidos);
            this.panelButtons.Controls.Add(this.bOrcamento);
            this.panelButtons.Controls.Add(this.bCadastrarServico);
            this.panelButtons.Controls.Add(this.bServicos);
            this.panelButtons.Controls.Add(this.bHome);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButtons.Location = new System.Drawing.Point(0, 151);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(280, 720);
            this.panelButtons.TabIndex = 13;
            // 
            // bRedefinirSenha
            // 
            this.bRedefinirSenha.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRedefinirSenha.FlatAppearance.BorderSize = 0;
            this.bRedefinirSenha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRedefinirSenha.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRedefinirSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRedefinirSenha.Image = ((System.Drawing.Image)(resources.GetObject("bRedefinirSenha.Image")));
            this.bRedefinirSenha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRedefinirSenha.Location = new System.Drawing.Point(0, 360);
            this.bRedefinirSenha.Name = "bRedefinirSenha";
            this.bRedefinirSenha.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bRedefinirSenha.Size = new System.Drawing.Size(280, 40);
            this.bRedefinirSenha.TabIndex = 10;
            this.bRedefinirSenha.Text = "  redefinir senha";
            this.bRedefinirSenha.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRedefinirSenha.UseVisualStyleBackColor = true;
            this.bRedefinirSenha.Click += new System.EventHandler(this.bRedefinirSenha_Click);
            // 
            // bALterarMeusDados
            // 
            this.bALterarMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bALterarMeusDados.FlatAppearance.BorderSize = 0;
            this.bALterarMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bALterarMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bALterarMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bALterarMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bALterarMeusDados.Image")));
            this.bALterarMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bALterarMeusDados.Location = new System.Drawing.Point(0, 320);
            this.bALterarMeusDados.Name = "bALterarMeusDados";
            this.bALterarMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bALterarMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bALterarMeusDados.TabIndex = 6;
            this.bALterarMeusDados.Text = "  alterar meus dados";
            this.bALterarMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bALterarMeusDados.UseVisualStyleBackColor = true;
            this.bALterarMeusDados.Click += new System.EventHandler(this.bALterarMeusDados_Click);
            // 
            // bMeusDados
            // 
            this.bMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bMeusDados.FlatAppearance.BorderSize = 0;
            this.bMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bMeusDados.Image")));
            this.bMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bMeusDados.Location = new System.Drawing.Point(0, 280);
            this.bMeusDados.Name = "bMeusDados";
            this.bMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bMeusDados.TabIndex = 9;
            this.bMeusDados.Text = "  meus dados";
            this.bMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bMeusDados.UseVisualStyleBackColor = true;
            this.bMeusDados.Click += new System.EventHandler(this.bMeusDados_Click);
            // 
            // bConfiguracao
            // 
            this.bConfiguracao.Dock = System.Windows.Forms.DockStyle.Top;
            this.bConfiguracao.FlatAppearance.BorderSize = 0;
            this.bConfiguracao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bConfiguracao.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bConfiguracao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bConfiguracao.Image = ((System.Drawing.Image)(resources.GetObject("bConfiguracao.Image")));
            this.bConfiguracao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bConfiguracao.Location = new System.Drawing.Point(0, 240);
            this.bConfiguracao.Name = "bConfiguracao";
            this.bConfiguracao.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bConfiguracao.Size = new System.Drawing.Size(280, 40);
            this.bConfiguracao.TabIndex = 3;
            this.bConfiguracao.Text = "  configurações";
            this.bConfiguracao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bConfiguracao.UseVisualStyleBackColor = true;
            this.bConfiguracao.Click += new System.EventHandler(this.bConfiguracao_Click);
            // 
            // bRetirarPagamento
            // 
            this.bRetirarPagamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRetirarPagamento.FlatAppearance.BorderSize = 0;
            this.bRetirarPagamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRetirarPagamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRetirarPagamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRetirarPagamento.Image = ((System.Drawing.Image)(resources.GetObject("bRetirarPagamento.Image")));
            this.bRetirarPagamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRetirarPagamento.Location = new System.Drawing.Point(0, 200);
            this.bRetirarPagamento.Name = "bRetirarPagamento";
            this.bRetirarPagamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bRetirarPagamento.Size = new System.Drawing.Size(280, 40);
            this.bRetirarPagamento.TabIndex = 8;
            this.bRetirarPagamento.Text = "  retirar pagamento";
            this.bRetirarPagamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRetirarPagamento.UseVisualStyleBackColor = true;
            this.bRetirarPagamento.Click += new System.EventHandler(this.bRetirarPagamento_Click);
            // 
            // bpedidos
            // 
            this.bpedidos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bpedidos.FlatAppearance.BorderSize = 0;
            this.bpedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bpedidos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bpedidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bpedidos.Image = ((System.Drawing.Image)(resources.GetObject("bpedidos.Image")));
            this.bpedidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bpedidos.Location = new System.Drawing.Point(0, 160);
            this.bpedidos.Name = "bpedidos";
            this.bpedidos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bpedidos.Size = new System.Drawing.Size(280, 40);
            this.bpedidos.TabIndex = 5;
            this.bpedidos.Text = "  pedidos";
            this.bpedidos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bpedidos.UseVisualStyleBackColor = true;
            this.bpedidos.Click += new System.EventHandler(this.bpedidos_Click);
            // 
            // bOrcamento
            // 
            this.bOrcamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bOrcamento.FlatAppearance.BorderSize = 0;
            this.bOrcamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOrcamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bOrcamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bOrcamento.Image = ((System.Drawing.Image)(resources.GetObject("bOrcamento.Image")));
            this.bOrcamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bOrcamento.Location = new System.Drawing.Point(0, 120);
            this.bOrcamento.Name = "bOrcamento";
            this.bOrcamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bOrcamento.Size = new System.Drawing.Size(280, 40);
            this.bOrcamento.TabIndex = 4;
            this.bOrcamento.Text = "  orçamentos";
            this.bOrcamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bOrcamento.UseVisualStyleBackColor = true;
            this.bOrcamento.Click += new System.EventHandler(this.bOrcamento_Click);
            // 
            // bCadastrarServico
            // 
            this.bCadastrarServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bCadastrarServico.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bCadastrarServico.Image = ((System.Drawing.Image)(resources.GetObject("bCadastrarServico.Image")));
            this.bCadastrarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCadastrarServico.Location = new System.Drawing.Point(0, 80);
            this.bCadastrarServico.Name = "bCadastrarServico";
            this.bCadastrarServico.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bCadastrarServico.Size = new System.Drawing.Size(280, 40);
            this.bCadastrarServico.TabIndex = 2;
            this.bCadastrarServico.Text = "  cadastrar serviço";
            this.bCadastrarServico.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bCadastrarServico.UseVisualStyleBackColor = true;
            this.bCadastrarServico.Click += new System.EventHandler(this.bCadastrarServico_Click);
            // 
            // bServicos
            // 
            this.bServicos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bServicos.FlatAppearance.BorderSize = 0;
            this.bServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bServicos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bServicos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bServicos.Image = ((System.Drawing.Image)(resources.GetObject("bServicos.Image")));
            this.bServicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bServicos.Location = new System.Drawing.Point(0, 40);
            this.bServicos.Name = "bServicos";
            this.bServicos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bServicos.Size = new System.Drawing.Size(280, 40);
            this.bServicos.TabIndex = 7;
            this.bServicos.Text = "  serviços";
            this.bServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bServicos.UseVisualStyleBackColor = true;
            this.bServicos.Click += new System.EventHandler(this.bServicos_Click);
            // 
            // bHome
            // 
            this.bHome.BackColor = System.Drawing.Color.Transparent;
            this.bHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.bHome.FlatAppearance.BorderSize = 0;
            this.bHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bHome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bHome.Image = ((System.Drawing.Image)(resources.GetObject("bHome.Image")));
            this.bHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.Location = new System.Drawing.Point(0, 0);
            this.bHome.Name = "bHome";
            this.bHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bHome.Size = new System.Drawing.Size(280, 40);
            this.bHome.TabIndex = 1;
            this.bHome.Text = "  home";
            this.bHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bHome.UseVisualStyleBackColor = false;
            this.bHome.Click += new System.EventHandler(this.bHome_Click);
            // 
            // bSair
            // 
            this.bSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bSair.Location = new System.Drawing.Point(0, 871);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(280, 29);
            this.bSair.TabIndex = 6;
            this.bSair.Text = "sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bSair.UseVisualStyleBackColor = true;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // panelBemVindo
            // 
            this.panelBemVindo.Controls.Add(this.labelWelcome);
            this.panelBemVindo.Controls.Add(this.pictureBoxWelcome);
            this.panelBemVindo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBemVindo.Location = new System.Drawing.Point(0, 86);
            this.panelBemVindo.Name = "panelBemVindo";
            this.panelBemVindo.Size = new System.Drawing.Size(280, 65);
            this.panelBemVindo.TabIndex = 1;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.labelWelcome.Location = new System.Drawing.Point(59, 24);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(105, 25);
            this.labelWelcome.TabIndex = 1;
            this.labelWelcome.Text = "bem vindo,";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxWelcome
            // 
            this.pictureBoxWelcome.Location = new System.Drawing.Point(21, 15);
            this.pictureBoxWelcome.Name = "pictureBoxWelcome";
            this.pictureBoxWelcome.Size = new System.Drawing.Size(34, 34);
            this.pictureBoxWelcome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxWelcome.TabIndex = 0;
            this.pictureBoxWelcome.TabStop = false;
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelLogo.Controls.Add(this.pictureBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.panelLogo.Size = new System.Drawing.Size(280, 86);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogo.ErrorImage = null;
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.InitialImage = null;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 5);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(280, 86);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(247)))), ((int)(((byte)(251)))));
            this.panel1.Controls.Add(this.panelAprovar);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.bGerarPDF);
            this.panel1.Controls.Add(this.bAjuda);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.textBoxPesquisar);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.bPesquisar);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(280, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1621, 198);
            this.panel1.TabIndex = 8;
            // 
            // panelAprovar
            // 
            this.panelAprovar.Controls.Add(this.bsalvarAprovação);
            this.panelAprovar.Controls.Add(this.label5);
            this.panelAprovar.Controls.Add(this.textBoxDuracao);
            this.panelAprovar.Controls.Add(this.textBoxPreco);
            this.panelAprovar.Controls.Add(this.label1);
            this.panelAprovar.Controls.Add(this.monthCalendar1);
            this.panelAprovar.Controls.Add(this.label4);
            this.panelAprovar.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelAprovar.Location = new System.Drawing.Point(834, 0);
            this.panelAprovar.Name = "panelAprovar";
            this.panelAprovar.Size = new System.Drawing.Size(787, 198);
            this.panelAprovar.TabIndex = 130;
            // 
            // bsalvarAprovação
            // 
            this.bsalvarAprovação.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bsalvarAprovação.FlatAppearance.BorderSize = 0;
            this.bsalvarAprovação.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bsalvarAprovação.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bsalvarAprovação.ForeColor = System.Drawing.Color.White;
            this.bsalvarAprovação.Location = new System.Drawing.Point(256, 151);
            this.bsalvarAprovação.Name = "bsalvarAprovação";
            this.bsalvarAprovação.Size = new System.Drawing.Size(300, 40);
            this.bsalvarAprovação.TabIndex = 50;
            this.bsalvarAprovação.Text = "Enviar proposta";
            this.bsalvarAprovação.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bsalvarAprovação.UseVisualStyleBackColor = false;
            this.bsalvarAprovação.Click += new System.EventHandler(this.bsalvarAprovação_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(262, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 25);
            this.label5.TabIndex = 119;
            this.label5.Text = "duração em dias";
            // 
            // textBoxDuracao
            // 
            this.textBoxDuracao.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxDuracao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDuracao.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxDuracao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxDuracao.Location = new System.Drawing.Point(256, 39);
            this.textBoxDuracao.MaxLength = 4;
            this.textBoxDuracao.Name = "textBoxDuracao";
            this.textBoxDuracao.Size = new System.Drawing.Size(300, 32);
            this.textBoxDuracao.TabIndex = 112;
            this.textBoxDuracao.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxDuracao_KeyDown);
            // 
            // textBoxPreco
            // 
            this.textBoxPreco.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxPreco.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxPreco.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxPreco.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxPreco.Location = new System.Drawing.Point(256, 104);
            this.textBoxPreco.MaxLength = 4;
            this.textBoxPreco.Name = "textBoxPreco";
            this.textBoxPreco.Size = new System.Drawing.Size(300, 32);
            this.textBoxPreco.TabIndex = 118;
            this.textBoxPreco.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxPreco_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(24, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 25);
            this.label1.TabIndex = 113;
            this.label1.Text = "data da execução";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.BackColor = System.Drawing.SystemColors.Window;
            this.monthCalendar1.Location = new System.Drawing.Point(17, 27);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.ShowTodayCircle = false;
            this.monthCalendar1.TabIndex = 121;
            this.monthCalendar1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.monthCalendar1_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(259, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 25);
            this.label4.TabIndex = 117;
            this.label4.Text = "preço";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(434, 39);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(263, 32);
            this.button2.TabIndex = 129;
            this.button2.Text = "Orçamentos aprovados por mim";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(434, 88);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(263, 32);
            this.button3.TabIndex = 126;
            this.button3.Text = "Orçamentos rejeitados por mim";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // bGerarPDF
            // 
            this.bGerarPDF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bGerarPDF.FlatAppearance.BorderSize = 0;
            this.bGerarPDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bGerarPDF.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bGerarPDF.ForeColor = System.Drawing.Color.White;
            this.bGerarPDF.Location = new System.Drawing.Point(286, 130);
            this.bGerarPDF.Name = "bGerarPDF";
            this.bGerarPDF.Size = new System.Drawing.Size(124, 41);
            this.bGerarPDF.TabIndex = 124;
            this.bGerarPDF.Text = "Gerar PDF";
            this.bGerarPDF.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bGerarPDF.UseVisualStyleBackColor = false;
            // 
            // bAjuda
            // 
            this.bAjuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bAjuda.FlatAppearance.BorderSize = 0;
            this.bAjuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bAjuda.Font = new System.Drawing.Font("Segoe UI", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bAjuda.ForeColor = System.Drawing.Color.White;
            this.bAjuda.Location = new System.Drawing.Point(286, 77);
            this.bAjuda.Name = "bAjuda";
            this.bAjuda.Size = new System.Drawing.Size(124, 41);
            this.bAjuda.TabIndex = 49;
            this.bAjuda.Text = "Ajuda";
            this.bAjuda.UseVisualStyleBackColor = false;
            this.bAjuda.Click += new System.EventHandler(this.bAjuda_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(21, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 25);
            this.label6.TabIndex = 123;
            this.label6.Text = "Ordenar PDF por:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "preço crescente",
            "preço decrescente",
            "data crescente",
            "data decrescente",
            "pagamento efetuado",
            "pedido em andamento",
            "pedido concluído"});
            this.comboBox1.Location = new System.Drawing.Point(26, 138);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(254, 33);
            this.comboBox1.TabIndex = 122;
            // 
            // textBoxPesquisar
            // 
            this.textBoxPesquisar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxPesquisar.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.textBoxPesquisar.Location = new System.Drawing.Point(26, 39);
            this.textBoxPesquisar.Name = "textBoxPesquisar";
            this.textBoxPesquisar.Size = new System.Drawing.Size(308, 32);
            this.textBoxPesquisar.TabIndex = 46;
            this.textBoxPesquisar.TextChanged += new System.EventHandler(this.textBoxPesquisar_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(378, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 32);
            this.button1.TabIndex = 51;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bPesquisar
            // 
            this.bPesquisar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bPesquisar.Image = ((System.Drawing.Image)(resources.GetObject("bPesquisar.Image")));
            this.bPesquisar.Location = new System.Drawing.Point(340, 39);
            this.bPesquisar.Name = "bPesquisar";
            this.bPesquisar.Size = new System.Drawing.Size(32, 32);
            this.bPesquisar.TabIndex = 47;
            this.bPesquisar.UseVisualStyleBackColor = false;
            this.bPesquisar.Click += new System.EventHandler(this.bPesquisar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label2.Location = new System.Drawing.Point(21, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 25);
            this.label2.TabIndex = 48;
            this.label2.Text = "Pesquise";
            // 
            // dataGridViewORcamentos
            // 
            this.dataGridViewORcamentos.AllowUserToAddRows = false;
            this.dataGridViewORcamentos.AllowUserToDeleteRows = false;
            this.dataGridViewORcamentos.AllowUserToResizeColumns = false;
            this.dataGridViewORcamentos.AllowUserToResizeRows = false;
            this.dataGridViewORcamentos.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dataGridViewORcamentos.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewORcamentos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewORcamentos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewORcamentos.ColumnHeadersHeight = 43;
            this.dataGridViewORcamentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewORcamentos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column23,
            this.Column24,
            this.Column25,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column35,
            this.Column29,
            this.Column30,
            this.Column36,
            this.Column31,
            this.Column32,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column22,
            this.Column33,
            this.Column34});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewORcamentos.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewORcamentos.GridColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridViewORcamentos.Location = new System.Drawing.Point(26, 33);
            this.dataGridViewORcamentos.MultiSelect = false;
            this.dataGridViewORcamentos.Name = "dataGridViewORcamentos";
            this.dataGridViewORcamentos.ReadOnly = true;
            this.dataGridViewORcamentos.RowHeadersVisible = false;
            this.dataGridViewORcamentos.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewORcamentos.ShowEditingIcon = false;
            this.dataGridViewORcamentos.Size = new System.Drawing.Size(1603, 605);
            this.dataGridViewORcamentos.TabIndex = 52;
            this.dataGridViewORcamentos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewORcamentos_CellClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "idquote";
            this.Column1.HeaderText = "idquote";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Visible = false;
            // 
            // Column23
            // 
            this.Column23.DataPropertyName = "desperson";
            this.Column23.HeaderText = "Cliente";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            // 
            // Column24
            // 
            this.Column24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column24.DataPropertyName = "descity";
            this.Column24.HeaderText = "Cidade";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            this.Column24.Width = 74;
            // 
            // Column25
            // 
            this.Column25.DataPropertyName = "desneighborhood";
            this.Column25.HeaderText = "Bairro";
            this.Column25.Name = "Column25";
            this.Column25.ReadOnly = true;
            this.Column25.Visible = false;
            // 
            // Column26
            // 
            this.Column26.DataPropertyName = "desservice";
            this.Column26.HeaderText = "Serviço";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            // 
            // Column27
            // 
            this.Column27.DataPropertyName = "dtrequest";
            this.Column27.HeaderText = "Solicitação";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Width = 85;
            // 
            // Column28
            // 
            this.Column28.DataPropertyName = "userdemand";
            this.Column28.HeaderText = "Descrição";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.Width = 170;
            // 
            // Column35
            // 
            this.Column35.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column35.DataPropertyName = "idstatus";
            this.Column35.HeaderText = "Status";
            this.Column35.Name = "Column35";
            this.Column35.ReadOnly = true;
            this.Column35.Width = 71;
            // 
            // Column29
            // 
            this.Column29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column29.DataPropertyName = "duration";
            this.Column29.HeaderText = "Duração em dias";
            this.Column29.Name = "Column29";
            this.Column29.ReadOnly = true;
            this.Column29.Width = 101;
            // 
            // Column30
            // 
            this.Column30.DataPropertyName = "execution";
            this.Column30.HeaderText = "Execução";
            this.Column30.Name = "Column30";
            this.Column30.ReadOnly = true;
            this.Column30.Width = 90;
            // 
            // Column36
            // 
            this.Column36.DataPropertyName = "deadline";
            this.Column36.HeaderText = "Prazo";
            this.Column36.Name = "Column36";
            this.Column36.ReadOnly = true;
            this.Column36.Width = 90;
            // 
            // Column31
            // 
            this.Column31.DataPropertyName = "vlquote";
            this.Column31.HeaderText = "Preço";
            this.Column31.Name = "Column31";
            this.Column31.ReadOnly = true;
            // 
            // Column32
            // 
            this.Column32.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column32.DataPropertyName = "nrquote";
            this.Column32.HeaderText = "Nº Orçamento";
            this.Column32.Name = "Column32";
            this.Column32.ReadOnly = true;
            this.Column32.Width = 111;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "idperson";
            this.Column2.HeaderText = "idperson";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Visible = false;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "iduser";
            this.Column3.HeaderText = "iduser";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Visible = false;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "idservice";
            this.Column4.HeaderText = "idservice";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Visible = false;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "idprovider";
            this.Column5.HeaderText = "idprovider";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Visible = false;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "idaddress";
            this.Column6.HeaderText = "idaddress";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Visible = false;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "deszipcode";
            this.Column7.HeaderText = "deszipcode";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Visible = false;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "desaddress";
            this.Column8.HeaderText = "desaddress";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Visible = false;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "desnumber";
            this.Column9.HeaderText = "desnumber";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Visible = false;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "desstate";
            this.Column10.HeaderText = "desstate";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Visible = false;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "descountry";
            this.Column11.HeaderText = "descountry";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Visible = false;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "descomplement";
            this.Column12.HeaderText = "descomplement";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Visible = false;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "desserviceprovider";
            this.Column13.HeaderText = "desserviceprovider";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Visible = false;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "rating";
            this.Column14.HeaderText = "rating";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Visible = false;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "availabity";
            this.Column15.HeaderText = "availabity";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Visible = false;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "idcategory";
            this.Column16.HeaderText = "idcategory";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Visible = false;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "deslogin";
            this.Column17.HeaderText = "deslogin";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Visible = false;
            // 
            // Column18
            // 
            this.Column18.DataPropertyName = "despassword";
            this.Column18.HeaderText = "despassword";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.Visible = false;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "dtregister";
            this.Column19.HeaderText = "dtregister";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.Visible = false;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "imguser";
            this.Column20.HeaderText = "imaguser";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Visible = false;
            // 
            // Column21
            // 
            this.Column21.DataPropertyName = "descpf";
            this.Column21.HeaderText = "descpf";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.Visible = false;
            // 
            // Column22
            // 
            this.Column22.DataPropertyName = "nrphone";
            this.Column22.HeaderText = "nrphone";
            this.Column22.Name = "Column22";
            this.Column22.ReadOnly = true;
            this.Column22.Visible = false;
            // 
            // Column33
            // 
            this.Column33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Green;
            this.Column33.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column33.HeaderText = "";
            this.Column33.Name = "Column33";
            this.Column33.ReadOnly = true;
            this.Column33.Text = "Aprovar orçamento";
            this.Column33.UseColumnTextForButtonValue = true;
            this.Column33.Width = 5;
            // 
            // Column34
            // 
            this.Column34.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Column34.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column34.HeaderText = "";
            this.Column34.Name = "Column34";
            this.Column34.ReadOnly = true;
            this.Column34.Text = "Rejeitar Orçamento";
            this.Column34.UseColumnTextForButtonValue = true;
            this.Column34.Width = 5;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panelOrçamento);
            this.panel2.Controls.Add(this.panelServico);
            this.panel2.Controls.Add(this.panelCliente);
            this.panel2.Controls.Add(this.dataGridViewORcamentos);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(280, 198);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1621, 702);
            this.panel2.TabIndex = 53;
            // 
            // panelOrçamento
            // 
            this.panelOrçamento.BackColor = System.Drawing.Color.White;
            this.panelOrçamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOrçamento.Controls.Add(this.label20);
            this.panelOrçamento.Controls.Add(this.label14);
            this.panelOrçamento.Controls.Add(this.textBox4);
            this.panelOrçamento.Controls.Add(this.textBox5);
            this.panelOrçamento.Controls.Add(this.label15);
            this.panelOrçamento.Controls.Add(this.label16);
            this.panelOrçamento.Controls.Add(this.label18);
            this.panelOrçamento.Controls.Add(this.button7);
            this.panelOrçamento.Controls.Add(this.label19);
            this.panelOrçamento.Location = new System.Drawing.Point(909, 298);
            this.panelOrçamento.Name = "panelOrçamento";
            this.panelOrçamento.Size = new System.Drawing.Size(427, 401);
            this.panelOrçamento.TabIndex = 131;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(35, 297);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(81, 28);
            this.label20.TabIndex = 131;
            this.label20.Text = "vlquote";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label14.Location = new System.Drawing.Point(37, 68);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(120, 17);
            this.label14.TabIndex = 130;
            this.label14.Text = "status + desservice";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.textBox4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox4.Location = new System.Drawing.Point(40, 87);
            this.textBox4.MaxLength = 512;
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(345, 69);
            this.textBox4.TabIndex = 129;
            this.textBox4.TabStop = false;
            this.textBox4.Text = "userdemand";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.textBox5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox5.Location = new System.Drawing.Point(40, 201);
            this.textBox5.MaxLength = 352;
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(345, 93);
            this.textBox5.TabIndex = 128;
            this.textBox5.TabStop = false;
            this.textBox5.Text = "solicitação\r\nprazo\r\nDuração\r\nexecução\r\n";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(35, 167);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 28);
            this.label15.TabIndex = 127;
            this.label15.Text = "Datas:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label16.Image = ((System.Drawing.Image)(resources.GetObject("label16.Image")));
            this.label16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label16.Location = new System.Drawing.Point(36, 328);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 21);
            this.label16.TabIndex = 122;
            this.label16.Text = "   ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label18.Location = new System.Drawing.Point(55, 329);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(167, 17);
            this.label18.TabIndex = 121;
            this.label18.Text = "Informações do orçamento";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button7.Location = new System.Drawing.Point(326, 339);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(59, 35);
            this.button7.TabIndex = 3;
            this.button7.Text = "ok";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(35, 40);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 28);
            this.label19.TabIndex = 8;
            this.label19.Text = "nrquote";
            // 
            // panelServico
            // 
            this.panelServico.BackColor = System.Drawing.Color.White;
            this.panelServico.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelServico.Controls.Add(this.textBox3);
            this.panelServico.Controls.Add(this.label13);
            this.panelServico.Controls.Add(this.textBox2);
            this.panelServico.Controls.Add(this.label7);
            this.panelServico.Controls.Add(this.label9);
            this.panelServico.Controls.Add(this.label10);
            this.panelServico.Controls.Add(this.button4);
            this.panelServico.Location = new System.Drawing.Point(476, 298);
            this.panelServico.Name = "panelServico";
            this.panelServico.Size = new System.Drawing.Size(427, 401);
            this.panelServico.TabIndex = 128;
            this.panelServico.Paint += new System.Windows.Forms.PaintEventHandler(this.panelServico_Paint);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold);
            this.textBox3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox3.Location = new System.Drawing.Point(40, 47);
            this.textBox3.MaxLength = 256;
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(345, 53);
            this.textBox3.TabIndex = 131;
            this.textBox3.TabStop = false;
            this.textBox3.Text = "desservice";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label13.Location = new System.Drawing.Point(37, 103);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 17);
            this.label13.TabIndex = 130;
            this.label13.Text = "dispo";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.textBox2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox2.Location = new System.Drawing.Point(40, 158);
            this.textBox2.MaxLength = 352;
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(345, 158);
            this.textBox2.TabIndex = 128;
            this.textBox2.TabStop = false;
            this.textBox2.Text = "desserviceprovider";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(35, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 28);
            this.label7.TabIndex = 127;
            this.label7.Text = "Descrição:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label9.Image = ((System.Drawing.Image)(resources.GetObject("label9.Image")));
            this.label9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label9.Location = new System.Drawing.Point(36, 319);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 21);
            this.label9.TabIndex = 122;
            this.label9.Text = "   ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label10.Location = new System.Drawing.Point(55, 320);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(145, 17);
            this.label10.TabIndex = 121;
            this.label10.Text = "Informações do serviço";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.Location = new System.Drawing.Point(326, 339);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(59, 35);
            this.button4.TabIndex = 3;
            this.button4.Text = "ok";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panelCliente
            // 
            this.panelCliente.BackColor = System.Drawing.Color.White;
            this.panelCliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCliente.Controls.Add(this.button6);
            this.panelCliente.Controls.Add(this.button5);
            this.panelCliente.Controls.Add(this.label3);
            this.panelCliente.Controls.Add(this.textBox1);
            this.panelCliente.Controls.Add(this.textBox6);
            this.panelCliente.Controls.Add(this.label17);
            this.panelCliente.Controls.Add(this.label12);
            this.panelCliente.Controls.Add(this.bCod);
            this.panelCliente.Controls.Add(this.label8);
            this.panelCliente.Controls.Add(this.pictureBox3);
            this.panelCliente.Location = new System.Drawing.Point(43, 298);
            this.panelCliente.Name = "panelCliente";
            this.panelCliente.Size = new System.Drawing.Size(427, 401);
            this.panelCliente.TabIndex = 53;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(230, 340);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(42, 35);
            this.button6.TabIndex = 129;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(278, 340);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(42, 35);
            this.button5.TabIndex = 128;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 28);
            this.label3.TabIndex = 127;
            this.label3.Text = "Endereço:";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.textBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox1.Location = new System.Drawing.Point(136, 72);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(249, 59);
            this.textBox1.TabIndex = 126;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "cpf\r\nnumero\r\nemail";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.textBox6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox6.Location = new System.Drawing.Point(40, 175);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(345, 158);
            this.textBox6.TabIndex = 125;
            this.textBox6.TabStop = false;
            this.textBox6.Text = "Brasil  - CEP\r\ncidade - estado\r\nrua  \r\nbairro\r\nnumero\r\ncomplemento";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label17.Image = ((System.Drawing.Image)(resources.GetObject("label17.Image")));
            this.label17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label17.Location = new System.Drawing.Point(36, 339);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(22, 21);
            this.label17.TabIndex = 122;
            this.label17.Text = "   ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label12.Location = new System.Drawing.Point(55, 340);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 17);
            this.label12.TabIndex = 121;
            this.label12.Text = "Informações do cliente";
            // 
            // bCod
            // 
            this.bCod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bCod.FlatAppearance.BorderSize = 0;
            this.bCod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCod.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCod.ForeColor = System.Drawing.Color.White;
            this.bCod.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bCod.Location = new System.Drawing.Point(326, 339);
            this.bCod.Name = "bCod";
            this.bCod.Size = new System.Drawing.Size(59, 35);
            this.bCod.TabIndex = 3;
            this.bCod.Text = "ok";
            this.bCod.UseVisualStyleBackColor = false;
            this.bCod.Click += new System.EventHandler(this.bCod_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(136, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 28);
            this.label8.TabIndex = 8;
            this.label8.Text = "desperson";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3.ErrorImage = null;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(40, 45);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(90, 86);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1901, 900);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelSideMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form8";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form8_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelButtons.ResumeLayout(false);
            this.panelBemVindo.ResumeLayout(false);
            this.panelBemVindo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).EndInit();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelAprovar.ResumeLayout(false);
            this.panelAprovar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewORcamentos)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panelOrçamento.ResumeLayout(false);
            this.panelOrçamento.PerformLayout();
            this.panelServico.ResumeLayout(false);
            this.panelServico.PerformLayout();
            this.panelCliente.ResumeLayout(false);
            this.panelCliente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Panel panelBemVindo;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.PictureBox pictureBoxWelcome;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button bRedefinirSenha;
        private System.Windows.Forms.Button bALterarMeusDados;
        private System.Windows.Forms.Button bMeusDados;
        private System.Windows.Forms.Button bConfiguracao;
        private System.Windows.Forms.Button bRetirarPagamento;
        private System.Windows.Forms.Button bpedidos;
        private System.Windows.Forms.Button bOrcamento;
        private System.Windows.Forms.Button bCadastrarServico;
        private System.Windows.Forms.Button bServicos;
        private System.Windows.Forms.Button bHome;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bAjuda;
        private System.Windows.Forms.Button bsalvarAprovação;
        private System.Windows.Forms.TextBox textBoxPesquisar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bPesquisar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridViewORcamentos;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxPreco;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxDuracao;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bGerarPDF;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column35;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column36;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewButtonColumn Column33;
        private System.Windows.Forms.DataGridViewButtonColumn Column34;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panelAprovar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelCliente;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button bCod;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panelServico;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panelOrçamento;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox3;
    }
}
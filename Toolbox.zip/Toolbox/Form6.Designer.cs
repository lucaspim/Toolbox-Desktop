﻿namespace Toolbox
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.bRedefinirSenha = new System.Windows.Forms.Button();
            this.bALterarMeusDados = new System.Windows.Forms.Button();
            this.bMeusDados = new System.Windows.Forms.Button();
            this.bConfiguracao = new System.Windows.Forms.Button();
            this.bRetirarPagamento = new System.Windows.Forms.Button();
            this.bpedidos = new System.Windows.Forms.Button();
            this.bOrcamento = new System.Windows.Forms.Button();
            this.bCadastrarServico = new System.Windows.Forms.Button();
            this.bServicos = new System.Windows.Forms.Button();
            this.bHome = new System.Windows.Forms.Button();
            this.bSair = new System.Windows.Forms.Button();
            this.panelBemVindo = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.pictureBoxWelcome = new System.Windows.Forms.PictureBox();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridViewServicos = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.bCadastrarServico2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.bPesquisar = new System.Windows.Forms.Button();
            this.textBoxPesquisar = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.bGerarPDF = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.bAjuda = new System.Windows.Forms.Button();
            this.panelSideMenu.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelBemVindo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).BeginInit();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServicos)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.BackColor = System.Drawing.Color.White;
            this.panelSideMenu.Controls.Add(this.panelButtons);
            this.panelSideMenu.Controls.Add(this.bSair);
            this.panelSideMenu.Controls.Add(this.panelBemVindo);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(280, 720);
            this.panelSideMenu.TabIndex = 3;
            // 
            // panelButtons
            // 
            this.panelButtons.BackColor = System.Drawing.Color.White;
            this.panelButtons.Controls.Add(this.bRedefinirSenha);
            this.panelButtons.Controls.Add(this.bALterarMeusDados);
            this.panelButtons.Controls.Add(this.bMeusDados);
            this.panelButtons.Controls.Add(this.bConfiguracao);
            this.panelButtons.Controls.Add(this.bRetirarPagamento);
            this.panelButtons.Controls.Add(this.bpedidos);
            this.panelButtons.Controls.Add(this.bOrcamento);
            this.panelButtons.Controls.Add(this.bCadastrarServico);
            this.panelButtons.Controls.Add(this.bServicos);
            this.panelButtons.Controls.Add(this.bHome);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButtons.Location = new System.Drawing.Point(0, 151);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(280, 540);
            this.panelButtons.TabIndex = 13;
            // 
            // bRedefinirSenha
            // 
            this.bRedefinirSenha.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRedefinirSenha.FlatAppearance.BorderSize = 0;
            this.bRedefinirSenha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRedefinirSenha.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRedefinirSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRedefinirSenha.Image = ((System.Drawing.Image)(resources.GetObject("bRedefinirSenha.Image")));
            this.bRedefinirSenha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRedefinirSenha.Location = new System.Drawing.Point(0, 360);
            this.bRedefinirSenha.Name = "bRedefinirSenha";
            this.bRedefinirSenha.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bRedefinirSenha.Size = new System.Drawing.Size(280, 40);
            this.bRedefinirSenha.TabIndex = 10;
            this.bRedefinirSenha.Text = "  redefinir senha";
            this.bRedefinirSenha.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRedefinirSenha.UseVisualStyleBackColor = true;
            this.bRedefinirSenha.Click += new System.EventHandler(this.bRedefinirSenha_Click);
            // 
            // bALterarMeusDados
            // 
            this.bALterarMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bALterarMeusDados.FlatAppearance.BorderSize = 0;
            this.bALterarMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bALterarMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bALterarMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bALterarMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bALterarMeusDados.Image")));
            this.bALterarMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bALterarMeusDados.Location = new System.Drawing.Point(0, 320);
            this.bALterarMeusDados.Name = "bALterarMeusDados";
            this.bALterarMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bALterarMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bALterarMeusDados.TabIndex = 6;
            this.bALterarMeusDados.Text = "  alterar meus dados";
            this.bALterarMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bALterarMeusDados.UseVisualStyleBackColor = true;
            this.bALterarMeusDados.Click += new System.EventHandler(this.bALterarMeusDados_Click);
            // 
            // bMeusDados
            // 
            this.bMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bMeusDados.FlatAppearance.BorderSize = 0;
            this.bMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bMeusDados.Image")));
            this.bMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bMeusDados.Location = new System.Drawing.Point(0, 280);
            this.bMeusDados.Name = "bMeusDados";
            this.bMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bMeusDados.TabIndex = 9;
            this.bMeusDados.Text = "  meus dados";
            this.bMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bMeusDados.UseVisualStyleBackColor = true;
            this.bMeusDados.Click += new System.EventHandler(this.bMeusDados_Click);
            // 
            // bConfiguracao
            // 
            this.bConfiguracao.Dock = System.Windows.Forms.DockStyle.Top;
            this.bConfiguracao.FlatAppearance.BorderSize = 0;
            this.bConfiguracao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bConfiguracao.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bConfiguracao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bConfiguracao.Image = ((System.Drawing.Image)(resources.GetObject("bConfiguracao.Image")));
            this.bConfiguracao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bConfiguracao.Location = new System.Drawing.Point(0, 240);
            this.bConfiguracao.Name = "bConfiguracao";
            this.bConfiguracao.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bConfiguracao.Size = new System.Drawing.Size(280, 40);
            this.bConfiguracao.TabIndex = 3;
            this.bConfiguracao.Text = "  configurações";
            this.bConfiguracao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bConfiguracao.UseVisualStyleBackColor = true;
            this.bConfiguracao.Click += new System.EventHandler(this.bConfiguracao_Click);
            // 
            // bRetirarPagamento
            // 
            this.bRetirarPagamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRetirarPagamento.FlatAppearance.BorderSize = 0;
            this.bRetirarPagamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRetirarPagamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRetirarPagamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRetirarPagamento.Image = ((System.Drawing.Image)(resources.GetObject("bRetirarPagamento.Image")));
            this.bRetirarPagamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRetirarPagamento.Location = new System.Drawing.Point(0, 200);
            this.bRetirarPagamento.Name = "bRetirarPagamento";
            this.bRetirarPagamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bRetirarPagamento.Size = new System.Drawing.Size(280, 40);
            this.bRetirarPagamento.TabIndex = 8;
            this.bRetirarPagamento.Text = "  retirar pagamento";
            this.bRetirarPagamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRetirarPagamento.UseVisualStyleBackColor = true;
            this.bRetirarPagamento.Click += new System.EventHandler(this.bRetirarPagamento_Click);
            // 
            // bpedidos
            // 
            this.bpedidos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bpedidos.FlatAppearance.BorderSize = 0;
            this.bpedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bpedidos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bpedidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bpedidos.Image = ((System.Drawing.Image)(resources.GetObject("bpedidos.Image")));
            this.bpedidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bpedidos.Location = new System.Drawing.Point(0, 160);
            this.bpedidos.Name = "bpedidos";
            this.bpedidos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bpedidos.Size = new System.Drawing.Size(280, 40);
            this.bpedidos.TabIndex = 5;
            this.bpedidos.Text = "  pedidos";
            this.bpedidos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bpedidos.UseVisualStyleBackColor = true;
            this.bpedidos.Click += new System.EventHandler(this.bpedidos_Click);
            // 
            // bOrcamento
            // 
            this.bOrcamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bOrcamento.FlatAppearance.BorderSize = 0;
            this.bOrcamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOrcamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bOrcamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bOrcamento.Image = ((System.Drawing.Image)(resources.GetObject("bOrcamento.Image")));
            this.bOrcamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bOrcamento.Location = new System.Drawing.Point(0, 120);
            this.bOrcamento.Name = "bOrcamento";
            this.bOrcamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bOrcamento.Size = new System.Drawing.Size(280, 40);
            this.bOrcamento.TabIndex = 4;
            this.bOrcamento.Text = "  orçamentos";
            this.bOrcamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bOrcamento.UseVisualStyleBackColor = true;
            this.bOrcamento.Click += new System.EventHandler(this.bOrcamento_Click);
            // 
            // bCadastrarServico
            // 
            this.bCadastrarServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bCadastrarServico.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bCadastrarServico.Image = ((System.Drawing.Image)(resources.GetObject("bCadastrarServico.Image")));
            this.bCadastrarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCadastrarServico.Location = new System.Drawing.Point(0, 80);
            this.bCadastrarServico.Name = "bCadastrarServico";
            this.bCadastrarServico.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bCadastrarServico.Size = new System.Drawing.Size(280, 40);
            this.bCadastrarServico.TabIndex = 2;
            this.bCadastrarServico.Text = "  cadastrar serviço";
            this.bCadastrarServico.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bCadastrarServico.UseVisualStyleBackColor = true;
            this.bCadastrarServico.Click += new System.EventHandler(this.bCadastrarServico_Click);
            // 
            // bServicos
            // 
            this.bServicos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bServicos.FlatAppearance.BorderSize = 0;
            this.bServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bServicos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bServicos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bServicos.Image = ((System.Drawing.Image)(resources.GetObject("bServicos.Image")));
            this.bServicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bServicos.Location = new System.Drawing.Point(0, 40);
            this.bServicos.Name = "bServicos";
            this.bServicos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bServicos.Size = new System.Drawing.Size(280, 40);
            this.bServicos.TabIndex = 7;
            this.bServicos.Text = "  serviços";
            this.bServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bServicos.UseVisualStyleBackColor = true;
            this.bServicos.Click += new System.EventHandler(this.bServicos_Click);
            // 
            // bHome
            // 
            this.bHome.BackColor = System.Drawing.Color.Transparent;
            this.bHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.bHome.FlatAppearance.BorderSize = 0;
            this.bHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bHome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bHome.Image = ((System.Drawing.Image)(resources.GetObject("bHome.Image")));
            this.bHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.Location = new System.Drawing.Point(0, 0);
            this.bHome.Name = "bHome";
            this.bHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bHome.Size = new System.Drawing.Size(280, 40);
            this.bHome.TabIndex = 1;
            this.bHome.Text = "  home";
            this.bHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bHome.UseVisualStyleBackColor = false;
            this.bHome.Click += new System.EventHandler(this.bHome_Click);
            // 
            // bSair
            // 
            this.bSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bSair.Location = new System.Drawing.Point(0, 691);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(280, 29);
            this.bSair.TabIndex = 6;
            this.bSair.Text = "sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bSair.UseVisualStyleBackColor = true;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // panelBemVindo
            // 
            this.panelBemVindo.Controls.Add(this.labelWelcome);
            this.panelBemVindo.Controls.Add(this.pictureBoxWelcome);
            this.panelBemVindo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBemVindo.Location = new System.Drawing.Point(0, 86);
            this.panelBemVindo.Name = "panelBemVindo";
            this.panelBemVindo.Size = new System.Drawing.Size(280, 65);
            this.panelBemVindo.TabIndex = 1;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.labelWelcome.Location = new System.Drawing.Point(59, 24);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(105, 25);
            this.labelWelcome.TabIndex = 1;
            this.labelWelcome.Text = "bem vindo,";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxWelcome
            // 
            this.pictureBoxWelcome.Location = new System.Drawing.Point(21, 15);
            this.pictureBoxWelcome.Name = "pictureBoxWelcome";
            this.pictureBoxWelcome.Size = new System.Drawing.Size(34, 34);
            this.pictureBoxWelcome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxWelcome.TabIndex = 0;
            this.pictureBoxWelcome.TabStop = false;
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelLogo.Controls.Add(this.pictureBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.panelLogo.Size = new System.Drawing.Size(280, 86);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogo.ErrorImage = null;
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.InitialImage = null;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 5);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(280, 86);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(280, 135);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1005, 585);
            this.panel2.TabIndex = 7;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.dataGridViewServicos);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1005, 585);
            this.panel3.TabIndex = 3;
            // 
            // dataGridViewServicos
            // 
            this.dataGridViewServicos.AllowUserToAddRows = false;
            this.dataGridViewServicos.AllowUserToDeleteRows = false;
            this.dataGridViewServicos.AllowUserToResizeColumns = false;
            this.dataGridViewServicos.AllowUserToResizeRows = false;
            this.dataGridViewServicos.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dataGridViewServicos.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewServicos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewServicos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewServicos.ColumnHeadersHeight = 34;
            this.dataGridViewServicos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewServicos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column1,
            this.Column6,
            this.Column3,
            this.Column2,
            this.Column4});
            this.dataGridViewServicos.GridColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridViewServicos.Location = new System.Drawing.Point(75, 56);
            this.dataGridViewServicos.MultiSelect = false;
            this.dataGridViewServicos.Name = "dataGridViewServicos";
            this.dataGridViewServicos.ReadOnly = true;
            this.dataGridViewServicos.RowHeadersVisible = false;
            this.dataGridViewServicos.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewServicos.ShowEditingIcon = false;
            this.dataGridViewServicos.Size = new System.Drawing.Size(795, 423);
            this.dataGridViewServicos.TabIndex = 0;
            this.dataGridViewServicos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewServicos_CellClick);
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "idservice";
            this.Column5.HeaderText = "#Serviço";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Visible = false;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "desservice";
            this.Column1.HeaderText = "Serviço";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 170;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "desserviceprovider";
            this.Column6.HeaderText = "Descrição";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 300;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "availabity";
            this.Column3.HeaderText = "Disponibilidade";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 130;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "rating";
            this.Column2.HeaderText = "Avaliação";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 90;
            // 
            // Column4
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Column4.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column4.HeaderText = "";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Text = "Deletar serviço";
            this.Column4.UseColumnTextForButtonValue = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(354, 42);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 32);
            this.button1.TabIndex = 44;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bCadastrarServico2
            // 
            this.bCadastrarServico2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bCadastrarServico2.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bCadastrarServico2.ForeColor = System.Drawing.Color.White;
            this.bCadastrarServico2.Location = new System.Drawing.Point(156, 80);
            this.bCadastrarServico2.Name = "bCadastrarServico2";
            this.bCadastrarServico2.Size = new System.Drawing.Size(230, 41);
            this.bCadastrarServico2.TabIndex = 43;
            this.bCadastrarServico2.Text = "Cadastrar serviço";
            this.bCadastrarServico2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bCadastrarServico2.UseVisualStyleBackColor = false;
            this.bCadastrarServico2.Click += new System.EventHandler(this.bCadastrarServico2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label2.Location = new System.Drawing.Point(38, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Pesquise";
            // 
            // bPesquisar
            // 
            this.bPesquisar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bPesquisar.Image = ((System.Drawing.Image)(resources.GetObject("bPesquisar.Image")));
            this.bPesquisar.Location = new System.Drawing.Point(316, 42);
            this.bPesquisar.Name = "bPesquisar";
            this.bPesquisar.Size = new System.Drawing.Size(32, 32);
            this.bPesquisar.TabIndex = 2;
            this.bPesquisar.UseVisualStyleBackColor = false;
            this.bPesquisar.Click += new System.EventHandler(this.bPesquisar_Click);
            // 
            // textBoxPesquisar
            // 
            this.textBoxPesquisar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxPesquisar.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.textBoxPesquisar.Location = new System.Drawing.Point(43, 42);
            this.textBoxPesquisar.Name = "textBoxPesquisar";
            this.textBoxPesquisar.Size = new System.Drawing.Size(267, 32);
            this.textBoxPesquisar.TabIndex = 1;
            this.textBoxPesquisar.TextChanged += new System.EventHandler(this.textBoxPesquisar_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(247)))), ((int)(((byte)(251)))));
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.bGerarPDF);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.bCadastrarServico2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.bAjuda);
            this.panel1.Controls.Add(this.textBoxPesquisar);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.bPesquisar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(280, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1005, 135);
            this.panel1.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(392, 80);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(230, 41);
            this.button2.TabIndex = 125;
            this.button2.Text = "Sugerir serviço";
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(733, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 25);
            this.label6.TabIndex = 124;
            this.label6.Text = "Ordenar PDF por:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bGerarPDF
            // 
            this.bGerarPDF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bGerarPDF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bGerarPDF.FlatAppearance.BorderSize = 0;
            this.bGerarPDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bGerarPDF.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bGerarPDF.ForeColor = System.Drawing.Color.White;
            this.bGerarPDF.Location = new System.Drawing.Point(837, 80);
            this.bGerarPDF.Name = "bGerarPDF";
            this.bGerarPDF.Size = new System.Drawing.Size(156, 41);
            this.bGerarPDF.TabIndex = 60;
            this.bGerarPDF.Text = "Gerar PDF";
            this.bGerarPDF.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bGerarPDF.UseVisualStyleBackColor = false;
            this.bGerarPDF.Click += new System.EventHandler(this.bGerarPDF_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Escolha uma ordenação",
            "Todos os serviços",
            "Os serviços da busca"});
            this.comboBox1.Location = new System.Drawing.Point(738, 41);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(255, 33);
            this.comboBox1.TabIndex = 58;
            // 
            // bAjuda
            // 
            this.bAjuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bAjuda.FlatAppearance.BorderSize = 0;
            this.bAjuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bAjuda.Font = new System.Drawing.Font("Segoe UI", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bAjuda.ForeColor = System.Drawing.Color.White;
            this.bAjuda.Location = new System.Drawing.Point(43, 80);
            this.bAjuda.Name = "bAjuda";
            this.bAjuda.Size = new System.Drawing.Size(99, 41);
            this.bAjuda.TabIndex = 42;
            this.bAjuda.Text = "Ajuda";
            this.bAjuda.UseVisualStyleBackColor = false;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(247)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(1285, 720);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelSideMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Meus Serviços";
            this.Load += new System.EventHandler(this.Form6_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelButtons.ResumeLayout(false);
            this.panelBemVindo.ResumeLayout(false);
            this.panelBemVindo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).EndInit();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewServicos)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Panel panelBemVindo;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.PictureBox pictureBoxWelcome;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bAjuda;
        private System.Windows.Forms.Button bCadastrarServico2;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button bRedefinirSenha;
        private System.Windows.Forms.Button bALterarMeusDados;
        private System.Windows.Forms.Button bMeusDados;
        private System.Windows.Forms.Button bConfiguracao;
        private System.Windows.Forms.Button bRetirarPagamento;
        private System.Windows.Forms.Button bpedidos;
        private System.Windows.Forms.Button bOrcamento;
        private System.Windows.Forms.Button bCadastrarServico;
        private System.Windows.Forms.Button bServicos;
        private System.Windows.Forms.Button bHome;
        private System.Windows.Forms.DataGridView dataGridViewServicos;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bPesquisar;
        private System.Windows.Forms.TextBox textBoxPesquisar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bGerarPDF;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewButtonColumn Column4;
        private System.Windows.Forms.Button button2;
    }
}
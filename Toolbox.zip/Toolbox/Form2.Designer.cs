﻿namespace Toolbox
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panelCadastro = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.checkBoxTSPP = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxPais = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxContato = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxSenha = new System.Windows.Forms.TextBox();
            this.bVoltar = new System.Windows.Forms.Button();
            this.bEscolherFoto = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBoxCadastro = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxEstado = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxBairro = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxCidade = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxNumero = new System.Windows.Forms.TextBox();
            this.textBoxComplemento = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxCEP = new System.Windows.Forms.TextBox();
            this.textBoxRua = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxTelefone = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.bCadastrar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.textBoxCNPJ = new System.Windows.Forms.TextBox();
            this.panelCadastro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCadastro)).BeginInit();
            this.SuspendLayout();
            // 
            // panelCadastro
            // 
            this.panelCadastro.BackColor = System.Drawing.Color.White;
            this.panelCadastro.Controls.Add(this.button1);
            this.panelCadastro.Controls.Add(this.linkLabel1);
            this.panelCadastro.Controls.Add(this.checkBoxTSPP);
            this.panelCadastro.Controls.Add(this.label16);
            this.panelCadastro.Controls.Add(this.textBoxPais);
            this.panelCadastro.Controls.Add(this.label15);
            this.panelCadastro.Controls.Add(this.label14);
            this.panelCadastro.Controls.Add(this.textBoxContato);
            this.panelCadastro.Controls.Add(this.label13);
            this.panelCadastro.Controls.Add(this.textBoxSenha);
            this.panelCadastro.Controls.Add(this.bVoltar);
            this.panelCadastro.Controls.Add(this.bEscolherFoto);
            this.panelCadastro.Controls.Add(this.label11);
            this.panelCadastro.Controls.Add(this.pictureBoxCadastro);
            this.panelCadastro.Controls.Add(this.label5);
            this.panelCadastro.Controls.Add(this.textBoxEstado);
            this.panelCadastro.Controls.Add(this.label6);
            this.panelCadastro.Controls.Add(this.textBoxBairro);
            this.panelCadastro.Controls.Add(this.label12);
            this.panelCadastro.Controls.Add(this.textBoxCidade);
            this.panelCadastro.Controls.Add(this.label9);
            this.panelCadastro.Controls.Add(this.label10);
            this.panelCadastro.Controls.Add(this.textBoxNumero);
            this.panelCadastro.Controls.Add(this.textBoxComplemento);
            this.panelCadastro.Controls.Add(this.label7);
            this.panelCadastro.Controls.Add(this.label8);
            this.panelCadastro.Controls.Add(this.textBoxCEP);
            this.panelCadastro.Controls.Add(this.textBoxRua);
            this.panelCadastro.Controls.Add(this.label3);
            this.panelCadastro.Controls.Add(this.label4);
            this.panelCadastro.Controls.Add(this.textBoxTelefone);
            this.panelCadastro.Controls.Add(this.textBoxNome);
            this.panelCadastro.Controls.Add(this.bCadastrar);
            this.panelCadastro.Controls.Add(this.label2);
            this.panelCadastro.Controls.Add(this.label1);
            this.panelCadastro.Controls.Add(this.textBoxUsername);
            this.panelCadastro.Controls.Add(this.textBoxCNPJ);
            this.panelCadastro.Location = new System.Drawing.Point(82, 32);
            this.panelCadastro.Name = "panelCadastro";
            this.panelCadastro.Size = new System.Drawing.Size(1062, 616);
            this.panelCadastro.TabIndex = 36;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(482, 234);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(34, 24);
            this.button1.TabIndex = 73;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.linkLabel1.ForeColor = System.Drawing.Color.Transparent;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.SteelBlue;
            this.linkLabel1.Location = new System.Drawing.Point(185, 556);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(379, 25);
            this.linkLabel1.TabIndex = 72;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Termos de Serviço e Política de Privacidade";
            // 
            // checkBoxTSPP
            // 
            this.checkBoxTSPP.AutoSize = true;
            this.checkBoxTSPP.BackColor = System.Drawing.Color.Transparent;
            this.checkBoxTSPP.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxTSPP.ForeColor = System.Drawing.Color.Black;
            this.checkBoxTSPP.Location = new System.Drawing.Point(41, 555);
            this.checkBoxTSPP.Name = "checkBoxTSPP";
            this.checkBoxTSPP.Size = new System.Drawing.Size(149, 29);
            this.checkBoxTSPP.TabIndex = 71;
            this.checkBoxTSPP.Text = "Li e aceitos os";
            this.checkBoxTSPP.UseVisualStyleBackColor = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label16.Location = new System.Drawing.Point(36, 465);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 25);
            this.label16.TabIndex = 70;
            this.label16.Text = "país";
            // 
            // textBoxPais
            // 
            this.textBoxPais.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxPais.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxPais.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxPais.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxPais.Location = new System.Drawing.Point(41, 493);
            this.textBoxPais.MaxLength = 15;
            this.textBoxPais.Name = "textBoxPais";
            this.textBoxPais.Size = new System.Drawing.Size(201, 32);
            this.textBoxPais.TabIndex = 69;
            this.textBoxPais.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxPais_KeyDown);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label15.Location = new System.Drawing.Point(808, 97);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 25);
            this.label15.TabIndex = 68;
            this.label15.Text = "imagem";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label14.Location = new System.Drawing.Point(422, 170);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(170, 25);
            this.label14.TabIndex = 67;
            this.label14.Text = "email para contato";
            // 
            // textBoxContato
            // 
            this.textBoxContato.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxContato.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxContato.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxContato.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxContato.Location = new System.Drawing.Point(427, 198);
            this.textBoxContato.Name = "textBoxContato";
            this.textBoxContato.Size = new System.Drawing.Size(365, 32);
            this.textBoxContato.TabIndex = 66;
            this.textBoxContato.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxContato_KeyDown);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label13.Location = new System.Drawing.Point(422, 233);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 25);
            this.label13.TabIndex = 64;
            this.label13.Text = "senha";
            // 
            // textBoxSenha
            // 
            this.textBoxSenha.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSenha.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxSenha.Location = new System.Drawing.Point(427, 261);
            this.textBoxSenha.Name = "textBoxSenha";
            this.textBoxSenha.PasswordChar = '•';
            this.textBoxSenha.Size = new System.Drawing.Size(365, 32);
            this.textBoxSenha.TabIndex = 63;
            this.textBoxSenha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSenha_KeyDown);
            // 
            // bVoltar
            // 
            this.bVoltar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bVoltar.FlatAppearance.BorderSize = 0;
            this.bVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bVoltar.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bVoltar.ForeColor = System.Drawing.Color.White;
            this.bVoltar.Location = new System.Drawing.Point(686, 541);
            this.bVoltar.Name = "bVoltar";
            this.bVoltar.Size = new System.Drawing.Size(121, 40);
            this.bVoltar.TabIndex = 62;
            this.bVoltar.Text = "voltar";
            this.bVoltar.UseVisualStyleBackColor = false;
            this.bVoltar.Click += new System.EventHandler(this.bVoltar_Click);
            // 
            // bEscolherFoto
            // 
            this.bEscolherFoto.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bEscolherFoto.FlatAppearance.BorderSize = 0;
            this.bEscolherFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bEscolherFoto.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bEscolherFoto.ForeColor = System.Drawing.Color.Black;
            this.bEscolherFoto.Location = new System.Drawing.Point(813, 415);
            this.bEscolherFoto.Name = "bEscolherFoto";
            this.bEscolherFoto.Size = new System.Drawing.Size(204, 41);
            this.bEscolherFoto.TabIndex = 61;
            this.bEscolherFoto.Text = "escolher foto";
            this.bEscolherFoto.UseVisualStyleBackColor = false;
            this.bEscolherFoto.Click += new System.EventHandler(this.bEscolherFoto_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label11.Location = new System.Drawing.Point(34, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(304, 37);
            this.label11.TabIndex = 60;
            this.label11.Text = "Cadastro de prestador";
            // 
            // pictureBoxCadastro
            // 
            this.pictureBoxCadastro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBoxCadastro.Location = new System.Drawing.Point(813, 125);
            this.pictureBoxCadastro.Name = "pictureBoxCadastro";
            this.pictureBoxCadastro.Size = new System.Drawing.Size(204, 262);
            this.pictureBoxCadastro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCadastro.TabIndex = 59;
            this.pictureBoxCadastro.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label5.Location = new System.Drawing.Point(243, 465);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 25);
            this.label5.TabIndex = 58;
            this.label5.Text = "estado";
            // 
            // textBoxEstado
            // 
            this.textBoxEstado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEstado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxEstado.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxEstado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxEstado.Location = new System.Drawing.Point(248, 493);
            this.textBoxEstado.MaxLength = 2;
            this.textBoxEstado.Name = "textBoxEstado";
            this.textBoxEstado.Size = new System.Drawing.Size(158, 32);
            this.textBoxEstado.TabIndex = 57;
            this.textBoxEstado.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxEstado_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label6.Location = new System.Drawing.Point(426, 396);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 25);
            this.label6.TabIndex = 56;
            this.label6.Text = "bairro";
            // 
            // textBoxBairro
            // 
            this.textBoxBairro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxBairro.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxBairro.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxBairro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxBairro.Location = new System.Drawing.Point(427, 424);
            this.textBoxBairro.Name = "textBoxBairro";
            this.textBoxBairro.Size = new System.Drawing.Size(365, 32);
            this.textBoxBairro.TabIndex = 55;
            this.textBoxBairro.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxBairro_KeyDown);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label12.Location = new System.Drawing.Point(422, 327);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 25);
            this.label12.TabIndex = 54;
            this.label12.Text = "cidade";
            // 
            // textBoxCidade
            // 
            this.textBoxCidade.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCidade.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCidade.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxCidade.Location = new System.Drawing.Point(427, 355);
            this.textBoxCidade.Name = "textBoxCidade";
            this.textBoxCidade.Size = new System.Drawing.Size(365, 32);
            this.textBoxCidade.TabIndex = 53;
            this.textBoxCidade.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCidade_KeyDown);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label9.Location = new System.Drawing.Point(243, 327);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 25);
            this.label9.TabIndex = 52;
            this.label9.Text = "número";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label10.Location = new System.Drawing.Point(422, 465);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(218, 25);
            this.label10.TabIndex = 51;
            this.label10.Text = "complemento (opcional)";
            // 
            // textBoxNumero
            // 
            this.textBoxNumero.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxNumero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxNumero.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxNumero.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxNumero.Location = new System.Drawing.Point(248, 355);
            this.textBoxNumero.MaxLength = 5;
            this.textBoxNumero.Name = "textBoxNumero";
            this.textBoxNumero.Size = new System.Drawing.Size(158, 32);
            this.textBoxNumero.TabIndex = 50;
            this.textBoxNumero.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxNumero_KeyDown);
            // 
            // textBoxComplemento
            // 
            this.textBoxComplemento.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxComplemento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxComplemento.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxComplemento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxComplemento.Location = new System.Drawing.Point(427, 493);
            this.textBoxComplemento.Name = "textBoxComplemento";
            this.textBoxComplemento.Size = new System.Drawing.Size(365, 32);
            this.textBoxComplemento.TabIndex = 49;
            this.textBoxComplemento.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxComplemento_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label7.Location = new System.Drawing.Point(36, 327);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 25);
            this.label7.TabIndex = 48;
            this.label7.Text = "CEP";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label8.Location = new System.Drawing.Point(36, 396);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 25);
            this.label8.TabIndex = 47;
            this.label8.Text = "endereço";
            // 
            // textBoxCEP
            // 
            this.textBoxCEP.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCEP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCEP.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCEP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxCEP.Location = new System.Drawing.Point(41, 355);
            this.textBoxCEP.MaxLength = 8;
            this.textBoxCEP.Name = "textBoxCEP";
            this.textBoxCEP.Size = new System.Drawing.Size(201, 32);
            this.textBoxCEP.TabIndex = 46;
            this.textBoxCEP.TextChanged += new System.EventHandler(this.textBoxCEP_TextChanged);
            this.textBoxCEP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCEP_KeyDown);
            // 
            // textBoxRua
            // 
            this.textBoxRua.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxRua.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxRua.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxRua.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxRua.Location = new System.Drawing.Point(41, 424);
            this.textBoxRua.Name = "textBoxRua";
            this.textBoxRua.Size = new System.Drawing.Size(365, 32);
            this.textBoxRua.TabIndex = 45;
            this.textBoxRua.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxRua_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label3.Location = new System.Drawing.Point(36, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 25);
            this.label3.TabIndex = 44;
            this.label3.Text = "telefone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label4.Location = new System.Drawing.Point(36, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 25);
            this.label4.TabIndex = 43;
            this.label4.Text = "nome";
            // 
            // textBoxTelefone
            // 
            this.textBoxTelefone.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxTelefone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTelefone.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxTelefone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxTelefone.Location = new System.Drawing.Point(41, 193);
            this.textBoxTelefone.MaxLength = 13;
            this.textBoxTelefone.Name = "textBoxTelefone";
            this.textBoxTelefone.Size = new System.Drawing.Size(365, 32);
            this.textBoxTelefone.TabIndex = 42;
            this.textBoxTelefone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxTelefone_KeyDown);
            // 
            // textBoxNome
            // 
            this.textBoxNome.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxNome.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxNome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxNome.Location = new System.Drawing.Point(41, 125);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(365, 32);
            this.textBoxNome.TabIndex = 0;
            this.textBoxNome.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxNome_KeyDown);
            // 
            // bCadastrar
            // 
            this.bCadastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bCadastrar.FlatAppearance.BorderSize = 0;
            this.bCadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrar.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrar.ForeColor = System.Drawing.Color.White;
            this.bCadastrar.Location = new System.Drawing.Point(813, 541);
            this.bCadastrar.Name = "bCadastrar";
            this.bCadastrar.Size = new System.Drawing.Size(204, 40);
            this.bCadastrar.TabIndex = 40;
            this.bCadastrar.Text = "cadastrar";
            this.bCadastrar.UseVisualStyleBackColor = false;
            this.bCadastrar.Click += new System.EventHandler(this.bCadastrar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label2.Location = new System.Drawing.Point(36, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 25);
            this.label2.TabIndex = 39;
            this.label2.Text = "email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label1.Location = new System.Drawing.Point(422, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 25);
            this.label1.TabIndex = 38;
            this.label1.Text = "CNPJ";
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxUsername.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxUsername.Location = new System.Drawing.Point(41, 261);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(365, 32);
            this.textBoxUsername.TabIndex = 37;
            this.textBoxUsername.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxUsername_KeyDown);
            // 
            // textBoxCNPJ
            // 
            this.textBoxCNPJ.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCNPJ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCNPJ.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCNPJ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxCNPJ.Location = new System.Drawing.Point(427, 125);
            this.textBoxCNPJ.MaxLength = 14;
            this.textBoxCNPJ.Name = "textBoxCNPJ";
            this.textBoxCNPJ.Size = new System.Drawing.Size(365, 32);
            this.textBoxCNPJ.TabIndex = 36;
            this.textBoxCNPJ.TextChanged += new System.EventHandler(this.textBoxCNPJ_TextChanged);
            this.textBoxCNPJ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCNPJ_KeyDown);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(247)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panelCadastro);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panelCadastro.ResumeLayout(false);
            this.panelCadastro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCadastro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelCadastro;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxBairro;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxCidade;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxNumero;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxCEP;
        private System.Windows.Forms.TextBox textBoxRua;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxTelefone;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.Button bCadastrar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.TextBox textBoxCNPJ;
        private System.Windows.Forms.TextBox textBoxEstado;
        private System.Windows.Forms.PictureBox pictureBoxCadastro;
        private System.Windows.Forms.Button bEscolherFoto;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button bVoltar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxSenha;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxComplemento;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxContato;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxPais;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.CheckBox checkBoxTSPP;
        private System.Windows.Forms.Button button1;
    }
}
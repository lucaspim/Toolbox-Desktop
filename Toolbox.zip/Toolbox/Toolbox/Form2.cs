﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace Toolbox
{
    public partial class Form2 : Form
    {
        MySqlConnection con;
        Thread nt;
        public Form2()
        {
            InitializeComponent();
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            panelCadastro.Location = new Point(this.Size.Width / 2 - panelCadastro.Size.Width / 2, this.Size.Height / 2 - panelCadastro.Size.Height / 2);
            panelCadastro.Anchor = AnchorStyles.None;
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void bCadastrar_Click(object sender, EventArgs e)
        {
            if ((textBoxBairro.Text == "") || (textBoxCidade.Text == "") || (textBoxNome.Text == "") || (textBoxEstado.Text == "") || (textBoxCNPJ.Text == "") || (textBoxTelefone.Text == "") || (textBoxUsername.Text == "") || (textBoxSenha.Text == "") || (textBoxCEP.Text == "") || (textBoxRua.Text == "") || (textBoxNumero.Text == ""))
            {
                MessageBox.Show("Algum dado está faltanto");
            }
            else
            {
                try
                {
                    //usar procedure
                    con.Open();
                    MySqlCommand inserirempresa = new MySqlCommand("insert into empresa(nome,cnpj,telefone,username,senha,fotoEmpresa) values('" + textBoxNome.Text + "','" + int.Parse(textBoxCNPJ.Text) + "','" + int.Parse(textBoxTelefone.Text) + "','" + textBoxUsername.Text + "','" + textBoxSenha.Text + "'@foto)", con);
                    inserirempresa.Parameters.AddWithValue("foto", ConverterFotoParaArray());
                    inserirempresa.ExecuteNonQuery();
                    MySqlCommand inserirendereco = new MySqlCommand("insert into endereco(cep,rua,numero,cidade,estado,complemento) values('" + int.Parse(textBoxCEP.Text) + "','" + textBoxRua.Text + "','" + int.Parse(textBoxNumero.Text) + "','" + textBoxCidade.Text + "','" + textBoxEstado.Text + "','" + textBoxComplemento.Text + "')", con);
                    inserirendereco.ExecuteNonQuery();
                    MessageBox.Show("gravado");
                    textBoxBairro.Clear();
                    textBoxCEP.Clear();
                    textBoxCidade.Clear();
                    textBoxCNPJ.Clear();
                    textBoxComplemento.Clear();
                    textBoxEstado.Clear();
                    textBoxNome.Clear();
                    textBoxNumero.Clear();
                    textBoxRua.Clear();
                    textBoxSenha.Clear();
                    textBoxTelefone.Clear();
                    textBoxUsername.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão");
                    MessageBox.Show(ex.Message);
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    con.Close();
                }
            }


        }

        private byte[] ConverterFotoParaArray()
        {
            using (var stream = new System.IO.MemoryStream())
            {
                pictureBoxCadastro.Image.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
                stream.Seek(0, System.IO.SeekOrigin.Begin);
                byte[] bArray = new byte[stream.Length];
                stream.Read(bArray, 0, System.Convert.ToInt32(stream.Length));
                return bArray;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void bVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(novoForm1);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void novoForm1()
        {
            Application.Run(new Form1());
        }

        private void panelCadastro_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bEscolherFoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Title = "Abrir Foto";
            dialog.Filter = "Images types (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg" + "|All files (*.*)|*.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pictureBoxCadastro.Image = new Bitmap(dialog.OpenFile());

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Não foi possivel carregar a foto: " + ex.Message);
                }
            }
            dialog.Dispose();
        }
    }
}

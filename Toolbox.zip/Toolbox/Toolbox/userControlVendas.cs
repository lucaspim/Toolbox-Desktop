﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Toolbox
{
    public partial class userControlVendas : UserControl
    {
        public userControlVendas()
        {
            InitializeComponent();
        }
        #region
        private String nome;
        private String cpf;
        private String email;
        private String telefone;
        private String servico;
        private String categoria;
        private String subcate;
        private String descricao;
        private String rua;
        private String estado;
        private String cep;
        private String cidade;
        private String num;
        private String complemento;
        private String data;
        private String preco;
        private String pagamento;
        private Image clienteFoto;

        public string Nome
        {
                get { return nome; }
                set { nome = value; label1.Text = value;}
            }
        
        public string Cpf
        {
                get { return cpf; }
                set { cpf = value; label2.Text = value;}
            }

        public string Email
        {
                get { return email; }
                set { email = value; label3.Text = value;}
            }
        
        public string Telefone
        {
                get { return telefone; }
                set { telefone = value; label4.Text = value;}
            }
        
        public string Servico
        {
                get { return servico; }
                set { servico = value; label5.Text = value;}
            }
        
        public string Descricao
            {
                get { return descricao;}
                set { descricao = value; label6.Text = value;}
            }
        
        public string Rua
        {
                get { return rua; }
                set { rua = value; label7.Text = value;}
            }
        
        public string Estado
        {
                get { return estado; }
                set { estado = value; label9.Text = value;}
            }
        
        public string Cep
        {
                get { return cep; }
                set { cep = value; label11.Text = value;}
            }
        
        public string Cidade
        {
                get { return cidade; }
                set { cidade = value; label10.Text = value;}
            }
        
        public string Num
        {
                get { return num; }
                set { num = value; label8.Text = value;}
            }
        
        public string Complemento
        {
                get { return complemento; }
                set { complemento = value; label12.Text = value;}
            }
        
        public string Data
        {
                get { return data; }
                set { data = value; label14.Text = value;}
            }
        
        public string Preco
        {
                get { return preco; }
                set { preco = value; label13.Text = value;}
        }

        public string Pagamento
        {
            get { return pagamento; }
            set { pagamento = value; label15.Text = value; }
        }

        public Image ClienteFoto
        {
            get { return clienteFoto; }
            set { clienteFoto = value; pictureBox1.Image = value; }
        }

        #endregion




        #region LabelsClick
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
        #endregion
    }
}

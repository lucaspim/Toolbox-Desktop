﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;


namespace Toolbox
{
    public partial class Form4 : Form
    {
        MySqlConnection con;
        Thread nt;
        public Form4()
        {
            InitializeComponent();
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            bMinhasVendas.BackColor = Color.FromArgb(40, 131, 238);
            bMinhasVendas.ForeColor = Color.White;
            try
            {
                con.Open();
                MySqlCommand logado = new MySqlCommand("Select fotoEmpresa,nome from empresa where username = '" + GlobalLogin.username + "' and senha = '" + GlobalLogin.senha + "'", con);
                MySqlDataReader resultado = logado.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["nome"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["fotoEmpresa"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
                else
                    MessageBox.Show("Erro.\nAlgum valor errado ou faltando");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand busca_Pedidos = new MySqlCommand("Select cep,cidade,numero,rua,complemento,estado from endereco", con);//usar view
                MySqlDataReader resultado = busca_Pedidos.ExecuteReader();

                while (resultado.Read())
                {
                    userControlVendas pedido = new userControlVendas();
                    pedido.Cep = "CEP "+ resultado["cep"].ToString();
                    pedido.Cidade = "Cidade " + resultado["cidade"].ToString();
                    pedido.Num = "Número " + resultado["numero"].ToString();
                    pedido.Rua = "Rua " + resultado["rua"].ToString();
                    pedido.Estado = "Estado " + resultado["estado"].ToString();
                    pedido.Complemento = "Complemento " + resultado["complemento"].ToString();
                    pedido.Nome = "teste";

                    flowLayoutPanel1.Controls.Add(pedido);
                        

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão");
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(login);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void login()
        {
            Application.Run(new Form1());
        }

        private void bHome_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3>().Count() == 0)
            {
                this.Close();
                nt = new Thread(Home);
                nt.SetApartmentState(ApartmentState.STA);
                nt.Start();
            }
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void bStatusServico_Click(object sender, EventArgs e)
        {

        }
    }
}

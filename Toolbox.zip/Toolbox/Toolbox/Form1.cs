﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Toolbox
{
    
    public partial class Form1 : Form
    {
        MySqlConnection con;
        Thread nt;

        public Form1()
        {
            InitializeComponent();
            try
            {
               con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panelLogin.Location = new Point(this.Size.Width / 2 - panelLogin.Size.Width / 2, this.Size.Height / 2 - panelLogin.Size.Height / 2);
            panelLogin.Anchor = AnchorStyles.None;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bLogin_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private void pictureBoxLogo_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void bCadastrar_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(novoForm);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void novoForm()
        {
            Application.Run(new Form2());
        }

        private void bLogin_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand login = new MySqlCommand("Select username,senha from empresa where username = '" + textBoxUser.Text + "' and senha = '" + textBoxSenha.Text + "'", con);
                MySqlDataReader resultado = login.ExecuteReader();

                if (resultado.Read())
                {
                    GlobalLogin.username = resultado["username"].ToString();
                    GlobalLogin.senha = resultado["senha"].ToString();
                    if (textBoxUser.Text == resultado["username"].ToString())
                    {
                        if (textBoxSenha.Text == resultado["senha"].ToString())
                            if (Application.OpenForms.OfType<Form3>().Count() == 0)
                        {
                            this.Close();
                            nt = new Thread(novoForm3);
                            nt.SetApartmentState(ApartmentState.STA);
                            nt.Start();
                        }
                    }
                }
                else
                    MessageBox.Show("Erro.\nAlgum valor errado ou faltando");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
               
            } 
            con.Close();
        }

        private void novoForm3()
        {
            Application.Run(new Form3());
        }
    }
}

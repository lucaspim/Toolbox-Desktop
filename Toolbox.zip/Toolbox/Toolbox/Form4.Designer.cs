﻿namespace Toolbox
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.bSair = new System.Windows.Forms.Button();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.bConfiguracoes = new System.Windows.Forms.Button();
            this.bMinhasVendas = new System.Windows.Forms.Button();
            this.bStatusServico = new System.Windows.Forms.Button();
            this.bCadastrarServico = new System.Windows.Forms.Button();
            this.bMeusDados = new System.Windows.Forms.Button();
            this.bHome = new System.Windows.Forms.Button();
            this.panelBemVindo = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.pictureBoxWelcome = new System.Windows.Forms.PictureBox();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelSideMenu.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelBemVindo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).BeginInit();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.BackColor = System.Drawing.Color.White;
            this.panelSideMenu.Controls.Add(this.bSair);
            this.panelSideMenu.Controls.Add(this.panelButtons);
            this.panelSideMenu.Controls.Add(this.panelBemVindo);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(280, 681);
            this.panelSideMenu.TabIndex = 2;
            // 
            // bSair
            // 
            this.bSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bSair.Location = new System.Drawing.Point(0, 652);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(280, 29);
            this.bSair.TabIndex = 6;
            this.bSair.Text = "sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bSair.UseVisualStyleBackColor = true;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // panelButtons
            // 
            this.panelButtons.Controls.Add(this.bConfiguracoes);
            this.panelButtons.Controls.Add(this.bMinhasVendas);
            this.panelButtons.Controls.Add(this.bStatusServico);
            this.panelButtons.Controls.Add(this.bCadastrarServico);
            this.panelButtons.Controls.Add(this.bMeusDados);
            this.panelButtons.Controls.Add(this.bHome);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelButtons.Location = new System.Drawing.Point(0, 151);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(280, 295);
            this.panelButtons.TabIndex = 2;
            // 
            // bConfiguracoes
            // 
            this.bConfiguracoes.Dock = System.Windows.Forms.DockStyle.Top;
            this.bConfiguracoes.FlatAppearance.BorderSize = 0;
            this.bConfiguracoes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bConfiguracoes.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bConfiguracoes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bConfiguracoes.Location = new System.Drawing.Point(0, 200);
            this.bConfiguracoes.Name = "bConfiguracoes";
            this.bConfiguracoes.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bConfiguracoes.Size = new System.Drawing.Size(280, 40);
            this.bConfiguracoes.TabIndex = 6;
            this.bConfiguracoes.Text = "configurações";
            this.bConfiguracoes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bConfiguracoes.UseVisualStyleBackColor = true;
            // 
            // bMinhasVendas
            // 
            this.bMinhasVendas.Dock = System.Windows.Forms.DockStyle.Top;
            this.bMinhasVendas.FlatAppearance.BorderSize = 0;
            this.bMinhasVendas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bMinhasVendas.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bMinhasVendas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bMinhasVendas.Location = new System.Drawing.Point(0, 160);
            this.bMinhasVendas.Name = "bMinhasVendas";
            this.bMinhasVendas.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bMinhasVendas.Size = new System.Drawing.Size(280, 40);
            this.bMinhasVendas.TabIndex = 5;
            this.bMinhasVendas.Text = "minhas vendas";
            this.bMinhasVendas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bMinhasVendas.UseVisualStyleBackColor = true;
            // 
            // bStatusServico
            // 
            this.bStatusServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bStatusServico.FlatAppearance.BorderSize = 0;
            this.bStatusServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bStatusServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bStatusServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bStatusServico.Location = new System.Drawing.Point(0, 120);
            this.bStatusServico.Name = "bStatusServico";
            this.bStatusServico.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bStatusServico.Size = new System.Drawing.Size(280, 40);
            this.bStatusServico.TabIndex = 4;
            this.bStatusServico.Text = "status dos pedidos";
            this.bStatusServico.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bStatusServico.UseVisualStyleBackColor = true;
            this.bStatusServico.Click += new System.EventHandler(this.bStatusServico_Click);
            // 
            // bCadastrarServico
            // 
            this.bCadastrarServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bCadastrarServico.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bCadastrarServico.Location = new System.Drawing.Point(0, 80);
            this.bCadastrarServico.Name = "bCadastrarServico";
            this.bCadastrarServico.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bCadastrarServico.Size = new System.Drawing.Size(280, 40);
            this.bCadastrarServico.TabIndex = 3;
            this.bCadastrarServico.Text = "meus serviços";
            this.bCadastrarServico.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCadastrarServico.UseVisualStyleBackColor = true;
            // 
            // bMeusDados
            // 
            this.bMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bMeusDados.FlatAppearance.BorderSize = 0;
            this.bMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bMeusDados.Location = new System.Drawing.Point(0, 40);
            this.bMeusDados.Name = "bMeusDados";
            this.bMeusDados.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bMeusDados.TabIndex = 2;
            this.bMeusDados.Text = "meus dados";
            this.bMeusDados.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bMeusDados.UseVisualStyleBackColor = true;
            // 
            // bHome
            // 
            this.bHome.BackColor = System.Drawing.Color.Transparent;
            this.bHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.bHome.FlatAppearance.BorderSize = 0;
            this.bHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bHome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.Location = new System.Drawing.Point(0, 0);
            this.bHome.Name = "bHome";
            this.bHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bHome.Size = new System.Drawing.Size(280, 40);
            this.bHome.TabIndex = 1;
            this.bHome.Text = "home";
            this.bHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.UseVisualStyleBackColor = false;
            this.bHome.Click += new System.EventHandler(this.bHome_Click);
            // 
            // panelBemVindo
            // 
            this.panelBemVindo.Controls.Add(this.labelWelcome);
            this.panelBemVindo.Controls.Add(this.pictureBoxWelcome);
            this.panelBemVindo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBemVindo.Location = new System.Drawing.Point(0, 86);
            this.panelBemVindo.Name = "panelBemVindo";
            this.panelBemVindo.Size = new System.Drawing.Size(280, 65);
            this.panelBemVindo.TabIndex = 1;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.labelWelcome.Location = new System.Drawing.Point(59, 24);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(105, 25);
            this.labelWelcome.TabIndex = 1;
            this.labelWelcome.Text = "bem vindo,";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxWelcome
            // 
            this.pictureBoxWelcome.Location = new System.Drawing.Point(21, 15);
            this.pictureBoxWelcome.Name = "pictureBoxWelcome";
            this.pictureBoxWelcome.Size = new System.Drawing.Size(34, 34);
            this.pictureBoxWelcome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxWelcome.TabIndex = 0;
            this.pictureBoxWelcome.TabStop = false;
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelLogo.Controls.Add(this.pictureBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.panelLogo.Size = new System.Drawing.Size(280, 86);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogo.ErrorImage = null;
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.InitialImage = null;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 5);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(280, 86);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(20, 3, 3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(984, 533);
            this.flowLayoutPanel1.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(280, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(984, 148);
            this.panel1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.flowLayoutPanel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(280, 148);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(984, 533);
            this.panel2.TabIndex = 5;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelSideMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Minhas Vendas";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelButtons.ResumeLayout(false);
            this.panelBemVindo.ResumeLayout(false);
            this.panelBemVindo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).EndInit();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button bConfiguracoes;
        private System.Windows.Forms.Button bMinhasVendas;
        private System.Windows.Forms.Button bStatusServico;
        private System.Windows.Forms.Button bCadastrarServico;
        private System.Windows.Forms.Button bMeusDados;
        private System.Windows.Forms.Button bHome;
        private System.Windows.Forms.Panel panelBemVindo;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.PictureBox pictureBoxWelcome;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}
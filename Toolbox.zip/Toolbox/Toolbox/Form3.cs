﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;

namespace Toolbox
{
    public partial class Form3 : Form
    {
        MySqlConnection con;
        Thread nt;
        public Form3()
        {
           
            InitializeComponent();
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            bHome.BackColor = Color.FromArgb(40, 131, 238);
            bHome.ForeColor = Color.White;
            try
            {
                con.Open();
                MySqlCommand logado = new MySqlCommand("Select fotoEmpresa,nome from empresa where username = '" + GlobalLogin.username + "' and senha = '" + GlobalLogin.senha + "'", con);
                MySqlDataReader resultado = logado.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["nome"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["fotoEmpresa"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
                else
                    MessageBox.Show("Erro.\nAlgum valor errado ou faltando");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3>().Count() == 0)
            {
                this.Close();
                nt = new Thread(Home);
                nt.SetApartmentState(ApartmentState.STA);
                nt.Start();
            }
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(login);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void login()
        {
            Application.Run(new Form1());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void bMinhasVendas_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(minhasVendas);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void minhasVendas()
        {
            Application.Run(new Form4());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;
using Correios;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Toolbox
{
    public partial class Form7 : Form
    {
        MySqlConnection con;
        Thread nt;
        int cepFlag = 0;
        bool verifyFlags = false;
        public Form7()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            bALterarMeusDados.BackColor = Color.FromArgb(40, 131, 238);
            bALterarMeusDados.ForeColor = Color.White;
            panelCentral.Location = new Point((this.Size.Width / 2 - panelCentral.Size.Width / 2)-150, (this.Size.Height / 2 - panelCentral.Size.Height / 2)-70);
            panelCentral.Anchor = AnchorStyles.None;
            bMeusDados.Visible = true;
            bALterarMeusDados.Visible = true;
            bRedefinirSenha.Visible = true;

            try
            {
                con.Open();
                MySqlCommand altDados = new MySqlCommand("call myData('" + GlobalLogin.idprestador + "');", con);
                MySqlDataReader resultado = altDados.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["desprovider"].ToString();

                    textBoxCNPJ.Text = resultado["descnpj"].ToString();
                    textBoxUsername.Text = resultado["deslogin"].ToString();
                    textBoxTelefone.Text = resultado["nrphone"].ToString();
                    textBoxNome.Text = resultado["desprovider"].ToString();
                    textBoxEstado.Text = resultado["desstate"].ToString();
                    textBoxBairro.Text = resultado["desneighborhood"].ToString();
                    textBoxCEP.Text = resultado["deszipcode"].ToString();
                    textBoxRua.Text = resultado["desaddress"].ToString();
                    textBoxNumero.Text = resultado["desnumber"].ToString();
                    textBoxComplemento.Text = resultado["descomplement"].ToString();
                    textBoxCidade.Text = resultado["descity"].ToString();
                    textBoxContato.Text = resultado["desemail"].ToString();
                    textBoxPais.Text = resultado["descountry"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();
        }

        #region Buttons Side Menu
        private void bHome_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            bCadastrarServico.BackColor = Color.Silver;
            bCadastrarServico.ForeColor = Color.White;
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
                MessageBox.Show("A janela de cadastrar serviço já está aberta.");
            else
                form9.Show();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Orcamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(pedidos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRetirarPagamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RetirarPagamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bConfiguracao_Click(object sender, EventArgs e)
        {
            if (bMeusDados.Visible == false)
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.AliceBlue;
                bMeusDados.Visible = true;
                bALterarMeusDados.Visible = true;
                bRedefinirSenha.Visible = true;
            }
            else
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.White;
                bMeusDados.Visible = false;
                bALterarMeusDados.Visible = false;
                bRedefinirSenha.Visible = false;
            }
        }

        private void bMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(MeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bALterarMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(ALterarMeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRedefinirSenha_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RedefinirSenha);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void Servicos()
        {
            Application.Run(new Form6());
        }

        private void Orcamento()
        {
            Application.Run(new Form8());
        }

        private void pedidos()
        {
            Application.Run(new Form4());
        }

        private void RetirarPagamento()
        {
            Application.Run(new Form10());
        }

        private void MeusDados()
        {
            Application.Run(new Form5());
        }

        private void ALterarMeusDados()
        {
            Application.Run(new Form7());
        }

        private void RedefinirSenha()
        {
            Application.Run(new Form11());
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }
        #endregion

        private void bSalvar_Click(object sender, EventArgs e)
        {
            if ((textBoxBairro.Text == "") || (textBoxCidade.Text == "") || (textBoxNome.Text == "") || (textBoxEstado.Text == "") || (textBoxCNPJ.Text == "") || (textBoxTelefone.Text == "") || (textBoxUsername.Text == "") || (textBoxCEP.Text == "") || (textBoxRua.Text == "") || (textBoxNumero.Text == "") || (textBoxContato.Text == "") || (textBoxPais.Text == ""))
            {
                MessageBox.Show("Algum dado está faltanto", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                verifyFlags = false;
            }
            else
                verifyFlags = true;

            if (textBoxCNPJ.Text.Length == 14)
                if (IsCnpj(textBoxCNPJ.Text) == true)
                    verifyFlags = true;
                else
                {
                    verifyFlags = false;
                    textBoxCNPJ.Focus();
                    MessageBox.Show("CNPJ inválido, por favor inserir um válido");
                }

            if (pictureBoxCadastro.Image == null)
                pictureBoxCadastro.Image = Image.FromFile("semFoto.png");

            if (IsValidEmail(textBoxUsername.Text) == true)
                verifyFlags = true;
            else
            {
                verifyFlags = false;
                MessageBox.Show("Email incorreto, por favor verifica-se de digitar o endereço de email corretamente");
            }

            if (IsValidEmail(textBoxContato.Text) == true)
                verifyFlags = true;
            else
            {
                verifyFlags = false;
                MessageBox.Show("Email de contato incorreto, por favor verifica-se de digitar o endereço de email corretamente");
            }

            if (IsDigitsOnly(textBoxNumero.Text) == true)
                verifyFlags = true;
            else
            {
                verifyFlags = false;
                MessageBox.Show("Número de endereço incorreto, por favor certifique-se de digitar números somente");
            }

            if (IsDigitsOnly(textBoxTelefone.Text) == true)
                verifyFlags = true;
            else
            {
                verifyFlags = false;
                MessageBox.Show("Número de telefone incorreto, por favor certifique-se de digitar números somente");
            }

            if (verifyFlags == true && cepFlag==1)
            {
                try
                {
                    con.Open();
                    MySqlCommand update_Provider = new MySqlCommand("call updating_UserProvider('" + int.Parse(textBoxCEP.Text) + "','" + textBoxRua.Text + "','" + int.Parse(textBoxNumero.Text) + "','" + textBoxCidade.Text + "','" + textBoxEstado.Text + "','" + "Brasil" + "', '" + textBoxBairro.Text + "', '" + textBoxComplemento.Text + "', '" + textBoxCNPJ.Text + "', '" + textBoxNome.Text + "', '" + int.Parse(textBoxTelefone.Text) + "', '" + textBoxUsername.Text + "', '" + textBoxContato.Text + "','" +"@foto" + "','" + GlobalLogin.idprestador + "');", con);
                    update_Provider.Parameters.AddWithValue("foto", ConverterFotoParaArray());
                    update_Provider.ExecuteNonQuery();
                    MessageBox.Show("Dados foram atualizados com sucesso!", "Sistema");
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                con.Close();
            }
            call_MyData();
        }

        public static bool IsCnpj(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int soma;
            int resto;
            string digito;
            string tempCnpj;
            cnpj = cnpj.Trim();
            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");
            if (cnpj.Length != 14)
                return false;
            tempCnpj = cnpj.Substring(0, 12);
            soma = 0;
            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCnpj = tempCnpj + digito;
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            return cnpj.EndsWith(digito);
        }

        private void call_MyData()
        {
            try
            {
                con.Open();
                MySqlCommand meusDados = new MySqlCommand("call myData('" + GlobalLogin.idprestador + "');", con);
                MySqlDataReader resultado = meusDados.ExecuteReader();

                if (resultado.Read())
                {
                    textBoxCNPJ.Text = resultado["descnpj"].ToString();
                    textBoxUsername.Text = resultado["deslogin"].ToString();
                    textBoxTelefone.Text = resultado["nrphone"].ToString();
                    textBoxNome.Text = resultado["desprovider"].ToString();
                    textBoxEstado.Text = resultado["desstate"].ToString();
                    textBoxBairro.Text = resultado["desneighborhood"].ToString();
                    textBoxCEP.Text = resultado["deszipcode"].ToString();
                    textBoxRua.Text = resultado["desaddress"].ToString();
                    textBoxNumero.Text = resultado["desnumber"].ToString();
                    textBoxComplemento.Text = resultado["descomplement"].ToString();
                    textBoxCidade.Text = resultado["descity"].ToString();
                    textBoxContato.Text = resultado["desemail"].ToString();
                    textBoxPais.Text = resultado["descountry"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxCadastro.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
                else
                    MessageBox.Show("Erro.\nAlgum valor errado ou faltando");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();
        }

        private void bEscolherFoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Title = "Abrir Foto";
            dialog.Filter = "Images types (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg" + "|All files (*.*)|*.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pictureBoxCadastro.Image = new Bitmap(dialog.OpenFile());

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Não foi possivel carregar a foto: " + ex.Message);
                }
            }
            dialog.Dispose();
        }

        private byte[] ConverterFotoParaArray()
        {
            using (var stream = new System.IO.MemoryStream())
            {
                pictureBoxCadastro.Image.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
                stream.Seek(0, System.IO.SeekOrigin.Begin);
                byte[] bArray = new byte[stream.Length];
                stream.Read(bArray, 0, System.Convert.ToInt32(stream.Length));
                return bArray;
            }
        }

        #region Keys_Down+CEP
        private void textBoxNome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxCNPJ.Focus();
            }
        }

        private void textBoxCNPJ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxTelefone.Focus();
            }
        }

        private void textBoxTelefone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxContato.Focus();
            }
        }

        private void textBoxContato_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxUsername.Focus();
            }
        }

        private void textBoxUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxTelefone.Focus();
            }
        }

        private void textBoxCEP_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (string.IsNullOrEmpty(textBoxCEP.Text))
                {
                    MessageBox.Show("O campo de CEP está vazio", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    CorreiosApi correiosApi = new CorreiosApi();
                    try
                    {
                        var retorno = correiosApi.consultaCEP(textBoxCEP.Text);
                        if (retorno is null)
                        {
                            cepFlag = 0;
                            MessageBox.Show("CEP não encontrado", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        textBoxBairro.Text = retorno.bairro;
                        textBoxCidade.Text = retorno.cidade;
                        textBoxEstado.Text = retorno.uf;
                        textBoxRua.Text = retorno.end;
                        textBoxPais.Text = "Brasil";
                        textBoxComplemento.Text = retorno.complemento;
                        cepFlag = 1;
                    }
                    catch (System.ServiceModel.FaultException)
                    {
                        cepFlag = 0;
                        MessageBox.Show("CEP invalido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                textBoxNumero.Focus();
            }
        }

        private void textBoxCEP_TextChanged(object sender, EventArgs e)
        {
                if (textBoxCEP.Text.Length == 8)
                {
                    if (string.IsNullOrEmpty(textBoxCEP.Text))
                    {
                        MessageBox.Show("O campo de CEP está vazio", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        CorreiosApi correiosApi = new CorreiosApi();
                        try
                        {
                            var retorno = correiosApi.consultaCEP(textBoxCEP.Text);
                            if (retorno is null)
                            {
                                cepFlag = 0;
                                MessageBox.Show("CEP não encontrado", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            textBoxBairro.Text = retorno.bairro;
                            textBoxCidade.Text = retorno.cidade;
                            textBoxEstado.Text = retorno.uf;
                            textBoxRua.Text = retorno.end;
                        textBoxPais.Text = "Brasil";
                        textBoxComplemento.Text = retorno.complemento;
                            cepFlag = 1;
                        }
                        catch (System.ServiceModel.FaultException)
                        {
                            cepFlag = 0;
                            MessageBox.Show("CEP invalido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            textBoxNumero.Focus();
        }

        private void textBoxNumero_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxNumero.Focus();
            }
        }

        private void textBoxComplemento_KeyDown(object sender, KeyEventArgs e)
        {
            bEscolherFoto_Click( sender,  e);
        }
        #endregion

        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));
                string DomainMapper(Match match)
                {
                    var idn = new IdnMapping();

                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                return false;
            }
            catch (ArgumentException e)
            {
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }
            return true;
        }
    }
}

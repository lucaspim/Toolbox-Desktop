﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace Toolbox
{
    public partial class Form6 : Form
    {
        MySqlConnection con;
        Thread nt;
        public Form6()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            bServicos.BackColor = Color.FromArgb(40, 131, 238);
            bServicos.ForeColor = Color.White;
            bMeusDados.Visible = false;
            bALterarMeusDados.Visible = false;
            bRedefinirSenha.Visible = false;
            dataGridViewServicos.Location = new Point((panel3.Size.Width / 2 - dataGridViewServicos.Size.Width / 2)-120, 40);
            dataGridViewServicos.Anchor = AnchorStyles.None;

            try
            {
                con.Open();
                MySqlCommand logado = new MySqlCommand("select imguserprovider,desprovider from tb_userprovider inner join tb_providers where tb_userprovider.idprovider ='" + GlobalLogin.idprestador + "' and tb_providers.idprovider = '" + GlobalLogin.idprestador + "';", con);
                MySqlDataReader resultado = logado.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["desprovider"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = System.Drawing.Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = System.Drawing.Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
                else
                    MessageBox.Show("Erro.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

            DisplayService();

            //try
            //{
            //    con.Open();
            //    MySqlCommand busca_Pedidos = new MySqlCommand("call myOrders('" + GlobalLogin.username + "','" + GlobalLogin.senha + "')", con);
            //    MySqlDataReader resultado = busca_Pedidos.ExecuteReader();

            //    if (resultado.Read())
            //    {
            //        UserControlServico servico = new UserControlServico();
            //        servico.Servico = "Limpeza de veículo";
            //        servico.Preco = "R$ 25,00";
            //        servico.Rating = "hoje";
            //        servico.Descricao = "limpeza de carros e motos";

            //        UserControlServico servico1 = new UserControlServico();
            //        servico1.Servico = "Jardinagem";
            //        servico1.Preco = "R$ 150,00";
            //        servico1.Rating = "Em 3 dias";
            //        servico1.Descricao = "Jardinagem residencial, com foco em gramas e flores. Podagem de pequenas árvores e criação de jardins botânicos internos";

            //        UserControlServico servico2 = new UserControlServico();
            //        servico2.Servico = "Alvenaria";
            //        servico2.Preco = "R$ 1200,00";
            //        servico2.Rating = "hoje";
            //        servico2.Descricao = "Conserto de armários e portas";

            //        flowLayoutPanel1.Controls.Add(servico);
            //        flowLayoutPanel1.Controls.Add(servico1);
            //        flowLayoutPanel1.Controls.Add(servico2);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}
            //con.Close();


        }

        private void DeleteService(int idservico)
        {
                try
                {
                    con.Open();
                    MySqlCommand deletar_servico = new MySqlCommand("call Delete_services('" + GlobalLogin.idprestador + "','" + idservico + "');", con);
                    deletar_servico.ExecuteNonQuery();
                    MessageBox.Show("Serviço deletado.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                }
                con.Close();
        }

        #region Buttons Side Menu
        private void bHome_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            bCadastrarServico.BackColor = Color.Silver;
            bCadastrarServico.ForeColor = Color.White;
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
            {
                form9.BringToFront();
                form9.TopMost = true;
                form9.Focus();
            }
            else
            {
                GlobalLogin.sugg = false;
                form9.Show();
            }
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Orcamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(pedidos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRetirarPagamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RetirarPagamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bConfiguracao_Click(object sender, EventArgs e)
        {
            if (bMeusDados.Visible == false)
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.AliceBlue;
                bMeusDados.Visible = true;
                bALterarMeusDados.Visible = true;
                bRedefinirSenha.Visible = true;
            }
            else
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.White;
                bMeusDados.Visible = false;
                bALterarMeusDados.Visible = false;
                bRedefinirSenha.Visible = false;
            }
        }

        private void bMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(MeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bALterarMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(ALterarMeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRedefinirSenha_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RedefinirSenha);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void Servicos()
        {
            Application.Run(new Form6());
        }

        private void Orcamento()
        {
            Application.Run(new Form8());
        }

        private void pedidos()
        {
            Application.Run(new Form4());
        }

        private void RetirarPagamento()
        {
            Application.Run(new Form10());
        }

        private void MeusDados()
        {
            Application.Run(new Form5());
        }

        private void ALterarMeusDados()
        {
            Application.Run(new Form7());
        }

        private void RedefinirSenha()
        {
            Application.Run(new Form11());
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }
        
        private void bCadastrarServico2_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
            {
                form9.BringToFront();
                form9.TopMost = true;
                form9.Focus();
            }
            else
            {
                GlobalLogin.sugg = false;
                form9.Show();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
            {
                form9.BringToFront();
                form9.TopMost = true;
                form9.Focus();
            }
            else
            {
                GlobalLogin.sugg = true;
                form9.Show();
            }
                
        }
        #endregion

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DisplayService()
        {
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("call Provider_services('" + GlobalLogin.idprestador + "');", con);
                

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DisplayService();
        }

        private void textBoxPesquisar_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idservice, desservice, desserviceprovider, IF(tb_servicesprovider.availabity = 1,'"+ "Hoje" +"',IF(tb_servicesprovider.availabity = 2,'"+"Em 3 dias" + "',IF(tb_servicesprovider.availabity = 3,'" + "Em 1 semana" + "','" + "Em 1 mês" + "'))) as availabity, rating from tb_services inner join tb_servicesprovider using (idservice) where tb_services.idservice = tb_servicesprovider.idservice and tb_servicesprovider.idprovider = '" + GlobalLogin.idprestador + "'  and tb_services.desservice LIKE '%" + textBoxPesquisar.Text + "%' or tb_servicesprovider.desserviceprovider LIKE '%" + textBoxPesquisar.Text + "%' ;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void dataGridViewServicos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                DialogResult ask_forDeletion = MessageBox.Show("Tem certeza que deseja deletar esse serviço?","Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forDeletion)
                {
                    //MessageBox.Show(dataGridViewServicos.Rows[e.RowIndex].Cells[0].Value.ToString() + " 0\n" + dataGridViewServicos.Rows[e.RowIndex].Cells[1].Value.ToString() + " 1\n" + dataGridViewServicos.Rows[e.RowIndex].Cells[2].Value.ToString() + " 2\n" + dataGridViewServicos.Rows[e.RowIndex].Cells[3].Value.ToString() + " 3\n" + dataGridViewServicos.Rows[e.RowIndex].Cells[4].Value.ToString() + " 4\n");
                    int d = int.Parse(dataGridViewServicos.Rows[e.RowIndex].Cells[1].Value.ToString());
                    DeleteService(d);
                    DisplayService();
                }
            }
        }

        private void bPesquisar_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idservice, desservice, desserviceprovider, IF(tb_servicesprovider.availabity = 1,'" + "Hoje" + "',IF(tb_servicesprovider.availabity = 2,'" + "Em 3 dias" + "',IF(tb_servicesprovider.availabity = 3,'" + "Em 1 semana" + "','" + "Em 1 mês" + "'))) as availabity, rating from tb_services inner join tb_servicesprovider using (idservice) where tb_services.idservice = tb_servicesprovider.idservice and tb_servicesprovider.idprovider = '" + GlobalLogin.idprestador + "' and tb_services.desservice LIKE '%" + textBoxPesquisar.Text + "%' or tb_servicesprovider.desserviceprovider LIKE '%" + textBoxPesquisar.Text + "%' ;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void bGerarPDF_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Escolha uma ordenação")
            {
                MessageBox.Show("Selecione um modo de ordenação para gerar o pdf");
            }

            if (comboBox1.SelectedItem.ToString() == "Todos os serviços")
            {
                DisplayService();
                GeneratePDF();
            }

            if (comboBox1.SelectedItem.ToString() == "Os serviços da busca")
            {
                textBoxPesquisar_TextChanged( sender,  e);
                GeneratePDF();
            }
        }

        private void GeneratePDF()
        {
            if (dataGridViewServicos.Rows.Count > 0)
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "PDF (*.pdf)|*.pdf";
                save.FileName = "Serviços.pdf";
                bool Error = false;

                if (save.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(save.FileName))
                    {
                        try
                        {
                            File.Delete(save.FileName);
                        }
                        catch (Exception ex)
                        {
                            Error = true;
                            MessageBox.Show("Não foi possível salvar.\n"+ex.Message);
                        }
                    }
                    if (!Error)
                    {
                        try
                        {
                            PdfPTable table = new PdfPTable(dataGridViewServicos.Columns.Count);
                            table.DefaultCell.Padding = 2;
                            table.WidthPercentage = 100;
                            table.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach(DataGridViewColumn col in dataGridViewServicos.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(col.HeaderText));
                                table.AddCell(cell);
                            }
                            foreach(DataGridViewRow row in dataGridViewServicos.Rows)
                            {
                                foreach(DataGridViewCell dcell in row.Cells)
                                {
                                    table.AddCell(dcell.Value.ToString());
                                }
                            }

                            using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))
                            {
                                Document document = new Document(PageSize.A4, 8f, 16f, 16f, 8f);
                                document.Open();
                                document.Add(table);
                                document.Close();
                                fileStream.Close();
                            }
                            MessageBox.Show("PDF gerado e salvo com sucesso.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Aconteceu algo de errado.\n" + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Não há serviço para gerar um PDF.\n");
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Toolbox
{
    
    public partial class Form1 : Form
    {
        MySqlConnection con;
        Thread nt;
        bool verifyFlags = false;
        int f = 0;

        public Form1()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
               con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panelLogin.Location = new Point(this.Size.Width / 2 - panelLogin.Size.Width / 2, this.Size.Height / 2 - panelLogin.Size.Height / 2);
            panelLogin.Anchor = AnchorStyles.None;
        }

        private void bCadastrar_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(novoForm);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void novoForm()
        {
            Application.Run(new Form2());
        }

        private void bLogin_Click(object sender, EventArgs e)
        {
            if (IsValidEmail(textBoxUser.Text) == true)
                verifyFlags = true;

            verifyFlags = true;
            try
            {
                string password = textBoxSenha.Text;
                con.Open();
                MySqlCommand login = new MySqlCommand("Select deslogin,despassword,idprovider,iduserprovider from tb_userprovider where deslogin = '" + textBoxUser.Text + "'", con);
                MySqlDataReader resultado = login.ExecuteReader();
                
                while (resultado.Read())
                {
                    if (textBoxUser.Text == resultado["deslogin"].ToString())
                    {
                        if (BCrypt.Net.BCrypt.Verify(password, resultado["despassword"].ToString()))
                        {
                            GlobalLogin.senha = resultado["despassword"].ToString();
                            GlobalLogin.username = resultado["deslogin"].ToString();
                            GlobalLogin.idprestador = int.Parse(resultado["idprovider"].ToString());
                            GlobalLogin.iduserprestador = int.Parse(resultado["iduserprovider"].ToString());
                            this.Close();
                            nt = new Thread(novoForm3);
                            nt.SetApartmentState(ApartmentState.STA);
                            nt.Start();
                        }

                    }
                    else
                        MessageBox.Show("Erro.\nAlgum valor errado ou faltando");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha no cadastro\nErro: " + ex.Message + "\n" + ex.ToString());
            } 
            con.Close();
        }

        private void novoForm3()
        {
            Application.Run(new Form3());
        }

        private void textBoxUser_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxSenha.Focus();
            }
        }

        private void textBoxSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bLogin_Click(sender,e);
            }
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //this.linkLabel1.LinkVisited = true;
            //System.Diagnostics.Process.Start("https://toolboxservico.space/forgot");
            //this.Close();
            //nt = new Thread(EsqueciSenha);
            //nt.SetApartmentState(ApartmentState.STA);
            //nt.Start();
        }

        private void EsqueciSenha()
        {
            Application.Run(new Form13());
        }

        private void button1_Click(object sender, EventArgs e)  
        {
            if (f == 0)
            {
                textBoxSenha.PasswordChar = char.Parse("\0");
                f = 1;
                button1.BackColor = Color.Gainsboro;
            }
            else
            {
                textBoxSenha.PasswordChar = char.Parse("•");
                f = 0;
                button1.BackColor = Color.Transparent;
            }
        }

        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));
                string DomainMapper(Match match)
                {
                    var idn = new IdnMapping();

                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                return false;
            }
            catch (ArgumentException e)
            {
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

    }
}

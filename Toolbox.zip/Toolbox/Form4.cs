﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;


namespace Toolbox
{
    public partial class Form4 : Form
    {
        MySqlConnection con;
        Thread nt;
        int idquot, dispo = 0, status = 1;
        bool verifyFlags = false;
        string endereço, tel;
        DateTime prazo;

        public Form4()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            bpedidos.BackColor = Color.FromArgb(40, 131, 238);
            bpedidos.ForeColor = Color.White;
            bMeusDados.Visible = false;
            bALterarMeusDados.Visible = false;
            bRedefinirSenha.Visible = false;
            panelCliente.Visible = false;
            panelOrçamento.Visible = false;
            panelServico.Visible = false;
            panelPedido.Visible = false;

            dataGridViewPedidos.Location = new Point((panel2.Size.Width / 2 - dataGridViewPedidos.Size.Width / 2), 40);
            dataGridViewPedidos.Anchor = AnchorStyles.Bottom;
            panelCliente.Location = new Point(1165, 300);
            panelCliente.Anchor = AnchorStyles.None;
            panelOrçamento.Location = new Point(1165, 300);
            panelOrçamento.Anchor = AnchorStyles.None;
            panelServico.Location = new Point(1165, 300);
            panelServico.Anchor = AnchorStyles.None;
            panelPedido.Location = new Point(1165, 300);
            panelPedido.Anchor = AnchorStyles.None;

            status = 6;
            Display_Orders(6);

            try
            {
                con.Open();
                MySqlCommand logado = new MySqlCommand("select imguserprovider,desprovider from tb_userprovider inner join tb_providers where tb_userprovider.idprovider ='" + GlobalLogin.idprestador + "' and tb_providers.idprovider = '" + GlobalLogin.idprestador + "';", con);
                MySqlDataReader resultado = logado.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["desprovider"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

        }

        #region Buttons Side Menu
        private void bHome_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            bCadastrarServico.BackColor = Color.Silver;
            bCadastrarServico.ForeColor = Color.White;
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
                MessageBox.Show("A janela de cadastrar serviço já está aberta.");
            else
                form9.Show();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Orcamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(pedidos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRetirarPagamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RetirarPagamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bConfiguracao_Click(object sender, EventArgs e)
        {
            if (bMeusDados.Visible == false)
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.AliceBlue;
                bMeusDados.Visible = true;
                bALterarMeusDados.Visible = true;
                bRedefinirSenha.Visible = true;
            }
            else
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.White;
                bMeusDados.Visible = false;
                bALterarMeusDados.Visible = false;
                bRedefinirSenha.Visible = false;
            }
        }

        private void bMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(MeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bALterarMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(ALterarMeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRedefinirSenha_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RedefinirSenha);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void Servicos()
        {
            Application.Run(new Form6());
        }

        private void Orcamento()
        {
            Application.Run(new Form8());
        }

        private void pedidos()
        {
            Application.Run(new Form4());
        }

        private void RetirarPagamento()
        {
            Application.Run(new Form10());
        }

        private void MeusDados()
        {
            Application.Run(new Form5());
        }

        private void ALterarMeusDados()
        {
            Application.Run(new Form7());
        }

        private void RedefinirSenha()
        {
            Application.Run(new Form11());
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        #endregion

        private void button5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://wa.me/" + tel + "?text=Tudo bem, cliente.0A%Gostaria de iniciar uma conversa sobre o seu pedido.");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.google.com.br/maps/search/" + endereço);
        }

        private void bCod_Click(object sender, EventArgs e)
        {
            panelCliente.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panelServico.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panelOrçamento.Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panelPedido.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridViewPedidos.Columns["Column33"].Visible = true;
            dataGridViewPedidos.Columns["Column34"].Visible = true;
            status = 6;
            Display_Orders(6);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridViewPedidos.Columns["Column33"].Visible = false;
            dataGridViewPedidos.Columns["Column34"].Visible = false;
            status = 7;
            Display_Orders(7);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridViewPedidos.Columns["Column33"].Visible = false;
            dataGridViewPedidos.Columns["Column34"].Visible = false;
            status = 8;
            Display_Orders(8);
        }

        private void dataGridViewPedidos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.ColumnIndex.ToString());
            //for (int i = 0; i < 40; i++)
            //{
            //    MessageBox.Show(dataGridViewORcamentos.Rows[e.RowIndex].Cells[i].Value.ToString() + " cells" + i);
            //}
            if (e.ColumnIndex == 34)
            {
                dispo = int.Parse(dataGridViewPedidos.Rows[e.RowIndex].Cells[26].Value.ToString());
                idquot = int.Parse(dataGridViewPedidos.Rows[e.RowIndex].Cells[0].Value.ToString());

                DialogResult ask_forAcceptance = MessageBox.Show("Tem certeza que deseja esse pedido por em andamento?", "Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forAcceptance)
                {
                    try
                    {
                        con.Open();
                        MySqlCommand Accepted = new MySqlCommand("update tb_quotes set idstatus = 7 where idquote = '" + idquot + "';", con);
                        Accepted.ExecuteNonQuery();
                        MySqlCommand Accepted2 = new MySqlCommand("update tb_orders set idstatus = 7 where idquote = '" + idquot + "';", con);
                        Accepted2.ExecuteNonQuery();

                        MessageBox.Show("Pedido posto em andamento com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                    }
                    con.Close();
                    Display_Orders(6);
                }
            }

            if (e.ColumnIndex == 35)
            {
                DialogResult ask_forContinuance = MessageBox.Show("Tem certeza que deseja concluir esse pedido?", "Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forContinuance)
                {
                    idquot = int.Parse(dataGridViewPedidos.Rows[e.RowIndex].Cells[0].Value.ToString());

                    try
                    {
                        con.Open();
                        MySqlCommand Continuance = new MySqlCommand("update tb_quotes set idstatus = 8 where idquote = '" + idquot + "';", con);
                        Continuance.ExecuteNonQuery();
                        MessageBox.Show("Pedido concluído com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                    }
                    con.Close();
                    Display_Orders(6);
                }
            }

            if (e.ColumnIndex == 1 || e.ColumnIndex == 2)
            {
                tel = dataGridViewPedidos.Rows[e.RowIndex].Cells[33].Value.ToString();
                endereço = dataGridViewPedidos.Rows[e.RowIndex].Cells[18].Value.ToString();

                panelCliente.Visible = true;
                panelOrçamento.Visible = false;
                panelServico.Visible = false;
                panelPedido.Visible = false;

                var data = (Byte[])(dataGridViewPedidos.Rows[e.RowIndex].Cells[31].Value);
                var stream = new MemoryStream(data);
                pictureBox3.Image = Image.FromStream(stream);

                label8.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox1.Text = "CPF: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[32].Value.ToString() + "\r\nTelefone: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[33].Value.ToString() + "\r\nEmail: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[28].Value.ToString();
                textBox6.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[22].Value.ToString() + " - CEP: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[18].Value.ToString() + "\r\n" + dataGridViewPedidos.Rows[e.RowIndex].Cells[2].Value.ToString() + " - " + dataGridViewPedidos.Rows[e.RowIndex].Cells[21].Value.ToString() + "\r\n" + dataGridViewPedidos.Rows[e.RowIndex].Cells[19].Value.ToString() + "\r\nBairro: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[3].Value.ToString() + "\r\nNº: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[20].Value.ToString() + "\r\nComplemtento: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[23].Value.ToString();
            }

            if (e.ColumnIndex == 4)
            {
                panelServico.Visible = true;
                panelCliente.Visible = false;
                panelOrçamento.Visible = false;
                panelPedido.Visible = false;

                textBox3.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[4].Value.ToString();
                if (dataGridViewPedidos.Rows[e.RowIndex].Cells[26].Value.ToString() == "1")
                    label13.Text = "Hoje";
                if (dataGridViewPedidos.Rows[e.RowIndex].Cells[26].Value.ToString() == "2")
                    label13.Text = "Em 3 dias";
                if (dataGridViewPedidos.Rows[e.RowIndex].Cells[26].Value.ToString() == "3")
                    label13.Text = "Em 1 semana";
                if (dataGridViewPedidos.Rows[e.RowIndex].Cells[26].Value.ToString() == "4")
                    label13.Text = "Em 1 mês";
                textBox2.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[24].Value.ToString();
            }

            if (e.ColumnIndex == 12 || e.ColumnIndex == 9 || e.ColumnIndex == 8 || e.ColumnIndex == 11 || e.ColumnIndex == 7 || e.ColumnIndex == 10 || e.ColumnIndex == 5 || e.ColumnIndex == 6)
            {
                panelOrçamento.Visible = true;
                panelCliente.Visible = false;
                panelServico.Visible = false;
                panelPedido.Visible = false;

                prazo = DateTime.Parse(dataGridViewPedidos.Rows[e.RowIndex].Cells[10].Value.ToString());
                label19.Text = "Nº Orçamento " + dataGridViewPedidos.Rows[e.RowIndex].Cells[12].Value.ToString();
                label14.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[7].Value.ToString();
                textBox4.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[6].Value.ToString();
                textBox5.Text = "Solicitação: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[5].Value.ToString() + "\r\nPrazo: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[10].Value.ToString() + "\r\nDuração de " + dataGridViewPedidos.Rows[e.RowIndex].Cells[8].Value.ToString() + " dias\r\nExecução começa em: " + dataGridViewPedidos.Rows[e.RowIndex].Cells[9].Value.ToString();
                label20.Text = "Preço do orçamento                 " + dataGridViewPedidos.Rows[e.RowIndex].Cells[11].Value.ToString();
            }

            if (e.ColumnIndex == 12441134)
            {
                int i = 0;
                panelOrçamento.Visible = false;
                panelCliente.Visible = false;
                panelServico.Visible = false;
                panelPedido.Visible = true;

                if (int.Parse(dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString()) == 0)
                {
                    i = 0;
                }
                else
                {
                    i = int.Parse(dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString());
                }

                if (i == 0)
                {
                    star1.Image = Image.FromFile("starza.png");
                    star2.Image = Image.FromFile("starza.png");
                    star3.Image = Image.FromFile("starza.png");
                    star4.Image = Image.FromFile("starza.png");
                    star5.Image = Image.FromFile("starza.png");
                }
                else
                {
                    if (i == 1)
                    {
                        star1.Image = Image.FromFile("starzul.png");
                        star2.Image = Image.FromFile("starza.png");
                        star3.Image = Image.FromFile("starza.png");
                        star4.Image = Image.FromFile("starza.png");
                        star5.Image = Image.FromFile("starza.png");
                    }
                    if (i == 2)
                    {
                        star1.Image = Image.FromFile("starzul.png");
                        star2.Image = Image.FromFile("starzul.png");
                        star3.Image = Image.FromFile("starza.png");
                        star4.Image = Image.FromFile("starza.png");
                        star5.Image = Image.FromFile("starza.png");
                    }
                    if (i == 3)
                    {
                        star1.Image = Image.FromFile("starzul.png");
                        star2.Image = Image.FromFile("starzul.png");
                        star3.Image = Image.FromFile("starzul.png");
                        star4.Image = Image.FromFile("starza.png");
                        star5.Image = Image.FromFile("starza.png");
                    }
                    if (i == 4)
                    {
                        star1.Image = Image.FromFile("starzul.png");
                        star2.Image = Image.FromFile("starzul.png");
                        star3.Image = Image.FromFile("starzul.png");
                        star4.Image = Image.FromFile("starzul.png");
                        star5.Image = Image.FromFile("starza.png");
                    }
                    if (i == 5)
                    {
                        star1.Image = Image.FromFile("starzul.png");
                        star2.Image = Image.FromFile("starzul.png");
                        star3.Image = Image.FromFile("starzul.png");
                        star4.Image = Image.FromFile("starzul.png");
                        star5.Image = Image.FromFile("starzul.png");
                    }
                }

                label22.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString();
                label5.Text = "Cartão de "+dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString();
                label23.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString();
                label4.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString();
                label26.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString();
                label1.Text = dataGridViewPedidos.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
        }

        private void textBoxPesquisar_TextChanged(object sender, EventArgs e)
        {
            Orders_like(status, textBoxPesquisar.Text);
        }

        private void bPesquisar_Click(object sender, EventArgs e)
        {
            Orders_like(status,textBoxPesquisar.Text);
        }

        private void Display_Orders(int stats)
        {
            dataGridViewPedidos.AutoGenerateColumns = false;

            dataGridViewPedidos.Columns["Column23"].DisplayIndex = 1;
            dataGridViewPedidos.Columns["Column24"].DisplayIndex = 2;
            dataGridViewPedidos.Columns["Column26"].DisplayIndex = 3;
            dataGridViewPedidos.Columns["Column37"].DisplayIndex = 4;
            dataGridViewPedidos.Columns["Column38"].DisplayIndex = 5;
            dataGridViewPedidos.Columns["Column42"].DisplayIndex = 6;
            dataGridViewPedidos.Columns["Column40"].DisplayIndex = 7;
            dataGridViewPedidos.Columns["Column41"].DisplayIndex = 8;
            dataGridViewPedidos.Columns["Column39"].DisplayIndex = 9;
            dataGridViewPedidos.Columns["Column35"].DisplayIndex = 10;
            dataGridViewPedidos.Columns["Column33"].DisplayIndex = 11;
            dataGridViewPedidos.Columns["Column34"].DisplayIndex = 12;

            try
            {
                con.Open();
                MySqlCommand display_Orders = new MySqlCommand("call Orders_data('" + GlobalLogin.idprestador + "','" + stats + "');", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_Orders);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewPedidos.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();

        }

        private void Orders_like(int stats, string text)
        {
            dataGridViewPedidos.AutoGenerateColumns = false;

            dataGridViewPedidos.Columns["Column23"].DisplayIndex = 1;
            dataGridViewPedidos.Columns["Column24"].DisplayIndex = 2;
            dataGridViewPedidos.Columns["Column26"].DisplayIndex = 3;
            dataGridViewPedidos.Columns["Column37"].DisplayIndex = 4;
            dataGridViewPedidos.Columns["Column38"].DisplayIndex = 5;
            dataGridViewPedidos.Columns["Column42"].DisplayIndex = 6;
            dataGridViewPedidos.Columns["Column40"].DisplayIndex = 7;
            dataGridViewPedidos.Columns["Column41"].DisplayIndex = 8;
            dataGridViewPedidos.Columns["Column39"].DisplayIndex = 9;
            dataGridViewPedidos.Columns["Column35"].DisplayIndex = 10;
            dataGridViewPedidos.Columns["Column33"].DisplayIndex = 11;
            dataGridViewPedidos.Columns["Column34"].DisplayIndex = 12;

            try
            {
                con.Open();
                MySqlCommand Orders_like = new MySqlCommand("call Orders_Like('" + GlobalLogin.idprestador + "','" + stats + "','" + text + "');", con);

                MySqlDataAdapter da = new MySqlDataAdapter(Orders_like);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewPedidos.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Globalization;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using System.Configuration;
using Twilio.TwiML;
using System.Net;
using System.Net.Mail;

namespace Toolbox
{
    public partial class Form13 : Form
    {
        MySqlConnection con;
        Thread nt;
        bool verifyFlags = false, email = false, tel = false;
        public Form13()
        {
            InitializeComponent();
            TwilioClient.SetRegion("br1");
            TwilioClient.SetEdge("sao-paulo");
            //Size(532, 544);
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel1.Location = new Point(this.Size.Width / 2 - panel1.Size.Width / 2, 40);
            panel1.Anchor = AnchorStyles.None;

            panel2.Visible = false;
            panel2.Location = new Point(this.Size.Width / 2 - panel2.Size.Width / 2, 40);
            panel2.Anchor = AnchorStyles.None;

            panel3.Visible = false;
            panel3.Location = new Point(this.Size.Width / 2 - panel3.Size.Width / 2, 40);
            panel3.Anchor = AnchorStyles.None;
        }

        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));
                string DomainMapper(Match match)
                {
                    var idn = new IdnMapping();

                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                return false;
            }
            catch (ArgumentException e)
            {
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }
            return true;
        }

        private void bCod_Click(object sender, EventArgs e)
        {
            SendEmail();
            //SendSMS();
            //if (IsDigitsOnly(textBoxP1.Text) == true && textBoxP1.Text.Length == 13)
            //{
            //    verifyFlags = true;
            //    tel = true;
            //}
            //else
            //{
            //    if (IsValidEmail(textBoxP1.Text) == true)
            //    {
            //        verifyFlags = true;
            //        email = true;
            //    }
            //    else
            //    {
            //        MessageBox.Show("Por favor, digite um email ou telefone válido");
            //    }
            //}

        }

        private void SendEmail()
        {
            string to, from, pass, body;
            MailMessage message = new MailMessage();
            to = "pimlucas14@gmail.com";
            from = "lucaspim.007@hotmail.com.br";
            pass = "14lucas41L.";
            body = "teste\n cod 123445";

            message.To.Add(to);
            message.From = new MailAddress(from);
            message.Body = "DE: " + "<br><hr><br>Mensagem: " + body;
            message.Subject = "t";
            message.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(from, pass);

            try
            {
                smtp.Send(message);
                DialogResult em = MessageBox.Show("enviado");

            }
            catch(Exception ex)
            {
                MessageBox.Show("erro \n" + ex.Message +"\n\n"+ex.ToString());
            }
        }

        //private void SendSMS()
        //{
        //    try
        //    {
        //        string account = Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID");
        //        string auth = Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN");

        //        TwilioClient.Init(account, auth);
        //        //TwilioClient.SetLogLevel("debug");
        //        //TwilioClient.Init(Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID"), Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN"));
        //        //TwilioClient.Init("ACCOUNT_SID", "AUTH_TOKEN");

        //        var m = MessageResource.Create(
        //            to: new PhoneNumber("+5519996187020"),
        //            from: new PhoneNumber("+5511942450103"),
        //            body: "teste");
        //        Console.WriteLine(m.Sid);
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ToString());
        //    }
        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;

namespace Toolbox
{
    public partial class Form8 : Form
    {
        MySqlConnection con;
        Thread nt;
        int idquot,dispo = 0,status = 1;
        bool verifyFlags = false, calendarFlags=false;
        string endereço,tel;
        DateTime prazo;

        public Form8()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            bOrcamento.BackColor = Color.FromArgb(40, 131, 238);
            bOrcamento.ForeColor = Color.White;

            bMeusDados.Visible = false;
            bALterarMeusDados.Visible = false;
            bRedefinirSenha.Visible = false;
            panelAprovar.Visible = false;
            panelCliente.Visible = false;
            panelOrçamento.Visible = false;
            panelServico.Visible = false;

            dataGridViewORcamentos.Location = new Point((panel2.Size.Width / 2 - dataGridViewORcamentos.Size.Width / 2), 40);
            dataGridViewORcamentos.Anchor = AnchorStyles.Bottom;
            panelCliente.Location = new Point(1165, 300);
            panelCliente.Anchor = AnchorStyles.None;
            panelOrçamento.Location = new Point(1165, 300);
            panelOrçamento.Anchor = AnchorStyles.None;
            panelServico.Location = new Point(1165, 300);
            panelServico.Anchor = AnchorStyles.None;

            status = 1;
            Display_Quotes(1);

            try
            {
                con.Open();
                MySqlCommand logado = new MySqlCommand("select imguserprovider,desprovider from tb_userprovider inner join tb_providers where tb_userprovider.idprovider ='" + GlobalLogin.idprestador + "' and tb_providers.idprovider = '" + GlobalLogin.idprestador + "';", con);
                MySqlDataReader resultado = logado.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["desprovider"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();
        }

        #region Buttons Side Menu
        private void bHome_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            bCadastrarServico.BackColor = Color.Silver;
            bCadastrarServico.ForeColor = Color.White;
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
                MessageBox.Show("A janela de cadastrar serviço já está aberta.");
            else
                form9.Show();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Orcamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(pedidos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRetirarPagamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RetirarPagamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bConfiguracao_Click(object sender, EventArgs e)
        {
            if (bMeusDados.Visible == false)
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.AliceBlue;
                bMeusDados.Visible = true;
                bALterarMeusDados.Visible = true;
                bRedefinirSenha.Visible = true;
            }
            else
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.White;
                bMeusDados.Visible = false;
                bALterarMeusDados.Visible = false;
                bRedefinirSenha.Visible = false;
            }
        }

        private void bMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(MeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bALterarMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(ALterarMeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRedefinirSenha_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RedefinirSenha);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void Servicos()
        {
            Application.Run(new Form6());
        }

        private void Orcamento()
        {
            Application.Run(new Form8());
        }

        private void pedidos()
        {
            Application.Run(new Form4());
        }

        private void RetirarPagamento()
        {
            Application.Run(new Form10());
        }

        private void MeusDados()
        {
            Application.Run(new Form5());
        }

        private void ALterarMeusDados()
        {
            Application.Run(new Form7());
        }

        private void RedefinirSenha()
        {
            Application.Run(new Form11());
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }
        #endregion

        private void bsalvarAprovação_Click(object sender, EventArgs e)
        {
            if (IsDigitsOnly(textBoxPreco.Text) == true)
                verifyFlags = true;
            else
                MessageBox.Show("Por favor digitar um preço válido.");

            if (IsDigitsOnly(textBoxDuracao.Text) == true)
                verifyFlags = true;
            else
                MessageBox.Show("Por favor digitar uma duração em dias válida.");

            if (dispo == 1 && monthCalendar1.SelectionStart.ToString("yyyy-MM-dd") == monthCalendar1.TodayDate.ToString("yyyy-MM-dd"))
                calendarFlags = true;
            else
            {
                if (dispo == 2 && monthCalendar1.SelectionStart <= monthCalendar1.TodayDate.AddDays(3) && monthCalendar1.SelectionStart >= monthCalendar1.TodayDate)
                    calendarFlags = true;
                else
                {
                    if (dispo == 3 && monthCalendar1.SelectionStart <= monthCalendar1.TodayDate.AddDays(7) && monthCalendar1.SelectionStart >= monthCalendar1.TodayDate)
                        calendarFlags = true;
                    else
                    {
                        if (dispo == 4 && monthCalendar1.SelectionStart <= monthCalendar1.TodayDate.AddDays(30) && monthCalendar1.SelectionStart >= monthCalendar1.TodayDate)
                            calendarFlags = true;
                        else
                        {
                            calendarFlags = false;
                            if (dispo == 1)
                                MessageBox.Show("Por favor selecionar uma data para execução válida à sua disponibilidade que é hoje.");
                            if (dispo == 2)
                                MessageBox.Show("Por favor selecionar uma data para execução válida à sua disponibilidade que é em 3 dias.");
                            if (dispo == 3)
                                MessageBox.Show("Por favor selecionar uma data para execução válida à sua disponibilidade que é em 1 semana.");
                            if (dispo == 4)
                                MessageBox.Show("Por favor selecionar uma data para execução válida à sua disponibilidade que é em 1 mês (30 dias).");
                        }
                    }
                }
            }

            if (verifyFlags == true && calendarFlags == true)
            {
                DialogResult ask_forAcceptance = MessageBox.Show("Tem certeza que deseja aprovar esse orçamento?", "Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forAcceptance)
                {
                    try
                    {
                        con.Open();
                        MySqlCommand Accepted = new MySqlCommand("update tb_quotes set idstatus = 2, vlquote = '" + decimal.Parse(textBoxPreco.Text) + "', duration = '" + textBoxDuracao.Text + "', execution = '" + monthCalendar1.SelectionStart.ToString("yyyy-MM-dd") + "' where idquote = '" + idquot + "';", con);
                        Accepted.ExecuteNonQuery();

                        MessageBox.Show("Orçamento aprovado com sucesso!");
                        textBoxDuracao.Clear();
                        textBoxPreco.Clear();
                        monthCalendar1.SelectionStart = monthCalendar1.TodayDate;
                        panelAprovar.Visible = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                    }
                    con.Close();
                    Display_Quotes(1);
                }
            }
        }

        private void bAjuda_Click(object sender, EventArgs e)
        {

        }

        private void Display_Quotes(int stats)
        {
            dataGridViewORcamentos.AutoGenerateColumns = false;

            dataGridViewORcamentos.Columns["Column23"].DisplayIndex = 1;
            dataGridViewORcamentos.Columns["Column24"].DisplayIndex = 2;
            dataGridViewORcamentos.Columns["Column26"].DisplayIndex = 3;
            dataGridViewORcamentos.Columns["Column28"].DisplayIndex = 4;
            dataGridViewORcamentos.Columns["Column27"].DisplayIndex = 5;
            dataGridViewORcamentos.Columns["Column36"].DisplayIndex = 6;
            dataGridViewORcamentos.Columns["Column30"].DisplayIndex = 7;
            dataGridViewORcamentos.Columns["Column29"].DisplayIndex = 8;
            dataGridViewORcamentos.Columns["Column31"].DisplayIndex = 9;
            dataGridViewORcamentos.Columns["Column32"].DisplayIndex = 10;
            dataGridViewORcamentos.Columns["Column35"].DisplayIndex = 11;
            dataGridViewORcamentos.Columns["Column33"].DisplayIndex = 12;
            dataGridViewORcamentos.Columns["Column34"].DisplayIndex = 13;

            try
            {
                con.Open();
                MySqlCommand display_Quotes = new MySqlCommand("call Quotes_data('" + GlobalLogin.idprestador + "','" + stats + "');", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_Quotes);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewORcamentos.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();

        }

        private void Quotes_like(int stats,string text)
        {
            dataGridViewORcamentos.AutoGenerateColumns = false;

            dataGridViewORcamentos.Columns["Column23"].DisplayIndex = 1;
            dataGridViewORcamentos.Columns["Column24"].DisplayIndex = 2;
            dataGridViewORcamentos.Columns["Column26"].DisplayIndex = 3;
            dataGridViewORcamentos.Columns["Column28"].DisplayIndex = 4;
            dataGridViewORcamentos.Columns["Column27"].DisplayIndex = 5;
            dataGridViewORcamentos.Columns["Column36"].DisplayIndex = 6;
            dataGridViewORcamentos.Columns["Column30"].DisplayIndex = 7;
            dataGridViewORcamentos.Columns["Column29"].DisplayIndex = 8;
            dataGridViewORcamentos.Columns["Column31"].DisplayIndex = 9;
            dataGridViewORcamentos.Columns["Column32"].DisplayIndex = 10;
            dataGridViewORcamentos.Columns["Column35"].DisplayIndex = 11;
            dataGridViewORcamentos.Columns["Column33"].DisplayIndex = 12;
            dataGridViewORcamentos.Columns["Column34"].DisplayIndex = 13;

            try
            {
                con.Open();
                MySqlCommand Quotes_like = new MySqlCommand("call Quotes_Like('" + GlobalLogin.idprestador + "','" + stats + "','" + text + "');", con);

                MySqlDataAdapter da = new MySqlDataAdapter(Quotes_like);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewORcamentos.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();
        }

        private void dataGridViewORcamentos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.ColumnIndex.ToString());
            //for (int i = 0; i < 40; i++)
            //{
            //    MessageBox.Show(dataGridViewORcamentos.Rows[e.RowIndex].Cells[i].Value.ToString() + " cells" + i);
            //}
            if (e.ColumnIndex == 34)
            {
                dispo = int.Parse(dataGridViewORcamentos.Rows[e.RowIndex].Cells[26].Value.ToString());
                panelAprovar.Visible = true;
                idquot = int.Parse(dataGridViewORcamentos.Rows[e.RowIndex].Cells[0].Value.ToString());
                monthCalendar1.Focus();
            }

            if (e.ColumnIndex == 35)
            {
                DialogResult ask_forRefusal = MessageBox.Show("Tem certeza que deseja rejeitar esse orçamento?", "Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forRefusal)
                {
                    idquot = int.Parse(dataGridViewORcamentos.Rows[e.RowIndex].Cells[0].Value.ToString());

                    try
                    {
                        con.Open();
                        MySqlCommand Refused = new MySqlCommand("update tb_quotes set idstatus = 3 where idquote = '" + idquot + "';", con);
                        Refused.ExecuteNonQuery();
                        MessageBox.Show("Orçamento rejeitado com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                    }
                    con.Close();
                    Display_Quotes(1);
                }
            }

            if (e.ColumnIndex == 1 || e.ColumnIndex == 2)
            {
                tel = dataGridViewORcamentos.Rows[e.RowIndex].Cells[33].Value.ToString();
                endereço = dataGridViewORcamentos.Rows[e.RowIndex].Cells[18].Value.ToString();

                panelCliente.Visible = true;
                panelOrçamento.Visible = false;
                panelServico.Visible = false;

                var data = (Byte[])(dataGridViewORcamentos.Rows[e.RowIndex].Cells[31].Value);
                var stream = new MemoryStream(data);
                pictureBox3.Image = Image.FromStream(stream);

                label8.Text = dataGridViewORcamentos.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox1.Text = "CPF: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[32].Value.ToString() + "\r\nTelefone: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[33].Value.ToString()+ "\r\nEmail: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[28].Value.ToString();
                textBox6.Text = dataGridViewORcamentos.Rows[e.RowIndex].Cells[22].Value.ToString() + " - CEP: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[18].Value.ToString() + "\r\n" + dataGridViewORcamentos.Rows[e.RowIndex].Cells[2].Value.ToString() + " - " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[21].Value.ToString() + "\r\n" + dataGridViewORcamentos.Rows[e.RowIndex].Cells[19].Value.ToString() + "\r\nBairro: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[3].Value.ToString() + "\r\nNº: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[20].Value.ToString() + "\r\nComplemtento: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[23].Value.ToString();
            }

            if (e.ColumnIndex == 4)
            {
                panelServico.Visible = true;
                panelCliente.Visible = false;
                panelOrçamento.Visible = false;
                textBox3.Text = dataGridViewORcamentos.Rows[e.RowIndex].Cells[4].Value.ToString();
                if (dataGridViewORcamentos.Rows[e.RowIndex].Cells[26].Value.ToString() == "1")
                    label13.Text = "Hoje";
                if (dataGridViewORcamentos.Rows[e.RowIndex].Cells[26].Value.ToString() == "2")
                    label13.Text = "Em 3 dias";
                if (dataGridViewORcamentos.Rows[e.RowIndex].Cells[26].Value.ToString() == "3")
                    label13.Text = "Em 1 semana";
                if (dataGridViewORcamentos.Rows[e.RowIndex].Cells[26].Value.ToString() == "4")
                    label13.Text = "Em 1 mês";
                textBox2.Text = dataGridViewORcamentos.Rows[e.RowIndex].Cells[24].Value.ToString();
            }

            if (e.ColumnIndex == 12 || e.ColumnIndex == 9 || e.ColumnIndex == 8 || e.ColumnIndex == 11 || e.ColumnIndex == 7 || e.ColumnIndex == 10 || e.ColumnIndex == 5 || e.ColumnIndex == 6)
            {
                panelOrçamento.Visible = true;
                panelCliente.Visible = false;
                panelServico.Visible = false;
                prazo = DateTime.Parse(dataGridViewORcamentos.Rows[e.RowIndex].Cells[10].Value.ToString());
                label19.Text = "Nº Orçamento "+dataGridViewORcamentos.Rows[e.RowIndex].Cells[12].Value.ToString();
                label14.Text = dataGridViewORcamentos.Rows[e.RowIndex].Cells[7].Value.ToString();
                textBox4.Text = dataGridViewORcamentos.Rows[e.RowIndex].Cells[6].Value.ToString();
                textBox5.Text = "Solicitação: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[5].Value.ToString() + "\r\nPrazo: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[10].Value.ToString() + "\r\nDuração de " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[8].Value.ToString() + " dias\r\nExecução começa em: " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[9].Value.ToString();
                label20.Text = "Preço do orçamento                 " + dataGridViewORcamentos.Rows[e.RowIndex].Cells[11].Value.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridViewORcamentos.Columns["Column33"].Visible = false;
            dataGridViewORcamentos.Columns["Column34"].Visible = false;
            status = 3;
            Display_Quotes(3);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridViewORcamentos.Columns["Column33"].Visible = false;
            dataGridViewORcamentos.Columns["Column34"].Visible = false;
            status = 2;
            Display_Quotes(2);
        }

        private void textBoxDuracao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxPreco.Focus();
            }
        }

        private void textBoxPreco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bsalvarAprovação_Click( sender,  e);
            }
        }

        private void monthCalendar1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxDuracao.Focus();
            }
        }

        private void panelServico_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bCod_Click(object sender, EventArgs e)
        {
            panelCliente.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panelServico.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panelOrçamento.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.google.com.br/maps/search/"+endereço);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://wa.me/" + tel + "?text=Tudo bem, cliente.0A%Gostaria de iniciar uma conversa sobre o seu orçamento para ver os detalhes e melhor entender o serviço.");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            dataGridViewORcamentos.Columns["Column33"].Visible = true;
            dataGridViewORcamentos.Columns["Column34"].Visible = true;
            status = 1;
            Display_Quotes(1);
        }

        private void textBoxPesquisar_TextChanged(object sender, EventArgs e)
        {
            
            Quotes_like(status,textBoxPesquisar.Text);
        }

        private void bPesquisar_Click(object sender, EventArgs e)
        {
            Quotes_like(status, textBoxPesquisar.Text);
        }

        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9' )
                    return false;
            }
            return true;
        }
    }
}

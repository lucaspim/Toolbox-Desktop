﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace Toolbox
{
    public partial class Form10 : Form
    {
        MySqlConnection con;
        Thread nt;
        int b = 0,f=0;
        decimal qd=0,balance;
        bool verifyFlags = false;
        string savePath,bs;

        public Form10()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            bRetirarPagamento.BackColor = Color.FromArgb(40, 131, 238);
            bRetirarPagamento.ForeColor = Color.White;
            bMeusDados.Visible = false;
            bALterarMeusDados.Visible = false;
            bRedefinirSenha.Visible = false;

            try
            {
                con.Open();
                MySqlCommand logado = new MySqlCommand("select imguserprovider,desprovider from tb_userprovider inner join tb_providers where tb_userprovider.idprovider ='" + GlobalLogin.idprestador + "' and tb_providers.idprovider = '" + GlobalLogin.idprestador + "';", con);
                MySqlDataReader resultado = logado.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["desprovider"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = System.Drawing.Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = System.Drawing.Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand QuantDispo = new MySqlCommand("call accounting('" + GlobalLogin.idprestador + "');", con);
                MySqlDataReader resultado = QuantDispo.ExecuteReader();

                if (resultado.Read())
                {
                    if (resultado["accountbalance"].ToString() == null || resultado["accountbalance"].ToString() == "" || resultado["accountbalance"].ToString() == "0")
                    {
                        label7.Text = "R$ 0,00";
                        qd = 0.00M;
                    }
                    else
                    {
                        label7.Text = "R$ " + resultado["accountbalance"].ToString();
                        qd = decimal.Parse(resultado["accountbalance"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();
        }

        #region Buttons Side Menu
        private void bHome_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            bCadastrarServico.BackColor = Color.Silver;
            bCadastrarServico.ForeColor = Color.White;
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
                MessageBox.Show("A janela de cadastrar serviço já está aberta.");
            else
                form9.Show();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Orcamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(pedidos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRetirarPagamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RetirarPagamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bConfiguracao_Click(object sender, EventArgs e)
        {
            if (bMeusDados.Visible == false)
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.AliceBlue;
                bMeusDados.Visible = true;
                bALterarMeusDados.Visible = true;
                bRedefinirSenha.Visible = true;
            }
            else
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.White;
                bMeusDados.Visible = false;
                bALterarMeusDados.Visible = false;
                bRedefinirSenha.Visible = false;
            }
        }

        private void bMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(MeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bALterarMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(ALterarMeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRedefinirSenha_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RedefinirSenha);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void Servicos()
        {
            Application.Run(new Form6());
        }

        private void Orcamento()
        {
            Application.Run(new Form8());
        }

        private void pedidos()
        {
            Application.Run(new Form4());
        }

        private void RetirarPagamento()
        {
            Application.Run(new Form10());
        }

        private void MeusDados()
        {
            Application.Run(new Form5());
        }

        private void ALterarMeusDados()
        {
            Application.Run(new Form7());
        }

        private void RedefinirSenha()
        {
            Application.Run(new Form11());
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }


        #endregion

        #region Bank buttons
        private void button6_Click(object sender, EventArgs e)
        {
            b = 6;
            bs = "Bradesco";
            button6.FlatAppearance.BorderSize = 3;
            button6.FlatAppearance.BorderColor = Color.FromArgb(40, 131, 238);
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.BorderColor = Color.WhiteSmoke;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            b = 2;
            bs = "Itaú";
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button2.FlatAppearance.BorderSize = 3;
            button2.FlatAppearance.BorderColor = Color.FromArgb(40, 131, 238);
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.BorderColor = Color.WhiteSmoke;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            b = 3;
            bs = "Caixa";
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button3.FlatAppearance.BorderSize = 3;
            button3.FlatAppearance.BorderColor = Color.FromArgb(40, 131, 238);
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.BorderColor = Color.WhiteSmoke;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            b = 4;
            bs = "Santander";
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button4.FlatAppearance.BorderSize = 3;
            button4.FlatAppearance.BorderColor = Color.FromArgb(40, 131, 238);
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.BorderColor = Color.WhiteSmoke;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            b = 5;
            bs = "Banco do Brasil";
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button5.FlatAppearance.BorderSize = 3;
            button5.FlatAppearance.BorderColor = Color.FromArgb(40, 131, 238);
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.BorderColor = Color.WhiteSmoke;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            b = 8;
            bs = "BANRISUL";
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button8.FlatAppearance.BorderSize = 3;
            button8.FlatAppearance.BorderColor = Color.FromArgb(40, 131, 238);
        }
        #endregion
        private void bRetirar_Click(object sender, EventArgs e)
        {
            DialogResult retirar_Pagto = MessageBox.Show("Tem certeza que deseja retirar " + textBoxValor.Text + " reais?", "Sistema", MessageBoxButtons.YesNo);

            try
            {
                string password = textBoxSenha.Text;

                con.Open();
                MySqlCommand identidade = new MySqlCommand("Select despassword from tb_userprovider where idprovider = '" + GlobalLogin.idprestador + "'", con);
                MySqlDataReader resultado = identidade.ExecuteReader();

                if (resultado.Read())
                {
                    if (BCrypt.Net.BCrypt.Verify(password, resultado["despassword"].ToString()))
                    {
                        verifyFlags = true;
                    }
                    else
                        MessageBox.Show("Senha incorreta, tente novamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand CNPJ = new MySqlCommand("call myData('" + GlobalLogin.idprestador + "');", con);
                MySqlDataReader resultado = CNPJ.ExecuteReader();

                if (resultado.Read())
                {
                    if (resultado["descnpj"].ToString() == textBoxCNPJ.Text)
                        verifyFlags = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();

            if (textBoxAgencia.Text == null || textBoxAgencia.Text.Length < 4 || textBoxConta.Text == null || textBoxConta.Text.Length < 7 || b == 0 || IsDigitsOnly(textBoxAgencia.Text) == false || IsDigitsOnly(textBoxConta.Text) == false)
                MessageBox.Show("Por favor, insira corretamente os dados bancários");
            else
                verifyFlags = true;

            if (textBoxCNPJ.Text.Length == 14)
                if (IsCnpj(textBoxCNPJ.Text) == true)
                    verifyFlags = true;
                else
                {
                    verifyFlags = false;
                    textBoxCNPJ.Focus();
                    MessageBox.Show("CNPJ inválido, por favor inserir um válido");
                }

            if (textBoxValor.Text == null)
                verifyFlags = false;

            if (qd == 0 || textBoxValor.Text == null || textBoxValor.Text == "")
            {
                MessageBox.Show("Valor não inserido ou 0 reais disponíveis para retirada");
                verifyFlags = false;
            }
            else
            {
                if (decimal.Parse(textBoxValor.Text) > qd || decimal.Parse(textBoxValor.Text.Replace(".", ",")) > qd)
                {
                    MessageBox.Show("Valor insuficiente para retirada" +"\nqd = "+qd+"\ntextbox so replace "+ textBoxValor.Text.Replace(",", ".") + "\ntextbox nada" + textBoxValor.Text + "\ntextbox so decimal" + decimal.Parse(textBoxValor.Text) + "\ntextbox tudo" + decimal.Parse(textBoxValor.Text.Replace(",", ".")));
                    verifyFlags = false;
                }
                else
                {

                }
                    verifyFlags = true;
            }
            if (verifyFlags == true && retirar_Pagto == DialogResult.Yes)
            {
                try
                {
                    con.Open();
                    //MySqlCommand Retirar_pagto = new MySqlCommand("update tb_providers set accountbalance = accountbalance-'" + retirar + "' where idprovider = '" + GlobalLogin.idprestador + "';", con);

                    MySqlCommand Retirar_pagto = new MySqlCommand("call Retirar_pagto('" + decimal.Parse(textBoxValor.Text) + "','" + GlobalLogin.idprestador + "');", con);
                    Retirar_pagto.ExecuteNonQuery();
                    MessageBox.Show("Pagamento retirado com sucesso!", "Sistema");
                    con.Close();

                    Document doc = new Document(PageSize.A5);
                    doc.SetMargins(3, 3, 3, 3);
                    doc.AddCreationDate();
                    string FileName = "recibo";

                    SaveFileDialog sf = new SaveFileDialog();
                    sf.FileName = FileName;

                    if (sf.ShowDialog() == DialogResult.OK)
                    {
                        savePath = Path.GetDirectoryName(sf.FileName);
                        savePath = savePath + "recibo.pdf";
                    }
                    PdfWriter writer = PdfWriter.GetInstance(doc, new FileStream(savePath, FileMode.Create));
                    doc.Open();

                    iTextSharp.text.Font titulo = FontFactory.GetFont("Lucida_Sans_Typewriter", 30f);
                    iTextSharp.text.Font texto = FontFactory.GetFont("Lucida_Sans_Typewriter", 20f);

                    String dados = "";
                    Paragraph paragrafo = new Paragraph(dados, titulo);
                    paragrafo.Alignment = Element.ALIGN_LEFT;
                    paragrafo.Add("Toolbox prestador\n________________________");
                    doc.Add(paragrafo);

                    Paragraph paragrafo2 = new Paragraph(dados, texto);
                    paragrafo2.Alignment = Element.ALIGN_LEFT;
                    paragrafo2.Add("Recibo                         " + DateTime.Now.ToString("dd/MM/yyyy") +" "+ DateTime.Now.ToString("H:mm:ss"));
                    doc.Add(paragrafo2);

                    try
                    {
                        con.Open();
                        MySqlCommand dadosP = new MySqlCommand("call myData('" + GlobalLogin.idprestador + "');", con);
                        MySqlDataReader resultado = dadosP.ExecuteReader();

                        if (resultado.Read())
                        {
                            Paragraph paragrafo3 = new Paragraph(dados, texto);
                            paragrafo3.Alignment = Element.ALIGN_LEFT;
                            paragrafo3.Add(resultado["desprovider"].ToString() + "\nCNPJ:" +resultado["descnpj"].ToString() + "\n--------------------------------------------------------------");
                            doc.Add(paragrafo3);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    con.Close();

                    Paragraph paragrafo4 = new Paragraph(dados, texto);
                    paragrafo4.Alignment = Element.ALIGN_LEFT;
                    paragrafo4.Add("Dinheiro na conta                   R$ " + qd+ "\n--------------------------------------------------------------\n" + bs+"\n"+"Agência "+textBoxAgencia.Text+ "                           Conta " + textBoxConta.Text + "\n--------------------------------------------------------------");
                    doc.Add(paragrafo4);

                    Paragraph paragrafo5 = new Paragraph(dados, texto);
                    paragrafo5.Alignment = Element.ALIGN_LEFT;
                    paragrafo5.Add("Valor total                                R$ "+textBoxValor.Text);
                    doc.Add(paragrafo5);

                    Paragraph paragrafo6 = new Paragraph(dados, titulo);
                    paragrafo6.Alignment = Element.ALIGN_LEFT;
                    paragrafo6.Add("________________________\n");
                    doc.Add(paragrafo6);

                    Paragraph paragrafo7 = new Paragraph(dados, texto);
                    paragrafo7.Alignment = Element.ALIGN_LEFT;
                    paragrafo7.Add("ToolBox\nAv. Paulista, 214 - Edifício Space, Bela Vista São Paulo-SP | 01311-100\n(11) 3440-4000             (11) 99440-4000\nsuporte@toolboxservico.space");
                    doc.Add(paragrafo7);

                    doc.Close();
                    System.Diagnostics.Process.Start(savePath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                con.Close();
            }
            textBoxAgencia.Clear();
            textBoxCNPJ.Clear();
            textBoxConta.Clear();
            textBoxSenha.Clear();
            textBoxValor.Clear();
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.BorderColor = Color.WhiteSmoke;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.BorderColor = Color.WhiteSmoke;

        }

        public static bool IsCnpj(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int soma;
            int resto;
            string digito;
            string tempCnpj;
            cnpj = cnpj.Trim();
            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");
            if (cnpj.Length != 14)
                return false;
            tempCnpj = cnpj.Substring(0, 12);
            soma = 0;
            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCnpj = tempCnpj + digito;
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            return cnpj.EndsWith(digito);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (f == 0)
            {
                textBoxSenha.PasswordChar = char.Parse("\0");
                f = 1;
                button1.BackColor = Color.Gainsboro;
            }
            else
            {
                textBoxSenha.PasswordChar = char.Parse("•");
                f = 0;
                button1.BackColor = Color.Transparent;
            }
        }

        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }
            return true;
        }
    }
}

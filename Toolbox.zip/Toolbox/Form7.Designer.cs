﻿namespace Toolbox
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.bRedefinirSenha = new System.Windows.Forms.Button();
            this.bALterarMeusDados = new System.Windows.Forms.Button();
            this.bMeusDados = new System.Windows.Forms.Button();
            this.bConfiguracao = new System.Windows.Forms.Button();
            this.bRetirarPagamento = new System.Windows.Forms.Button();
            this.bpedidos = new System.Windows.Forms.Button();
            this.bOrcamento = new System.Windows.Forms.Button();
            this.bCadastrarServico = new System.Windows.Forms.Button();
            this.bServicos = new System.Windows.Forms.Button();
            this.bHome = new System.Windows.Forms.Button();
            this.bSair = new System.Windows.Forms.Button();
            this.panelBemVindo = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.pictureBoxWelcome = new System.Windows.Forms.PictureBox();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.panelCadastro = new System.Windows.Forms.Panel();
            this.panelCentral = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxPais = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxContato = new System.Windows.Forms.TextBox();
            this.bEscolherFoto = new System.Windows.Forms.Button();
            this.pictureBoxCadastro = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxEstado = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxBairro = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxCidade = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxNumero = new System.Windows.Forms.TextBox();
            this.textBoxComplemento = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxCEP = new System.Windows.Forms.TextBox();
            this.textBoxRua = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxTelefone = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.textBoxCNPJ = new System.Windows.Forms.TextBox();
            this.bSalvar = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.panelSideMenu.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelBemVindo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).BeginInit();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.panelCadastro.SuspendLayout();
            this.panelCentral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCadastro)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.BackColor = System.Drawing.Color.White;
            this.panelSideMenu.Controls.Add(this.panelButtons);
            this.panelSideMenu.Controls.Add(this.bSair);
            this.panelSideMenu.Controls.Add(this.panelBemVindo);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(280, 681);
            this.panelSideMenu.TabIndex = 3;
            // 
            // panelButtons
            // 
            this.panelButtons.BackColor = System.Drawing.Color.White;
            this.panelButtons.Controls.Add(this.bRedefinirSenha);
            this.panelButtons.Controls.Add(this.bALterarMeusDados);
            this.panelButtons.Controls.Add(this.bMeusDados);
            this.panelButtons.Controls.Add(this.bConfiguracao);
            this.panelButtons.Controls.Add(this.bRetirarPagamento);
            this.panelButtons.Controls.Add(this.bpedidos);
            this.panelButtons.Controls.Add(this.bOrcamento);
            this.panelButtons.Controls.Add(this.bCadastrarServico);
            this.panelButtons.Controls.Add(this.bServicos);
            this.panelButtons.Controls.Add(this.bHome);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButtons.Location = new System.Drawing.Point(0, 151);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(280, 501);
            this.panelButtons.TabIndex = 13;
            // 
            // bRedefinirSenha
            // 
            this.bRedefinirSenha.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRedefinirSenha.FlatAppearance.BorderSize = 0;
            this.bRedefinirSenha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRedefinirSenha.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRedefinirSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRedefinirSenha.Image = ((System.Drawing.Image)(resources.GetObject("bRedefinirSenha.Image")));
            this.bRedefinirSenha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRedefinirSenha.Location = new System.Drawing.Point(0, 360);
            this.bRedefinirSenha.Name = "bRedefinirSenha";
            this.bRedefinirSenha.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bRedefinirSenha.Size = new System.Drawing.Size(280, 40);
            this.bRedefinirSenha.TabIndex = 10;
            this.bRedefinirSenha.Text = "  redefinir senha";
            this.bRedefinirSenha.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRedefinirSenha.UseVisualStyleBackColor = true;
            this.bRedefinirSenha.Click += new System.EventHandler(this.bRedefinirSenha_Click);
            // 
            // bALterarMeusDados
            // 
            this.bALterarMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bALterarMeusDados.FlatAppearance.BorderSize = 0;
            this.bALterarMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bALterarMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bALterarMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bALterarMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bALterarMeusDados.Image")));
            this.bALterarMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bALterarMeusDados.Location = new System.Drawing.Point(0, 320);
            this.bALterarMeusDados.Name = "bALterarMeusDados";
            this.bALterarMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bALterarMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bALterarMeusDados.TabIndex = 6;
            this.bALterarMeusDados.Text = "  alterar meus dados";
            this.bALterarMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bALterarMeusDados.UseVisualStyleBackColor = true;
            this.bALterarMeusDados.Click += new System.EventHandler(this.bALterarMeusDados_Click);
            // 
            // bMeusDados
            // 
            this.bMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bMeusDados.FlatAppearance.BorderSize = 0;
            this.bMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bMeusDados.Image")));
            this.bMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bMeusDados.Location = new System.Drawing.Point(0, 280);
            this.bMeusDados.Name = "bMeusDados";
            this.bMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bMeusDados.TabIndex = 9;
            this.bMeusDados.Text = "  meus dados";
            this.bMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bMeusDados.UseVisualStyleBackColor = true;
            this.bMeusDados.Click += new System.EventHandler(this.bMeusDados_Click);
            // 
            // bConfiguracao
            // 
            this.bConfiguracao.Dock = System.Windows.Forms.DockStyle.Top;
            this.bConfiguracao.FlatAppearance.BorderSize = 0;
            this.bConfiguracao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bConfiguracao.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bConfiguracao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bConfiguracao.Image = ((System.Drawing.Image)(resources.GetObject("bConfiguracao.Image")));
            this.bConfiguracao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bConfiguracao.Location = new System.Drawing.Point(0, 240);
            this.bConfiguracao.Name = "bConfiguracao";
            this.bConfiguracao.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bConfiguracao.Size = new System.Drawing.Size(280, 40);
            this.bConfiguracao.TabIndex = 3;
            this.bConfiguracao.Text = "  configurações";
            this.bConfiguracao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bConfiguracao.UseVisualStyleBackColor = true;
            this.bConfiguracao.Click += new System.EventHandler(this.bConfiguracao_Click);
            // 
            // bRetirarPagamento
            // 
            this.bRetirarPagamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRetirarPagamento.FlatAppearance.BorderSize = 0;
            this.bRetirarPagamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRetirarPagamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRetirarPagamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRetirarPagamento.Image = ((System.Drawing.Image)(resources.GetObject("bRetirarPagamento.Image")));
            this.bRetirarPagamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRetirarPagamento.Location = new System.Drawing.Point(0, 200);
            this.bRetirarPagamento.Name = "bRetirarPagamento";
            this.bRetirarPagamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bRetirarPagamento.Size = new System.Drawing.Size(280, 40);
            this.bRetirarPagamento.TabIndex = 8;
            this.bRetirarPagamento.Text = "  retirar pagamento";
            this.bRetirarPagamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRetirarPagamento.UseVisualStyleBackColor = true;
            this.bRetirarPagamento.Click += new System.EventHandler(this.bRetirarPagamento_Click);
            // 
            // bpedidos
            // 
            this.bpedidos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bpedidos.FlatAppearance.BorderSize = 0;
            this.bpedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bpedidos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bpedidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bpedidos.Image = ((System.Drawing.Image)(resources.GetObject("bpedidos.Image")));
            this.bpedidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bpedidos.Location = new System.Drawing.Point(0, 160);
            this.bpedidos.Name = "bpedidos";
            this.bpedidos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bpedidos.Size = new System.Drawing.Size(280, 40);
            this.bpedidos.TabIndex = 5;
            this.bpedidos.Text = "  pedidos";
            this.bpedidos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bpedidos.UseVisualStyleBackColor = true;
            this.bpedidos.Click += new System.EventHandler(this.bpedidos_Click);
            // 
            // bOrcamento
            // 
            this.bOrcamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bOrcamento.FlatAppearance.BorderSize = 0;
            this.bOrcamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOrcamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bOrcamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bOrcamento.Image = ((System.Drawing.Image)(resources.GetObject("bOrcamento.Image")));
            this.bOrcamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bOrcamento.Location = new System.Drawing.Point(0, 120);
            this.bOrcamento.Name = "bOrcamento";
            this.bOrcamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bOrcamento.Size = new System.Drawing.Size(280, 40);
            this.bOrcamento.TabIndex = 4;
            this.bOrcamento.Text = "  orçamentos";
            this.bOrcamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bOrcamento.UseVisualStyleBackColor = true;
            this.bOrcamento.Click += new System.EventHandler(this.bOrcamento_Click);
            // 
            // bCadastrarServico
            // 
            this.bCadastrarServico.BackColor = System.Drawing.Color.White;
            this.bCadastrarServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bCadastrarServico.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bCadastrarServico.Image = ((System.Drawing.Image)(resources.GetObject("bCadastrarServico.Image")));
            this.bCadastrarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCadastrarServico.Location = new System.Drawing.Point(0, 80);
            this.bCadastrarServico.Name = "bCadastrarServico";
            this.bCadastrarServico.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bCadastrarServico.Size = new System.Drawing.Size(280, 40);
            this.bCadastrarServico.TabIndex = 2;
            this.bCadastrarServico.Text = "  cadastrar serviço";
            this.bCadastrarServico.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bCadastrarServico.UseVisualStyleBackColor = false;
            this.bCadastrarServico.Click += new System.EventHandler(this.bCadastrarServico_Click);
            // 
            // bServicos
            // 
            this.bServicos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bServicos.FlatAppearance.BorderSize = 0;
            this.bServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bServicos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bServicos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bServicos.Image = ((System.Drawing.Image)(resources.GetObject("bServicos.Image")));
            this.bServicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bServicos.Location = new System.Drawing.Point(0, 40);
            this.bServicos.Name = "bServicos";
            this.bServicos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bServicos.Size = new System.Drawing.Size(280, 40);
            this.bServicos.TabIndex = 7;
            this.bServicos.Text = "  serviços";
            this.bServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bServicos.UseVisualStyleBackColor = true;
            this.bServicos.Click += new System.EventHandler(this.bServicos_Click);
            // 
            // bHome
            // 
            this.bHome.BackColor = System.Drawing.Color.Transparent;
            this.bHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.bHome.FlatAppearance.BorderSize = 0;
            this.bHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bHome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bHome.Image = ((System.Drawing.Image)(resources.GetObject("bHome.Image")));
            this.bHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.Location = new System.Drawing.Point(0, 0);
            this.bHome.Name = "bHome";
            this.bHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bHome.Size = new System.Drawing.Size(280, 40);
            this.bHome.TabIndex = 1;
            this.bHome.Text = "  home";
            this.bHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bHome.UseVisualStyleBackColor = false;
            this.bHome.Click += new System.EventHandler(this.bHome_Click);
            // 
            // bSair
            // 
            this.bSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bSair.Location = new System.Drawing.Point(0, 652);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(280, 29);
            this.bSair.TabIndex = 6;
            this.bSair.Text = "sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bSair.UseVisualStyleBackColor = true;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // panelBemVindo
            // 
            this.panelBemVindo.Controls.Add(this.labelWelcome);
            this.panelBemVindo.Controls.Add(this.pictureBoxWelcome);
            this.panelBemVindo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBemVindo.Location = new System.Drawing.Point(0, 86);
            this.panelBemVindo.Name = "panelBemVindo";
            this.panelBemVindo.Size = new System.Drawing.Size(280, 65);
            this.panelBemVindo.TabIndex = 1;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.labelWelcome.Location = new System.Drawing.Point(59, 24);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(105, 25);
            this.labelWelcome.TabIndex = 1;
            this.labelWelcome.Text = "bem vindo,";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxWelcome
            // 
            this.pictureBoxWelcome.Location = new System.Drawing.Point(21, 15);
            this.pictureBoxWelcome.Name = "pictureBoxWelcome";
            this.pictureBoxWelcome.Size = new System.Drawing.Size(34, 34);
            this.pictureBoxWelcome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxWelcome.TabIndex = 0;
            this.pictureBoxWelcome.TabStop = false;
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelLogo.Controls.Add(this.pictureBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.panelLogo.Size = new System.Drawing.Size(280, 86);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogo.ErrorImage = null;
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.InitialImage = null;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 5);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(280, 86);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // panelCadastro
            // 
            this.panelCadastro.BackColor = System.Drawing.Color.White;
            this.panelCadastro.Controls.Add(this.panelCentral);
            this.panelCadastro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCadastro.Location = new System.Drawing.Point(280, 0);
            this.panelCadastro.Name = "panelCadastro";
            this.panelCadastro.Size = new System.Drawing.Size(1074, 681);
            this.panelCadastro.TabIndex = 38;
            // 
            // panelCentral
            // 
            this.panelCentral.Controls.Add(this.label16);
            this.panelCentral.Controls.Add(this.textBoxPais);
            this.panelCentral.Controls.Add(this.label15);
            this.panelCentral.Controls.Add(this.label14);
            this.panelCentral.Controls.Add(this.textBoxContato);
            this.panelCentral.Controls.Add(this.bEscolherFoto);
            this.panelCentral.Controls.Add(this.pictureBoxCadastro);
            this.panelCentral.Controls.Add(this.label5);
            this.panelCentral.Controls.Add(this.textBoxEstado);
            this.panelCentral.Controls.Add(this.label6);
            this.panelCentral.Controls.Add(this.textBoxBairro);
            this.panelCentral.Controls.Add(this.label12);
            this.panelCentral.Controls.Add(this.textBoxCidade);
            this.panelCentral.Controls.Add(this.label9);
            this.panelCentral.Controls.Add(this.label10);
            this.panelCentral.Controls.Add(this.textBoxNumero);
            this.panelCentral.Controls.Add(this.textBoxComplemento);
            this.panelCentral.Controls.Add(this.label7);
            this.panelCentral.Controls.Add(this.label8);
            this.panelCentral.Controls.Add(this.textBoxCEP);
            this.panelCentral.Controls.Add(this.textBoxRua);
            this.panelCentral.Controls.Add(this.label3);
            this.panelCentral.Controls.Add(this.label4);
            this.panelCentral.Controls.Add(this.textBoxTelefone);
            this.panelCentral.Controls.Add(this.textBoxNome);
            this.panelCentral.Controls.Add(this.label2);
            this.panelCentral.Controls.Add(this.label1);
            this.panelCentral.Controls.Add(this.textBoxUsername);
            this.panelCentral.Controls.Add(this.textBoxCNPJ);
            this.panelCentral.Controls.Add(this.bSalvar);
            this.panelCentral.Controls.Add(this.label11);
            this.panelCentral.Location = new System.Drawing.Point(24, 24);
            this.panelCentral.Name = "panelCentral";
            this.panelCentral.Size = new System.Drawing.Size(1038, 657);
            this.panelCentral.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label16.Location = new System.Drawing.Point(24, 456);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 25);
            this.label16.TabIndex = 152;
            this.label16.Text = "país";
            // 
            // textBoxPais
            // 
            this.textBoxPais.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxPais.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxPais.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxPais.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxPais.Location = new System.Drawing.Point(29, 484);
            this.textBoxPais.Name = "textBoxPais";
            this.textBoxPais.ReadOnly = true;
            this.textBoxPais.Size = new System.Drawing.Size(201, 32);
            this.textBoxPais.TabIndex = 151;
            this.textBoxPais.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label15.Location = new System.Drawing.Point(796, 88);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 25);
            this.label15.TabIndex = 150;
            this.label15.Text = "imagem";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label14.Location = new System.Drawing.Point(410, 161);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(170, 25);
            this.label14.TabIndex = 149;
            this.label14.Text = "email para contato";
            // 
            // textBoxContato
            // 
            this.textBoxContato.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxContato.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxContato.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxContato.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxContato.Location = new System.Drawing.Point(415, 189);
            this.textBoxContato.Name = "textBoxContato";
            this.textBoxContato.Size = new System.Drawing.Size(365, 32);
            this.textBoxContato.TabIndex = 148;
            this.textBoxContato.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxContato_KeyDown);
            // 
            // bEscolherFoto
            // 
            this.bEscolherFoto.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bEscolherFoto.FlatAppearance.BorderSize = 0;
            this.bEscolherFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bEscolherFoto.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bEscolherFoto.ForeColor = System.Drawing.Color.Black;
            this.bEscolherFoto.Location = new System.Drawing.Point(801, 337);
            this.bEscolherFoto.Name = "bEscolherFoto";
            this.bEscolherFoto.Size = new System.Drawing.Size(204, 41);
            this.bEscolherFoto.TabIndex = 147;
            this.bEscolherFoto.Text = "escolher imagem";
            this.bEscolherFoto.UseVisualStyleBackColor = false;
            this.bEscolherFoto.Click += new System.EventHandler(this.bEscolherFoto_Click);
            // 
            // pictureBoxCadastro
            // 
            this.pictureBoxCadastro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBoxCadastro.Location = new System.Drawing.Point(801, 116);
            this.pictureBoxCadastro.Name = "pictureBoxCadastro";
            this.pictureBoxCadastro.Size = new System.Drawing.Size(204, 198);
            this.pictureBoxCadastro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCadastro.TabIndex = 146;
            this.pictureBoxCadastro.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label5.Location = new System.Drawing.Point(231, 456);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 25);
            this.label5.TabIndex = 145;
            this.label5.Text = "estado";
            // 
            // textBoxEstado
            // 
            this.textBoxEstado.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxEstado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxEstado.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxEstado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxEstado.Location = new System.Drawing.Point(236, 484);
            this.textBoxEstado.MaxLength = 2;
            this.textBoxEstado.Name = "textBoxEstado";
            this.textBoxEstado.ReadOnly = true;
            this.textBoxEstado.Size = new System.Drawing.Size(158, 32);
            this.textBoxEstado.TabIndex = 144;
            this.textBoxEstado.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label6.Location = new System.Drawing.Point(414, 387);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 25);
            this.label6.TabIndex = 143;
            this.label6.Text = "bairro";
            // 
            // textBoxBairro
            // 
            this.textBoxBairro.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxBairro.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxBairro.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxBairro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxBairro.Location = new System.Drawing.Point(415, 415);
            this.textBoxBairro.Name = "textBoxBairro";
            this.textBoxBairro.ReadOnly = true;
            this.textBoxBairro.Size = new System.Drawing.Size(365, 32);
            this.textBoxBairro.TabIndex = 142;
            this.textBoxBairro.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label12.Location = new System.Drawing.Point(410, 318);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 25);
            this.label12.TabIndex = 141;
            this.label12.Text = "cidade";
            // 
            // textBoxCidade
            // 
            this.textBoxCidade.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxCidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCidade.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCidade.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxCidade.Location = new System.Drawing.Point(415, 346);
            this.textBoxCidade.Name = "textBoxCidade";
            this.textBoxCidade.ReadOnly = true;
            this.textBoxCidade.Size = new System.Drawing.Size(365, 32);
            this.textBoxCidade.TabIndex = 140;
            this.textBoxCidade.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label9.Location = new System.Drawing.Point(231, 318);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 25);
            this.label9.TabIndex = 139;
            this.label9.Text = "número";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label10.Location = new System.Drawing.Point(410, 456);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 25);
            this.label10.TabIndex = 138;
            this.label10.Text = "complemento";
            // 
            // textBoxNumero
            // 
            this.textBoxNumero.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxNumero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxNumero.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxNumero.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxNumero.Location = new System.Drawing.Point(236, 346);
            this.textBoxNumero.MaxLength = 5;
            this.textBoxNumero.Name = "textBoxNumero";
            this.textBoxNumero.Size = new System.Drawing.Size(158, 32);
            this.textBoxNumero.TabIndex = 137;
            this.textBoxNumero.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxNumero_KeyDown);
            // 
            // textBoxComplemento
            // 
            this.textBoxComplemento.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxComplemento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxComplemento.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxComplemento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxComplemento.Location = new System.Drawing.Point(415, 484);
            this.textBoxComplemento.Name = "textBoxComplemento";
            this.textBoxComplemento.Size = new System.Drawing.Size(365, 32);
            this.textBoxComplemento.TabIndex = 136;
            this.textBoxComplemento.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxComplemento_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label7.Location = new System.Drawing.Point(24, 318);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 25);
            this.label7.TabIndex = 135;
            this.label7.Text = "cep";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label8.Location = new System.Drawing.Point(24, 387);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 25);
            this.label8.TabIndex = 134;
            this.label8.Text = "endereço";
            // 
            // textBoxCEP
            // 
            this.textBoxCEP.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCEP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCEP.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCEP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxCEP.Location = new System.Drawing.Point(29, 346);
            this.textBoxCEP.MaxLength = 8;
            this.textBoxCEP.Name = "textBoxCEP";
            this.textBoxCEP.Size = new System.Drawing.Size(201, 32);
            this.textBoxCEP.TabIndex = 133;
            this.textBoxCEP.TextChanged += new System.EventHandler(this.textBoxCEP_TextChanged);
            this.textBoxCEP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCEP_KeyDown);
            // 
            // textBoxRua
            // 
            this.textBoxRua.BackColor = System.Drawing.Color.Gainsboro;
            this.textBoxRua.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxRua.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxRua.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxRua.Location = new System.Drawing.Point(29, 415);
            this.textBoxRua.Name = "textBoxRua";
            this.textBoxRua.ReadOnly = true;
            this.textBoxRua.Size = new System.Drawing.Size(365, 32);
            this.textBoxRua.TabIndex = 132;
            this.textBoxRua.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label3.Location = new System.Drawing.Point(24, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 25);
            this.label3.TabIndex = 131;
            this.label3.Text = "telefone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label4.Location = new System.Drawing.Point(24, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 25);
            this.label4.TabIndex = 130;
            this.label4.Text = "nome";
            // 
            // textBoxTelefone
            // 
            this.textBoxTelefone.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxTelefone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTelefone.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxTelefone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxTelefone.Location = new System.Drawing.Point(29, 184);
            this.textBoxTelefone.MaxLength = 13;
            this.textBoxTelefone.Name = "textBoxTelefone";
            this.textBoxTelefone.Size = new System.Drawing.Size(365, 32);
            this.textBoxTelefone.TabIndex = 129;
            this.textBoxTelefone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxTelefone_KeyDown);
            // 
            // textBoxNome
            // 
            this.textBoxNome.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxNome.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxNome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxNome.Location = new System.Drawing.Point(29, 116);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(365, 32);
            this.textBoxNome.TabIndex = 124;
            this.textBoxNome.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxNome_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label2.Location = new System.Drawing.Point(24, 224);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 25);
            this.label2.TabIndex = 128;
            this.label2.Text = "email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label1.Location = new System.Drawing.Point(410, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 25);
            this.label1.TabIndex = 127;
            this.label1.Text = "cnpj";
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxUsername.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxUsername.Location = new System.Drawing.Point(29, 252);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(365, 32);
            this.textBoxUsername.TabIndex = 126;
            this.textBoxUsername.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxUsername_KeyDown);
            // 
            // textBoxCNPJ
            // 
            this.textBoxCNPJ.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCNPJ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCNPJ.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCNPJ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxCNPJ.Location = new System.Drawing.Point(415, 116);
            this.textBoxCNPJ.MaxLength = 14;
            this.textBoxCNPJ.Name = "textBoxCNPJ";
            this.textBoxCNPJ.Size = new System.Drawing.Size(365, 32);
            this.textBoxCNPJ.TabIndex = 125;
            this.textBoxCNPJ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxCNPJ_KeyDown);
            // 
            // bSalvar
            // 
            this.bSalvar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bSalvar.FlatAppearance.BorderSize = 0;
            this.bSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSalvar.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bSalvar.ForeColor = System.Drawing.Color.White;
            this.bSalvar.Location = new System.Drawing.Point(781, 604);
            this.bSalvar.Name = "bSalvar";
            this.bSalvar.Size = new System.Drawing.Size(224, 40);
            this.bSalvar.TabIndex = 123;
            this.bSalvar.Text = "Alterar";
            this.bSalvar.UseVisualStyleBackColor = false;
            this.bSalvar.Click += new System.EventHandler(this.bSalvar_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label11.Location = new System.Drawing.Point(28, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(267, 37);
            this.label11.TabIndex = 122;
            this.label11.Text = "Alterar meus dados";
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1354, 681);
            this.Controls.Add(this.panelCadastro);
            this.Controls.Add(this.panelSideMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alterar meus dados";
            this.Load += new System.EventHandler(this.Form7_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelButtons.ResumeLayout(false);
            this.panelBemVindo.ResumeLayout(false);
            this.panelBemVindo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).EndInit();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.panelCadastro.ResumeLayout(false);
            this.panelCentral.ResumeLayout(false);
            this.panelCentral.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCadastro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Panel panelBemVindo;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.PictureBox pictureBoxWelcome;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Panel panelCadastro;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button bRedefinirSenha;
        private System.Windows.Forms.Button bALterarMeusDados;
        private System.Windows.Forms.Button bMeusDados;
        private System.Windows.Forms.Button bConfiguracao;
        private System.Windows.Forms.Button bRetirarPagamento;
        private System.Windows.Forms.Button bpedidos;
        private System.Windows.Forms.Button bOrcamento;
        private System.Windows.Forms.Button bCadastrarServico;
        private System.Windows.Forms.Button bServicos;
        private System.Windows.Forms.Button bHome;
        private System.Windows.Forms.Panel panelCentral;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxPais;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxContato;
        private System.Windows.Forms.Button bEscolherFoto;
        private System.Windows.Forms.PictureBox pictureBoxCadastro;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxEstado;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxBairro;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxCidade;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxNumero;
        private System.Windows.Forms.TextBox textBoxComplemento;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxCEP;
        private System.Windows.Forms.TextBox textBoxRua;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxTelefone;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.TextBox textBoxCNPJ;
        private System.Windows.Forms.Button bSalvar;
        private System.Windows.Forms.Label label11;
    }
}
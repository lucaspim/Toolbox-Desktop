﻿namespace Toolbox
{
    partial class Form11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form11));
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.bRedefinirSenha = new System.Windows.Forms.Button();
            this.bALterarMeusDados = new System.Windows.Forms.Button();
            this.bMeusDados = new System.Windows.Forms.Button();
            this.bConfiguracao = new System.Windows.Forms.Button();
            this.bRetirarPagamento = new System.Windows.Forms.Button();
            this.bpedidos = new System.Windows.Forms.Button();
            this.bOrcamento = new System.Windows.Forms.Button();
            this.bCadastrarServico = new System.Windows.Forms.Button();
            this.bServicos = new System.Windows.Forms.Button();
            this.bHome = new System.Windows.Forms.Button();
            this.bSair = new System.Windows.Forms.Button();
            this.panelBemVindo = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.pictureBoxWelcome = new System.Windows.Forms.PictureBox();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxSA = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxSNR = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxSN = new System.Windows.Forms.TextBox();
            this.bAltsen = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panelSideMenu.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelBemVindo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).BeginInit();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.BackColor = System.Drawing.Color.White;
            this.panelSideMenu.Controls.Add(this.panelButtons);
            this.panelSideMenu.Controls.Add(this.bSair);
            this.panelSideMenu.Controls.Add(this.panelBemVindo);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(280, 681);
            this.panelSideMenu.TabIndex = 5;
            // 
            // panelButtons
            // 
            this.panelButtons.BackColor = System.Drawing.Color.White;
            this.panelButtons.Controls.Add(this.bRedefinirSenha);
            this.panelButtons.Controls.Add(this.bALterarMeusDados);
            this.panelButtons.Controls.Add(this.bMeusDados);
            this.panelButtons.Controls.Add(this.bConfiguracao);
            this.panelButtons.Controls.Add(this.bRetirarPagamento);
            this.panelButtons.Controls.Add(this.bpedidos);
            this.panelButtons.Controls.Add(this.bOrcamento);
            this.panelButtons.Controls.Add(this.bCadastrarServico);
            this.panelButtons.Controls.Add(this.bServicos);
            this.panelButtons.Controls.Add(this.bHome);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButtons.Location = new System.Drawing.Point(0, 151);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(280, 501);
            this.panelButtons.TabIndex = 13;
            // 
            // bRedefinirSenha
            // 
            this.bRedefinirSenha.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRedefinirSenha.FlatAppearance.BorderSize = 0;
            this.bRedefinirSenha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRedefinirSenha.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRedefinirSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRedefinirSenha.Image = ((System.Drawing.Image)(resources.GetObject("bRedefinirSenha.Image")));
            this.bRedefinirSenha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRedefinirSenha.Location = new System.Drawing.Point(0, 360);
            this.bRedefinirSenha.Name = "bRedefinirSenha";
            this.bRedefinirSenha.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bRedefinirSenha.Size = new System.Drawing.Size(280, 40);
            this.bRedefinirSenha.TabIndex = 10;
            this.bRedefinirSenha.Text = "  redefinir senha";
            this.bRedefinirSenha.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRedefinirSenha.UseVisualStyleBackColor = true;
            this.bRedefinirSenha.Click += new System.EventHandler(this.bRedefinirSenha_Click);
            // 
            // bALterarMeusDados
            // 
            this.bALterarMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bALterarMeusDados.FlatAppearance.BorderSize = 0;
            this.bALterarMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bALterarMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bALterarMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bALterarMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bALterarMeusDados.Image")));
            this.bALterarMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bALterarMeusDados.Location = new System.Drawing.Point(0, 320);
            this.bALterarMeusDados.Name = "bALterarMeusDados";
            this.bALterarMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bALterarMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bALterarMeusDados.TabIndex = 6;
            this.bALterarMeusDados.Text = "  alterar meus dados";
            this.bALterarMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bALterarMeusDados.UseVisualStyleBackColor = true;
            this.bALterarMeusDados.Click += new System.EventHandler(this.bALterarMeusDados_Click);
            // 
            // bMeusDados
            // 
            this.bMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bMeusDados.FlatAppearance.BorderSize = 0;
            this.bMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bMeusDados.Image")));
            this.bMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bMeusDados.Location = new System.Drawing.Point(0, 280);
            this.bMeusDados.Name = "bMeusDados";
            this.bMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bMeusDados.TabIndex = 9;
            this.bMeusDados.Text = "  meus dados";
            this.bMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bMeusDados.UseVisualStyleBackColor = true;
            this.bMeusDados.Click += new System.EventHandler(this.bMeusDados_Click);
            // 
            // bConfiguracao
            // 
            this.bConfiguracao.Dock = System.Windows.Forms.DockStyle.Top;
            this.bConfiguracao.FlatAppearance.BorderSize = 0;
            this.bConfiguracao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bConfiguracao.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bConfiguracao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bConfiguracao.Image = ((System.Drawing.Image)(resources.GetObject("bConfiguracao.Image")));
            this.bConfiguracao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bConfiguracao.Location = new System.Drawing.Point(0, 240);
            this.bConfiguracao.Name = "bConfiguracao";
            this.bConfiguracao.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bConfiguracao.Size = new System.Drawing.Size(280, 40);
            this.bConfiguracao.TabIndex = 3;
            this.bConfiguracao.Text = "  configurações";
            this.bConfiguracao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bConfiguracao.UseVisualStyleBackColor = true;
            this.bConfiguracao.Click += new System.EventHandler(this.bConfiguracao_Click);
            // 
            // bRetirarPagamento
            // 
            this.bRetirarPagamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRetirarPagamento.FlatAppearance.BorderSize = 0;
            this.bRetirarPagamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRetirarPagamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRetirarPagamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRetirarPagamento.Image = ((System.Drawing.Image)(resources.GetObject("bRetirarPagamento.Image")));
            this.bRetirarPagamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRetirarPagamento.Location = new System.Drawing.Point(0, 200);
            this.bRetirarPagamento.Name = "bRetirarPagamento";
            this.bRetirarPagamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bRetirarPagamento.Size = new System.Drawing.Size(280, 40);
            this.bRetirarPagamento.TabIndex = 8;
            this.bRetirarPagamento.Text = "  retirar pagamento";
            this.bRetirarPagamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRetirarPagamento.UseVisualStyleBackColor = true;
            this.bRetirarPagamento.Click += new System.EventHandler(this.bRetirarPagamento_Click);
            // 
            // bpedidos
            // 
            this.bpedidos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bpedidos.FlatAppearance.BorderSize = 0;
            this.bpedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bpedidos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bpedidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bpedidos.Image = ((System.Drawing.Image)(resources.GetObject("bpedidos.Image")));
            this.bpedidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bpedidos.Location = new System.Drawing.Point(0, 160);
            this.bpedidos.Name = "bpedidos";
            this.bpedidos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bpedidos.Size = new System.Drawing.Size(280, 40);
            this.bpedidos.TabIndex = 5;
            this.bpedidos.Text = "  pedidos";
            this.bpedidos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bpedidos.UseVisualStyleBackColor = true;
            this.bpedidos.Click += new System.EventHandler(this.bpedidos_Click);
            // 
            // bOrcamento
            // 
            this.bOrcamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bOrcamento.FlatAppearance.BorderSize = 0;
            this.bOrcamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOrcamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bOrcamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bOrcamento.Image = ((System.Drawing.Image)(resources.GetObject("bOrcamento.Image")));
            this.bOrcamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bOrcamento.Location = new System.Drawing.Point(0, 120);
            this.bOrcamento.Name = "bOrcamento";
            this.bOrcamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bOrcamento.Size = new System.Drawing.Size(280, 40);
            this.bOrcamento.TabIndex = 4;
            this.bOrcamento.Text = "  orçamentos";
            this.bOrcamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bOrcamento.UseVisualStyleBackColor = true;
            this.bOrcamento.Click += new System.EventHandler(this.bOrcamento_Click);
            // 
            // bCadastrarServico
            // 
            this.bCadastrarServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bCadastrarServico.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bCadastrarServico.Image = ((System.Drawing.Image)(resources.GetObject("bCadastrarServico.Image")));
            this.bCadastrarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCadastrarServico.Location = new System.Drawing.Point(0, 80);
            this.bCadastrarServico.Name = "bCadastrarServico";
            this.bCadastrarServico.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bCadastrarServico.Size = new System.Drawing.Size(280, 40);
            this.bCadastrarServico.TabIndex = 2;
            this.bCadastrarServico.Text = "  cadastrar serviço";
            this.bCadastrarServico.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bCadastrarServico.UseVisualStyleBackColor = true;
            this.bCadastrarServico.Click += new System.EventHandler(this.bCadastrarServico_Click);
            // 
            // bServicos
            // 
            this.bServicos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bServicos.FlatAppearance.BorderSize = 0;
            this.bServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bServicos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bServicos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bServicos.Image = ((System.Drawing.Image)(resources.GetObject("bServicos.Image")));
            this.bServicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bServicos.Location = new System.Drawing.Point(0, 40);
            this.bServicos.Name = "bServicos";
            this.bServicos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bServicos.Size = new System.Drawing.Size(280, 40);
            this.bServicos.TabIndex = 7;
            this.bServicos.Text = "  serviços";
            this.bServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bServicos.UseVisualStyleBackColor = true;
            this.bServicos.Click += new System.EventHandler(this.bServicos_Click);
            // 
            // bHome
            // 
            this.bHome.BackColor = System.Drawing.Color.Transparent;
            this.bHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.bHome.FlatAppearance.BorderSize = 0;
            this.bHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bHome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bHome.Image = ((System.Drawing.Image)(resources.GetObject("bHome.Image")));
            this.bHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.Location = new System.Drawing.Point(0, 0);
            this.bHome.Name = "bHome";
            this.bHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bHome.Size = new System.Drawing.Size(280, 40);
            this.bHome.TabIndex = 1;
            this.bHome.Text = "  home";
            this.bHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bHome.UseVisualStyleBackColor = false;
            this.bHome.Click += new System.EventHandler(this.bHome_Click);
            // 
            // bSair
            // 
            this.bSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bSair.Location = new System.Drawing.Point(0, 652);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(280, 29);
            this.bSair.TabIndex = 6;
            this.bSair.Text = "sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bSair.UseVisualStyleBackColor = true;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // panelBemVindo
            // 
            this.panelBemVindo.Controls.Add(this.labelWelcome);
            this.panelBemVindo.Controls.Add(this.pictureBoxWelcome);
            this.panelBemVindo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBemVindo.Location = new System.Drawing.Point(0, 86);
            this.panelBemVindo.Name = "panelBemVindo";
            this.panelBemVindo.Size = new System.Drawing.Size(280, 65);
            this.panelBemVindo.TabIndex = 1;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.labelWelcome.Location = new System.Drawing.Point(59, 24);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(105, 25);
            this.labelWelcome.TabIndex = 1;
            this.labelWelcome.Text = "bem vindo,";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxWelcome
            // 
            this.pictureBoxWelcome.Location = new System.Drawing.Point(21, 15);
            this.pictureBoxWelcome.Name = "pictureBoxWelcome";
            this.pictureBoxWelcome.Size = new System.Drawing.Size(34, 34);
            this.pictureBoxWelcome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxWelcome.TabIndex = 0;
            this.pictureBoxWelcome.TabStop = false;
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelLogo.Controls.Add(this.pictureBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.panelLogo.Size = new System.Drawing.Size(280, 86);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogo.ErrorImage = null;
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.InitialImage = null;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 5);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(280, 86);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label11.Location = new System.Drawing.Point(359, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(215, 37);
            this.label11.TabIndex = 63;
            this.label11.Text = "Redefinir senha";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label4.Location = new System.Drawing.Point(361, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 25);
            this.label4.TabIndex = 62;
            this.label4.Text = "Senha atual";
            // 
            // textBoxSA
            // 
            this.textBoxSA.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxSA.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSA.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxSA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxSA.Location = new System.Drawing.Point(366, 211);
            this.textBoxSA.Name = "textBoxSA";
            this.textBoxSA.PasswordChar = '•';
            this.textBoxSA.Size = new System.Drawing.Size(736, 32);
            this.textBoxSA.TabIndex = 61;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label1.Location = new System.Drawing.Point(732, 265);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 25);
            this.label1.TabIndex = 65;
            this.label1.Text = "Repita a nova senha";
            // 
            // textBoxSNR
            // 
            this.textBoxSNR.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxSNR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSNR.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxSNR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxSNR.Location = new System.Drawing.Point(737, 293);
            this.textBoxSNR.Name = "textBoxSNR";
            this.textBoxSNR.PasswordChar = '•';
            this.textBoxSNR.Size = new System.Drawing.Size(365, 32);
            this.textBoxSNR.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label2.Location = new System.Drawing.Point(361, 265);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 25);
            this.label2.TabIndex = 67;
            this.label2.Text = "Nova Senha";
            // 
            // textBoxSN
            // 
            this.textBoxSN.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxSN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSN.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxSN.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.textBoxSN.Location = new System.Drawing.Point(366, 293);
            this.textBoxSN.Name = "textBoxSN";
            this.textBoxSN.PasswordChar = '•';
            this.textBoxSN.Size = new System.Drawing.Size(365, 32);
            this.textBoxSN.TabIndex = 66;
            // 
            // bAltsen
            // 
            this.bAltsen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.bAltsen.FlatAppearance.BorderSize = 0;
            this.bAltsen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bAltsen.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bAltsen.ForeColor = System.Drawing.Color.White;
            this.bAltsen.Location = new System.Drawing.Point(366, 348);
            this.bAltsen.Name = "bAltsen";
            this.bAltsen.Size = new System.Drawing.Size(204, 40);
            this.bAltsen.TabIndex = 68;
            this.bAltsen.Text = "Alterar senha";
            this.bAltsen.UseVisualStyleBackColor = false;
            this.bAltsen.Click += new System.EventHandler(this.bAltsen_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(576, 348);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 40);
            this.button1.TabIndex = 69;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bAltsen);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxSN);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxSNR);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxSA);
            this.Controls.Add(this.panelSideMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form11";
            this.Text = "Redefinir Senha";
            this.Load += new System.EventHandler(this.Form11_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelButtons.ResumeLayout(false);
            this.panelBemVindo.ResumeLayout(false);
            this.panelBemVindo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).EndInit();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button bRedefinirSenha;
        private System.Windows.Forms.Button bALterarMeusDados;
        private System.Windows.Forms.Button bMeusDados;
        private System.Windows.Forms.Button bConfiguracao;
        private System.Windows.Forms.Button bRetirarPagamento;
        private System.Windows.Forms.Button bpedidos;
        private System.Windows.Forms.Button bOrcamento;
        private System.Windows.Forms.Button bCadastrarServico;
        private System.Windows.Forms.Button bServicos;
        private System.Windows.Forms.Button bHome;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Panel panelBemVindo;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.PictureBox pictureBoxWelcome;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxSA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxSNR;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxSN;
        private System.Windows.Forms.Button bAltsen;
        private System.Windows.Forms.Button button1;
    }
}
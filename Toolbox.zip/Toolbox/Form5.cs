﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;

namespace Toolbox
{
    public partial class Form5 : Form
    {
        MySqlConnection con;
        Thread nt;
        char i = '0';
        public Form5()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            bMeusDados.BackColor = Color.FromArgb(40, 131, 238);
            bMeusDados.ForeColor = Color.White;
            panelCentral.Location = new Point((this.Size.Width / 2 - panelCentral.Size.Width / 2) - 250, (this.Size.Height / 2 - panelCentral.Size.Height / 2) - 100);
            panelCentral.Anchor = AnchorStyles.None;
            bMeusDados.Visible = true;
            bALterarMeusDados.Visible = true;
            bRedefinirSenha.Visible = true;

            try
            {
                con.Open();
                MySqlCommand logado = new MySqlCommand("select imguserprovider,desprovider from tb_userprovider inner join tb_providers where tb_userprovider.idprovider ='" + GlobalLogin.idprestador + "' and tb_providers.idprovider = '" + GlobalLogin.idprestador + "';", con);
                MySqlDataReader resultado = logado.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["desprovider"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand meusDados = new MySqlCommand("call myData('" + GlobalLogin.idprestador + "');", con);
                MySqlDataReader resultado = meusDados.ExecuteReader();

                if (resultado.Read())
                {
                    textBoxCNPJ.Text = resultado["descnpj"].ToString();
                    textBoxUsername.Text = resultado["deslogin"].ToString();
                    textBoxTelefone.Text =  resultado["nrphone"].ToString();
                    textBoxNome.Text = resultado["desprovider"].ToString();
                    textBoxEstado.Text =  resultado["desstate"].ToString();
                    textBoxBairro.Text = resultado["desneighborhood"].ToString();
                    textBoxCEP.Text = resultado["deszipcode"].ToString();
                    textBoxRua.Text = resultado["desaddress"].ToString();
                    textBoxNumero.Text = resultado["desnumber"].ToString();
                    textBoxComplemento.Text = resultado["descomplement"].ToString();
                    textBoxCidade.Text =resultado["descity"].ToString();
                    textBoxContato.Text = resultado["desemail"].ToString();
                    textBoxPais.Text = resultado["descountry"].ToString();
                    labeldata.Text = "Desde "+Convert.ToDateTime(resultado["dtregister"].ToString()).ToString("dd/MM/yyyy");

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxMeusDados.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand classi = new MySqlCommand("select COUNT(idorder) as id from tb_orders inner join tb_quotes where tb_orders.idquote = tb_quotes.idquote and tb_orders.idstatus = 8 and tb_quotes.idprovider = '" + GlobalLogin.idprestador + "';", con);
                MySqlDataReader resultado = classi.ExecuteReader();

                if (resultado.Read())
                {
                    int pedconc = int.Parse(resultado["id"].ToString());

                    if (pedconc < 100)
                    {
                        pictureBox2.Image = Image.FromFile("bronze.png");
                        labelclas.Text = "Bronze";
                    }
                    if (pedconc >= 100 && pedconc < 250)
                    {
                        pictureBox2.Image = Image.FromFile("silver.png");
                        labelclas.Text = "Silver";
                    }
                    if (pedconc >= 250 && pedconc < 500)
                    {
                        pictureBox2.Image = Image.FromFile("gold.png");
                        labelclas.Text = "Gold";
                    }
                    if (pedconc >= 500 && pedconc < 750)
                    {
                        pictureBox2.Image = Image.FromFile("platinum.png");
                        labelclas.Text = "Platinum";
                    }
                    if (pedconc >= 750)
                    {
                        pictureBox2.Image = Image.FromFile("premium.png");
                        labelclas.Text = "Premium";
                    }
                }
                else
                    MessageBox.Show("Erro.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand stars = new MySqlCommand("select AVG(rating) as rating from tb_servicesprovider where rating != 0 and idprovider = '" + GlobalLogin.idprestador + "';", con);
                MySqlDataReader resultado = stars.ExecuteReader();

                if (resultado.Read())
                {
                    if (resultado["rating"].ToString() == null || resultado["rating"].ToString() == "")
                    {
                        i = '0';
                    }
                    else
                    {
                        i = resultado["rating"].ToString()[0];
                    }

                    if (i == '0')
                    {
                        star1.Image = Image.FromFile("starza.png");
                        star2.Image = Image.FromFile("starza.png");
                        star3.Image = Image.FromFile("starza.png");
                        star4.Image = Image.FromFile("starza.png");
                        star5.Image = Image.FromFile("starza.png");
                    }
                    else
                    {
                        if (i == '1')
                        {
                            star1.Image = Image.FromFile("starzul.png");
                            star2.Image = Image.FromFile("starza.png");
                            star3.Image = Image.FromFile("starza.png");
                            star4.Image = Image.FromFile("starza.png");
                            star5.Image = Image.FromFile("starza.png");
                        }
                        if (i == '2')
                        {
                            star1.Image = Image.FromFile("starzul.png");
                            star2.Image = Image.FromFile("starzul.png");
                            star3.Image = Image.FromFile("starza.png");
                            star4.Image = Image.FromFile("starza.png");
                            star5.Image = Image.FromFile("starza.png");
                        }
                        if (i == '3')
                        {
                            star1.Image = Image.FromFile("starzul.png");
                            star2.Image = Image.FromFile("starzul.png");
                            star3.Image = Image.FromFile("starzul.png");
                            star4.Image = Image.FromFile("starza.png");
                            star5.Image = Image.FromFile("starza.png");
                        }
                        if (i == '4')
                        {
                            star1.Image = Image.FromFile("starzul.png");
                            star2.Image = Image.FromFile("starzul.png");
                            star3.Image = Image.FromFile("starzul.png");
                            star4.Image = Image.FromFile("starzul.png");
                            star5.Image = Image.FromFile("starza.png");
                        }
                        if (i == '5')
                        {
                            star1.Image = Image.FromFile("starzul.png");
                            star2.Image = Image.FromFile("starzul.png");
                            star3.Image = Image.FromFile("starzul.png");
                            star4.Image = Image.FromFile("starzul.png");
                            star5.Image = Image.FromFile("starzul.png");
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();
        }
        #region Buttons Side Menu
        private void bHome_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            bCadastrarServico.BackColor = Color.Silver;
            bCadastrarServico.ForeColor = Color.White;
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
                MessageBox.Show("A janela de cadastrar serviço já está aberta.");
            else
                form9.Show();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Orcamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(pedidos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRetirarPagamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RetirarPagamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bConfiguracao_Click(object sender, EventArgs e)
        {
            if (bMeusDados.Visible == false)
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.AliceBlue;
                bMeusDados.Visible = true;
                bALterarMeusDados.Visible = true;
                bRedefinirSenha.Visible = true;
            }
            else
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.White;
                bMeusDados.Visible = false;
                bALterarMeusDados.Visible = false;
                bRedefinirSenha.Visible = false;
            }
        }

        private void bMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(MeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bALterarMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(ALterarMeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRedefinirSenha_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RedefinirSenha);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void Servicos()
        {
            Application.Run(new Form6());
        }

        private void Orcamento()
        {
            Application.Run(new Form8());
        }

        private void pedidos()
        {
            Application.Run(new Form4());
        }

        private void RetirarPagamento()
        {
            Application.Run(new Form10());
        }

        private void MeusDados()
        {
            Application.Run(new Form5());
        }

        private void ALterarMeusDados()
        {
            Application.Run(new Form7());
        }

        private void RedefinirSenha()
        {
            Application.Run(new Form11());
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }
        #endregion

        private void panelCentral_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelCadastro_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

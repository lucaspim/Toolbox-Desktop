﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;

namespace Toolbox
{
    public partial class Form9 : Form
    {
        MySqlConnection con;
        Thread nt;
        int idservice, Ndispo = 0, idcategory;

        public Form9()
        {
            InitializeComponent();
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            panelCadastroServico.Location = new Point(this.Size.Width / 2 - panelCadastroServico.Size.Width / 2,40);
            panelCadastroServico.Anchor = AnchorStyles.None;
            panelSugestao.Location = new Point(this.Size.Width / 2 - panelSugestao.Size.Width / 2, 40);
            panelSugestao.Anchor = AnchorStyles.None;

            if (GlobalLogin.sugg == true)
            {
                panelSugestao.Visible = true;
                panelCadastroServico.Visible = false;
            }
            else
            {
                panelSugestao.Visible = false;
                panelCadastroServico.Visible = true;
            }

            try
            {
                con.Open();
                MySqlCommand buscar_categoria = new MySqlCommand("Select descategory from tb_categories;", con);
                MySqlDataReader resultado = buscar_categoria.ExecuteReader();

                while (resultado.Read())
                {
                    comboBoxSugestao.Items.Add(resultado["descategory"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand buscar_servico = new MySqlCommand("Select desservice from tb_services;", con);
                MySqlDataReader resultado = buscar_servico.ExecuteReader();

                while (resultado.Read())
                {
                    comboBoxServico.Items.Add(resultado["desservice"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBoxDispo.SelectedItem == null && comboBoxServico.SelectedItem == null && richTextBoxDesc.Text == null || richTextBoxDesc.Text.Length < 90 || richTextBoxDesc.Text.Length >352)
                MessageBox.Show("Não foi possível cadastrar devido a falta de dados, por favor certifique-se de selecionar o serviço e a disponibilidade como, também, digitar uma descrição de no mínimo 90 caracteres.\nDescrição possui "+ richTextBoxDesc.Text.Length + " caracteres.");
            else
            {
                string dispo = comboBoxDispo.SelectedItem.ToString();
                if (dispo == "Hoje")
                    Ndispo = 1;
                if (dispo == "Em 3 dias")
                    Ndispo = 2;
                if (dispo == "Em 1 semana")
                    Ndispo = 3;
                if (dispo == "Em 1 mês")
                    Ndispo = 4;

                try
                {
                    con.Open();
                    MySqlCommand buscar_servico = new MySqlCommand("Select idservice from tb_services where desservice = '" + comboBoxServico.SelectedItem.ToString() + "';", con);
                    MySqlDataReader resultado = buscar_servico.ExecuteReader();

                    if (resultado.Read())
                    {
                        idservice = int.Parse(resultado["idservice"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                con.Close();

                try
                {
                    con.Open();
                    MySqlCommand inserirservico = new MySqlCommand("insert into tb_servicesprovider(idservice,idprovider,desserviceprovider,rating,availabity) values ('" + idservice + "','" + GlobalLogin.idprestador + "','" + richTextBoxDesc.Text + "','" + 0 + "','" + Ndispo + "');", con);
                    inserirservico.ExecuteNonQuery();
                    MessageBox.Show("Serviço cadastrado");
                    
                }
                catch (Exception ex)
                {
                    if (ex.Message == "Duplicate entry '" + idservice + "-" + GlobalLogin.idprestador + "' for key 'PRIMARY'")
                        MessageBox.Show("Não é possível cadastrar esse serviço devido já estar cadastrado");
                    else
                        MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                con.Close();

                comboBoxServico.SelectedIndex = -1;
                comboBoxDispo.SelectedIndex = -1;
                richTextBoxDesc.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panelCadastroServico.Visible = false;
            panelSugestao.Visible = true;
            GlobalLogin.sugg = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            comboBoxSugestao.SelectedIndex = -1;
            panelSugestao.Visible = false;
            panelCadastroServico.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBoxSugestao.SelectedItem == null && richTextBox1.Text == null )
                MessageBox.Show("Não foi possível sugerir o serviço devido a falta de dados, por favor certifique-se de selecionar uma categoria como, também, digitar uma descrição para o serviço.");
            else
            {
                try
                {
                    con.Open();
                    MySqlCommand buscar_categoria = new MySqlCommand("Select idcategory from tb_categories where descategory = '" + comboBoxSugestao.SelectedItem.ToString() + "';", con);
                    MySqlDataReader resultado = buscar_categoria.ExecuteReader();

                    if (resultado.Read())
                    {
                        idcategory = int.Parse(resultado["idcategory"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                con.Close();

                try
                {
                    con.Open();
                    MySqlCommand Suggestion = new MySqlCommand("insert into tb_servicesuggestions(idcategory,dessuggestion,situation) values ('" + idcategory + "','" + richTextBox1.Text + "',0);", con);
                    Suggestion.ExecuteNonQuery();
                    MessageBox.Show("Sugestão enviada.");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                con.Close();
            }
             
            richTextBox1.Clear();
            comboBoxSugestao.SelectedIndex = -1;
            panelSugestao.Visible = false;
            GlobalLogin.sugg = false;
            panelCadastroServico.Visible = true;
        }

    }
}

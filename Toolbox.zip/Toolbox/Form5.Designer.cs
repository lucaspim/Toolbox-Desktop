﻿namespace Toolbox
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.bRedefinirSenha = new System.Windows.Forms.Button();
            this.bALterarMeusDados = new System.Windows.Forms.Button();
            this.bMeusDados = new System.Windows.Forms.Button();
            this.bConfiguracao = new System.Windows.Forms.Button();
            this.bRetirarPagamento = new System.Windows.Forms.Button();
            this.bpedidos = new System.Windows.Forms.Button();
            this.bOrcamento = new System.Windows.Forms.Button();
            this.bCadastrarServico = new System.Windows.Forms.Button();
            this.bServicos = new System.Windows.Forms.Button();
            this.bHome = new System.Windows.Forms.Button();
            this.bSair = new System.Windows.Forms.Button();
            this.panelBemVindo = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.pictureBoxWelcome = new System.Windows.Forms.PictureBox();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.panelCadastro = new System.Windows.Forms.Panel();
            this.panelCentral = new System.Windows.Forms.Panel();
            this.labelclas = new System.Windows.Forms.Label();
            this.labeldata = new System.Windows.Forms.Label();
            this.star5 = new System.Windows.Forms.Label();
            this.star4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.star3 = new System.Windows.Forms.Label();
            this.star2 = new System.Windows.Forms.Label();
            this.star1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxPais = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBoxMeusDados = new System.Windows.Forms.PictureBox();
            this.textBoxContato = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxEstado = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxBairro = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxCidade = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxNumero = new System.Windows.Forms.TextBox();
            this.textBoxComplemento = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxCEP = new System.Windows.Forms.TextBox();
            this.textBoxRua = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxTelefone = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.textBoxCNPJ = new System.Windows.Forms.TextBox();
            this.panelSideMenu.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelBemVindo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).BeginInit();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.panelCadastro.SuspendLayout();
            this.panelCentral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMeusDados)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.BackColor = System.Drawing.Color.White;
            this.panelSideMenu.Controls.Add(this.panelButtons);
            this.panelSideMenu.Controls.Add(this.bSair);
            this.panelSideMenu.Controls.Add(this.panelBemVindo);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(280, 814);
            this.panelSideMenu.TabIndex = 2;
            // 
            // panelButtons
            // 
            this.panelButtons.BackColor = System.Drawing.Color.White;
            this.panelButtons.Controls.Add(this.bRedefinirSenha);
            this.panelButtons.Controls.Add(this.bALterarMeusDados);
            this.panelButtons.Controls.Add(this.bMeusDados);
            this.panelButtons.Controls.Add(this.bConfiguracao);
            this.panelButtons.Controls.Add(this.bRetirarPagamento);
            this.panelButtons.Controls.Add(this.bpedidos);
            this.panelButtons.Controls.Add(this.bOrcamento);
            this.panelButtons.Controls.Add(this.bCadastrarServico);
            this.panelButtons.Controls.Add(this.bServicos);
            this.panelButtons.Controls.Add(this.bHome);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButtons.Location = new System.Drawing.Point(0, 151);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(280, 634);
            this.panelButtons.TabIndex = 13;
            // 
            // bRedefinirSenha
            // 
            this.bRedefinirSenha.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRedefinirSenha.FlatAppearance.BorderSize = 0;
            this.bRedefinirSenha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRedefinirSenha.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRedefinirSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRedefinirSenha.Image = ((System.Drawing.Image)(resources.GetObject("bRedefinirSenha.Image")));
            this.bRedefinirSenha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRedefinirSenha.Location = new System.Drawing.Point(0, 360);
            this.bRedefinirSenha.Name = "bRedefinirSenha";
            this.bRedefinirSenha.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bRedefinirSenha.Size = new System.Drawing.Size(280, 40);
            this.bRedefinirSenha.TabIndex = 10;
            this.bRedefinirSenha.Text = "  redefinir senha";
            this.bRedefinirSenha.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRedefinirSenha.UseVisualStyleBackColor = true;
            this.bRedefinirSenha.Click += new System.EventHandler(this.bRedefinirSenha_Click);
            // 
            // bALterarMeusDados
            // 
            this.bALterarMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bALterarMeusDados.FlatAppearance.BorderSize = 0;
            this.bALterarMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bALterarMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bALterarMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bALterarMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bALterarMeusDados.Image")));
            this.bALterarMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bALterarMeusDados.Location = new System.Drawing.Point(0, 320);
            this.bALterarMeusDados.Name = "bALterarMeusDados";
            this.bALterarMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bALterarMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bALterarMeusDados.TabIndex = 6;
            this.bALterarMeusDados.Text = "  alterar meus dados";
            this.bALterarMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bALterarMeusDados.UseVisualStyleBackColor = true;
            this.bALterarMeusDados.Click += new System.EventHandler(this.bALterarMeusDados_Click);
            // 
            // bMeusDados
            // 
            this.bMeusDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.bMeusDados.FlatAppearance.BorderSize = 0;
            this.bMeusDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bMeusDados.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bMeusDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bMeusDados.Image = ((System.Drawing.Image)(resources.GetObject("bMeusDados.Image")));
            this.bMeusDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bMeusDados.Location = new System.Drawing.Point(0, 280);
            this.bMeusDados.Name = "bMeusDados";
            this.bMeusDados.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bMeusDados.Size = new System.Drawing.Size(280, 40);
            this.bMeusDados.TabIndex = 9;
            this.bMeusDados.Text = "  meus dados";
            this.bMeusDados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bMeusDados.UseVisualStyleBackColor = true;
            this.bMeusDados.Click += new System.EventHandler(this.bMeusDados_Click);
            // 
            // bConfiguracao
            // 
            this.bConfiguracao.Dock = System.Windows.Forms.DockStyle.Top;
            this.bConfiguracao.FlatAppearance.BorderSize = 0;
            this.bConfiguracao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bConfiguracao.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bConfiguracao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bConfiguracao.Image = ((System.Drawing.Image)(resources.GetObject("bConfiguracao.Image")));
            this.bConfiguracao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bConfiguracao.Location = new System.Drawing.Point(0, 240);
            this.bConfiguracao.Name = "bConfiguracao";
            this.bConfiguracao.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bConfiguracao.Size = new System.Drawing.Size(280, 40);
            this.bConfiguracao.TabIndex = 3;
            this.bConfiguracao.Text = "  configurações";
            this.bConfiguracao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bConfiguracao.UseVisualStyleBackColor = true;
            this.bConfiguracao.Click += new System.EventHandler(this.bConfiguracao_Click);
            // 
            // bRetirarPagamento
            // 
            this.bRetirarPagamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bRetirarPagamento.FlatAppearance.BorderSize = 0;
            this.bRetirarPagamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRetirarPagamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bRetirarPagamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bRetirarPagamento.Image = ((System.Drawing.Image)(resources.GetObject("bRetirarPagamento.Image")));
            this.bRetirarPagamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bRetirarPagamento.Location = new System.Drawing.Point(0, 200);
            this.bRetirarPagamento.Name = "bRetirarPagamento";
            this.bRetirarPagamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bRetirarPagamento.Size = new System.Drawing.Size(280, 40);
            this.bRetirarPagamento.TabIndex = 8;
            this.bRetirarPagamento.Text = "  retirar pagamento";
            this.bRetirarPagamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bRetirarPagamento.UseVisualStyleBackColor = true;
            this.bRetirarPagamento.Click += new System.EventHandler(this.bRetirarPagamento_Click);
            // 
            // bpedidos
            // 
            this.bpedidos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bpedidos.FlatAppearance.BorderSize = 0;
            this.bpedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bpedidos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bpedidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bpedidos.Image = ((System.Drawing.Image)(resources.GetObject("bpedidos.Image")));
            this.bpedidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bpedidos.Location = new System.Drawing.Point(0, 160);
            this.bpedidos.Name = "bpedidos";
            this.bpedidos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bpedidos.Size = new System.Drawing.Size(280, 40);
            this.bpedidos.TabIndex = 5;
            this.bpedidos.Text = "  pedidos";
            this.bpedidos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bpedidos.UseVisualStyleBackColor = true;
            this.bpedidos.Click += new System.EventHandler(this.bpedidos_Click);
            // 
            // bOrcamento
            // 
            this.bOrcamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bOrcamento.FlatAppearance.BorderSize = 0;
            this.bOrcamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOrcamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bOrcamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bOrcamento.Image = ((System.Drawing.Image)(resources.GetObject("bOrcamento.Image")));
            this.bOrcamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bOrcamento.Location = new System.Drawing.Point(0, 120);
            this.bOrcamento.Name = "bOrcamento";
            this.bOrcamento.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bOrcamento.Size = new System.Drawing.Size(280, 40);
            this.bOrcamento.TabIndex = 4;
            this.bOrcamento.Text = "  orçamentos";
            this.bOrcamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bOrcamento.UseVisualStyleBackColor = true;
            this.bOrcamento.Click += new System.EventHandler(this.bOrcamento_Click);
            // 
            // bCadastrarServico
            // 
            this.bCadastrarServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bCadastrarServico.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bCadastrarServico.Image = ((System.Drawing.Image)(resources.GetObject("bCadastrarServico.Image")));
            this.bCadastrarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCadastrarServico.Location = new System.Drawing.Point(0, 80);
            this.bCadastrarServico.Name = "bCadastrarServico";
            this.bCadastrarServico.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bCadastrarServico.Size = new System.Drawing.Size(280, 40);
            this.bCadastrarServico.TabIndex = 2;
            this.bCadastrarServico.Text = "  cadastrar serviço";
            this.bCadastrarServico.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bCadastrarServico.UseVisualStyleBackColor = true;
            this.bCadastrarServico.Click += new System.EventHandler(this.bCadastrarServico_Click);
            // 
            // bServicos
            // 
            this.bServicos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bServicos.FlatAppearance.BorderSize = 0;
            this.bServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bServicos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bServicos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bServicos.Image = ((System.Drawing.Image)(resources.GetObject("bServicos.Image")));
            this.bServicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bServicos.Location = new System.Drawing.Point(0, 40);
            this.bServicos.Name = "bServicos";
            this.bServicos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bServicos.Size = new System.Drawing.Size(280, 40);
            this.bServicos.TabIndex = 7;
            this.bServicos.Text = "  serviços";
            this.bServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bServicos.UseVisualStyleBackColor = true;
            this.bServicos.Click += new System.EventHandler(this.bServicos_Click);
            // 
            // bHome
            // 
            this.bHome.BackColor = System.Drawing.Color.Transparent;
            this.bHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.bHome.FlatAppearance.BorderSize = 0;
            this.bHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bHome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bHome.Image = ((System.Drawing.Image)(resources.GetObject("bHome.Image")));
            this.bHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.Location = new System.Drawing.Point(0, 0);
            this.bHome.Name = "bHome";
            this.bHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bHome.Size = new System.Drawing.Size(280, 40);
            this.bHome.TabIndex = 1;
            this.bHome.Text = "  home";
            this.bHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bHome.UseVisualStyleBackColor = false;
            this.bHome.Click += new System.EventHandler(this.bHome_Click);
            // 
            // bSair
            // 
            this.bSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bSair.Location = new System.Drawing.Point(0, 785);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(280, 29);
            this.bSair.TabIndex = 6;
            this.bSair.Text = "sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bSair.UseVisualStyleBackColor = true;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // panelBemVindo
            // 
            this.panelBemVindo.Controls.Add(this.labelWelcome);
            this.panelBemVindo.Controls.Add(this.pictureBoxWelcome);
            this.panelBemVindo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBemVindo.Location = new System.Drawing.Point(0, 86);
            this.panelBemVindo.Name = "panelBemVindo";
            this.panelBemVindo.Size = new System.Drawing.Size(280, 65);
            this.panelBemVindo.TabIndex = 1;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.labelWelcome.Location = new System.Drawing.Point(59, 24);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(105, 25);
            this.labelWelcome.TabIndex = 1;
            this.labelWelcome.Text = "bem vindo,";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxWelcome
            // 
            this.pictureBoxWelcome.Location = new System.Drawing.Point(21, 15);
            this.pictureBoxWelcome.Name = "pictureBoxWelcome";
            this.pictureBoxWelcome.Size = new System.Drawing.Size(34, 34);
            this.pictureBoxWelcome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxWelcome.TabIndex = 0;
            this.pictureBoxWelcome.TabStop = false;
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelLogo.Controls.Add(this.pictureBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.panelLogo.Size = new System.Drawing.Size(280, 86);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogo.ErrorImage = null;
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.InitialImage = null;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 5);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(280, 86);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // panelCadastro
            // 
            this.panelCadastro.BackColor = System.Drawing.Color.White;
            this.panelCadastro.Controls.Add(this.panelCentral);
            this.panelCadastro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCadastro.Location = new System.Drawing.Point(280, 0);
            this.panelCadastro.Name = "panelCadastro";
            this.panelCadastro.Size = new System.Drawing.Size(984, 814);
            this.panelCadastro.TabIndex = 37;
            this.panelCadastro.Paint += new System.Windows.Forms.PaintEventHandler(this.panelCadastro_Paint);
            // 
            // panelCentral
            // 
            this.panelCentral.Controls.Add(this.labelclas);
            this.panelCentral.Controls.Add(this.labeldata);
            this.panelCentral.Controls.Add(this.star5);
            this.panelCentral.Controls.Add(this.star4);
            this.panelCentral.Controls.Add(this.label13);
            this.panelCentral.Controls.Add(this.star3);
            this.panelCentral.Controls.Add(this.star2);
            this.panelCentral.Controls.Add(this.star1);
            this.panelCentral.Controls.Add(this.pictureBox2);
            this.panelCentral.Controls.Add(this.label16);
            this.panelCentral.Controls.Add(this.textBoxPais);
            this.panelCentral.Controls.Add(this.label11);
            this.panelCentral.Controls.Add(this.label14);
            this.panelCentral.Controls.Add(this.pictureBoxMeusDados);
            this.panelCentral.Controls.Add(this.textBoxContato);
            this.panelCentral.Controls.Add(this.label5);
            this.panelCentral.Controls.Add(this.textBoxEstado);
            this.panelCentral.Controls.Add(this.label6);
            this.panelCentral.Controls.Add(this.textBoxBairro);
            this.panelCentral.Controls.Add(this.label12);
            this.panelCentral.Controls.Add(this.textBoxCidade);
            this.panelCentral.Controls.Add(this.label9);
            this.panelCentral.Controls.Add(this.label10);
            this.panelCentral.Controls.Add(this.textBoxNumero);
            this.panelCentral.Controls.Add(this.textBoxComplemento);
            this.panelCentral.Controls.Add(this.label7);
            this.panelCentral.Controls.Add(this.label8);
            this.panelCentral.Controls.Add(this.textBoxCEP);
            this.panelCentral.Controls.Add(this.textBoxRua);
            this.panelCentral.Controls.Add(this.label3);
            this.panelCentral.Controls.Add(this.label4);
            this.panelCentral.Controls.Add(this.textBoxTelefone);
            this.panelCentral.Controls.Add(this.textBoxNome);
            this.panelCentral.Controls.Add(this.label2);
            this.panelCentral.Controls.Add(this.label1);
            this.panelCentral.Controls.Add(this.textBoxUsername);
            this.panelCentral.Controls.Add(this.textBoxCNPJ);
            this.panelCentral.Location = new System.Drawing.Point(52, 46);
            this.panelCentral.Name = "panelCentral";
            this.panelCentral.Size = new System.Drawing.Size(850, 756);
            this.panelCentral.TabIndex = 66;
            this.panelCentral.Paint += new System.Windows.Forms.PaintEventHandler(this.panelCentral_Paint);
            // 
            // labelclas
            // 
            this.labelclas.AllowDrop = true;
            this.labelclas.AutoSize = true;
            this.labelclas.BackColor = System.Drawing.Color.Transparent;
            this.labelclas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelclas.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelclas.Location = new System.Drawing.Point(380, 576);
            this.labelclas.Name = "labelclas";
            this.labelclas.Size = new System.Drawing.Size(95, 21);
            this.labelclas.TabIndex = 135;
            this.labelclas.Text = "classificação";
            // 
            // labeldata
            // 
            this.labeldata.AllowDrop = true;
            this.labeldata.AutoSize = true;
            this.labeldata.BackColor = System.Drawing.Color.Transparent;
            this.labeldata.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labeldata.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labeldata.Location = new System.Drawing.Point(315, 630);
            this.labeldata.Name = "labeldata";
            this.labeldata.Size = new System.Drawing.Size(163, 25);
            this.labeldata.TabIndex = 134;
            this.labeldata.Text = "Desde 29/06/2021";
            // 
            // star5
            // 
            this.star5.AllowDrop = true;
            this.star5.AutoSize = true;
            this.star5.BackColor = System.Drawing.Color.Transparent;
            this.star5.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.star5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.star5.Image = ((System.Drawing.Image)(resources.GetObject("star5.Image")));
            this.star5.Location = new System.Drawing.Point(451, 699);
            this.star5.Name = "star5";
            this.star5.Size = new System.Drawing.Size(27, 25);
            this.star5.TabIndex = 133;
            this.star5.Text = "   ";
            // 
            // star4
            // 
            this.star4.AllowDrop = true;
            this.star4.AutoSize = true;
            this.star4.BackColor = System.Drawing.Color.Transparent;
            this.star4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.star4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.star4.Image = ((System.Drawing.Image)(resources.GetObject("star4.Image")));
            this.star4.Location = new System.Drawing.Point(418, 699);
            this.star4.Name = "star4";
            this.star4.Size = new System.Drawing.Size(27, 25);
            this.star4.TabIndex = 132;
            this.star4.Text = "   ";
            // 
            // label13
            // 
            this.label13.AllowDrop = true;
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(325, 672);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(150, 25);
            this.label13.TabIndex = 128;
            this.label13.Text = "Minha avaliação";
            // 
            // star3
            // 
            this.star3.AllowDrop = true;
            this.star3.AutoSize = true;
            this.star3.BackColor = System.Drawing.Color.Transparent;
            this.star3.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.star3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.star3.Image = ((System.Drawing.Image)(resources.GetObject("star3.Image")));
            this.star3.Location = new System.Drawing.Point(385, 699);
            this.star3.Name = "star3";
            this.star3.Size = new System.Drawing.Size(27, 25);
            this.star3.TabIndex = 131;
            this.star3.Text = "   ";
            // 
            // star2
            // 
            this.star2.AllowDrop = true;
            this.star2.AutoSize = true;
            this.star2.BackColor = System.Drawing.Color.Transparent;
            this.star2.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.star2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.star2.Image = ((System.Drawing.Image)(resources.GetObject("star2.Image")));
            this.star2.Location = new System.Drawing.Point(352, 699);
            this.star2.Name = "star2";
            this.star2.Size = new System.Drawing.Size(27, 25);
            this.star2.TabIndex = 130;
            this.star2.Text = "   ";
            // 
            // star1
            // 
            this.star1.AllowDrop = true;
            this.star1.AutoSize = true;
            this.star1.BackColor = System.Drawing.Color.Transparent;
            this.star1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.star1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.star1.Image = ((System.Drawing.Image)(resources.GetObject("star1.Image")));
            this.star1.Location = new System.Drawing.Point(319, 699);
            this.star1.Name = "star1";
            this.star1.Size = new System.Drawing.Size(27, 25);
            this.star1.TabIndex = 129;
            this.star1.Text = "   ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Location = new System.Drawing.Point(326, 565);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(47, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 127;
            this.pictureBox2.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label16.Location = new System.Drawing.Point(102, 485);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 25);
            this.label16.TabIndex = 126;
            this.label16.Text = "país";
            // 
            // textBoxPais
            // 
            this.textBoxPais.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxPais.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxPais.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxPais.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxPais.Location = new System.Drawing.Point(107, 513);
            this.textBoxPais.Name = "textBoxPais";
            this.textBoxPais.ReadOnly = true;
            this.textBoxPais.Size = new System.Drawing.Size(86, 32);
            this.textBoxPais.TabIndex = 125;
            this.textBoxPais.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label11.Location = new System.Drawing.Point(21, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(171, 37);
            this.label11.TabIndex = 60;
            this.label11.Text = "Meus dados";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label14.Location = new System.Drawing.Point(437, 231);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(170, 25);
            this.label14.TabIndex = 124;
            this.label14.Text = "email para contato";
            // 
            // pictureBoxMeusDados
            // 
            this.pictureBoxMeusDados.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBoxMeusDados.Location = new System.Drawing.Point(348, 15);
            this.pictureBoxMeusDados.Name = "pictureBoxMeusDados";
            this.pictureBoxMeusDados.Size = new System.Drawing.Size(120, 120);
            this.pictureBoxMeusDados.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxMeusDados.TabIndex = 59;
            this.pictureBoxMeusDados.TabStop = false;
            // 
            // textBoxContato
            // 
            this.textBoxContato.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxContato.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxContato.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxContato.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxContato.Location = new System.Drawing.Point(442, 259);
            this.textBoxContato.Name = "textBoxContato";
            this.textBoxContato.ReadOnly = true;
            this.textBoxContato.Size = new System.Drawing.Size(378, 32);
            this.textBoxContato.TabIndex = 123;
            this.textBoxContato.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label5.Location = new System.Drawing.Point(23, 485);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 25);
            this.label5.TabIndex = 120;
            this.label5.Text = "estado";
            // 
            // textBoxEstado
            // 
            this.textBoxEstado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEstado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxEstado.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxEstado.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxEstado.Location = new System.Drawing.Point(28, 513);
            this.textBoxEstado.Name = "textBoxEstado";
            this.textBoxEstado.ReadOnly = true;
            this.textBoxEstado.Size = new System.Drawing.Size(73, 32);
            this.textBoxEstado.TabIndex = 119;
            this.textBoxEstado.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label6.Location = new System.Drawing.Point(27, 403);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 25);
            this.label6.TabIndex = 118;
            this.label6.Text = "bairro";
            // 
            // textBoxBairro
            // 
            this.textBoxBairro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxBairro.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxBairro.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxBairro.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxBairro.Location = new System.Drawing.Point(28, 431);
            this.textBoxBairro.Name = "textBoxBairro";
            this.textBoxBairro.ReadOnly = true;
            this.textBoxBairro.Size = new System.Drawing.Size(365, 32);
            this.textBoxBairro.TabIndex = 117;
            this.textBoxBairro.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label12.Location = new System.Drawing.Point(497, 403);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 25);
            this.label12.TabIndex = 116;
            this.label12.Text = "cidade";
            // 
            // textBoxCidade
            // 
            this.textBoxCidade.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCidade.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCidade.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxCidade.Location = new System.Drawing.Point(502, 431);
            this.textBoxCidade.Name = "textBoxCidade";
            this.textBoxCidade.ReadOnly = true;
            this.textBoxCidade.Size = new System.Drawing.Size(318, 32);
            this.textBoxCidade.TabIndex = 115;
            this.textBoxCidade.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label9.Location = new System.Drawing.Point(394, 403);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 25);
            this.label9.TabIndex = 114;
            this.label9.Text = "número";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label10.Location = new System.Drawing.Point(194, 485);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(218, 25);
            this.label10.TabIndex = 113;
            this.label10.Text = "complemento (opcional)";
            // 
            // textBoxNumero
            // 
            this.textBoxNumero.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxNumero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxNumero.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxNumero.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxNumero.Location = new System.Drawing.Point(399, 431);
            this.textBoxNumero.MaxLength = 5;
            this.textBoxNumero.Name = "textBoxNumero";
            this.textBoxNumero.ReadOnly = true;
            this.textBoxNumero.Size = new System.Drawing.Size(97, 32);
            this.textBoxNumero.TabIndex = 112;
            this.textBoxNumero.TabStop = false;
            // 
            // textBoxComplemento
            // 
            this.textBoxComplemento.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxComplemento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxComplemento.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxComplemento.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxComplemento.Location = new System.Drawing.Point(199, 513);
            this.textBoxComplemento.Name = "textBoxComplemento";
            this.textBoxComplemento.ReadOnly = true;
            this.textBoxComplemento.Size = new System.Drawing.Size(621, 32);
            this.textBoxComplemento.TabIndex = 111;
            this.textBoxComplemento.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label7.Location = new System.Drawing.Point(23, 328);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 25);
            this.label7.TabIndex = 110;
            this.label7.Text = "CEP";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label8.Location = new System.Drawing.Point(295, 328);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 25);
            this.label8.TabIndex = 109;
            this.label8.Text = "endereço";
            // 
            // textBoxCEP
            // 
            this.textBoxCEP.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCEP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCEP.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCEP.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxCEP.Location = new System.Drawing.Point(28, 356);
            this.textBoxCEP.MaxLength = 8;
            this.textBoxCEP.Name = "textBoxCEP";
            this.textBoxCEP.ReadOnly = true;
            this.textBoxCEP.Size = new System.Drawing.Size(266, 32);
            this.textBoxCEP.TabIndex = 108;
            this.textBoxCEP.TabStop = false;
            // 
            // textBoxRua
            // 
            this.textBoxRua.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxRua.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxRua.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxRua.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxRua.Location = new System.Drawing.Point(300, 356);
            this.textBoxRua.Name = "textBoxRua";
            this.textBoxRua.ReadOnly = true;
            this.textBoxRua.Size = new System.Drawing.Size(520, 32);
            this.textBoxRua.TabIndex = 107;
            this.textBoxRua.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label3.Location = new System.Drawing.Point(23, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 25);
            this.label3.TabIndex = 106;
            this.label3.Text = "telefone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label4.Location = new System.Drawing.Point(23, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 25);
            this.label4.TabIndex = 105;
            this.label4.Text = "nome";
            // 
            // textBoxTelefone
            // 
            this.textBoxTelefone.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxTelefone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTelefone.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxTelefone.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxTelefone.Location = new System.Drawing.Point(28, 259);
            this.textBoxTelefone.MaxLength = 15;
            this.textBoxTelefone.Name = "textBoxTelefone";
            this.textBoxTelefone.ReadOnly = true;
            this.textBoxTelefone.Size = new System.Drawing.Size(201, 32);
            this.textBoxTelefone.TabIndex = 104;
            this.textBoxTelefone.TabStop = false;
            // 
            // textBoxNome
            // 
            this.textBoxNome.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxNome.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxNome.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxNome.Location = new System.Drawing.Point(28, 184);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.ReadOnly = true;
            this.textBoxNome.Size = new System.Drawing.Size(382, 32);
            this.textBoxNome.TabIndex = 99;
            this.textBoxNome.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label2.Location = new System.Drawing.Point(409, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 25);
            this.label2.TabIndex = 103;
            this.label2.Text = "email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label1.Location = new System.Drawing.Point(230, 231);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 25);
            this.label1.TabIndex = 102;
            this.label1.Text = "CNPJ";
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxUsername.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxUsername.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxUsername.Location = new System.Drawing.Point(414, 184);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.ReadOnly = true;
            this.textBoxUsername.Size = new System.Drawing.Size(406, 32);
            this.textBoxUsername.TabIndex = 101;
            this.textBoxUsername.TabStop = false;
            // 
            // textBoxCNPJ
            // 
            this.textBoxCNPJ.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCNPJ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCNPJ.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.textBoxCNPJ.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxCNPJ.Location = new System.Drawing.Point(235, 259);
            this.textBoxCNPJ.MaxLength = 14;
            this.textBoxCNPJ.Name = "textBoxCNPJ";
            this.textBoxCNPJ.ReadOnly = true;
            this.textBoxCNPJ.Size = new System.Drawing.Size(201, 32);
            this.textBoxCNPJ.TabIndex = 100;
            this.textBoxCNPJ.TabStop = false;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(247)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(1264, 814);
            this.Controls.Add(this.panelCadastro);
            this.Controls.Add(this.panelSideMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Meus Dados";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelButtons.ResumeLayout(false);
            this.panelBemVindo.ResumeLayout(false);
            this.panelBemVindo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWelcome)).EndInit();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.panelCadastro.ResumeLayout(false);
            this.panelCentral.ResumeLayout(false);
            this.panelCentral.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMeusDados)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Panel panelBemVindo;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.PictureBox pictureBoxWelcome;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Panel panelCadastro;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBoxMeusDados;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button bRedefinirSenha;
        private System.Windows.Forms.Button bALterarMeusDados;
        private System.Windows.Forms.Button bMeusDados;
        private System.Windows.Forms.Button bConfiguracao;
        private System.Windows.Forms.Button bRetirarPagamento;
        private System.Windows.Forms.Button bpedidos;
        private System.Windows.Forms.Button bOrcamento;
        private System.Windows.Forms.Button bCadastrarServico;
        private System.Windows.Forms.Button bServicos;
        private System.Windows.Forms.Button bHome;
        private System.Windows.Forms.Panel panelCentral;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxPais;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxContato;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxEstado;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxBairro;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxCidade;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxNumero;
        private System.Windows.Forms.TextBox textBoxComplemento;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxCEP;
        private System.Windows.Forms.TextBox textBoxRua;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxTelefone;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.TextBox textBoxCNPJ;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label star5;
        private System.Windows.Forms.Label star4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label star3;
        private System.Windows.Forms.Label star2;
        private System.Windows.Forms.Label star1;
        private System.Windows.Forms.Label labeldata;
        private System.Windows.Forms.Label labelclas;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using MySql.Data.MySqlClient;

namespace Toolbox
{
    public partial class Form11 : Form
    {
        MySqlConnection con;
        Thread nt;
        int f = 0;
        public Form11()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            bRedefinirSenha.BackColor = Color.FromArgb(40, 131, 238);
            bRedefinirSenha.ForeColor = Color.White;
            bMeusDados.Visible = true;
            bALterarMeusDados.Visible = true;
            bRedefinirSenha.Visible = true;

            try
            {
                con.Open();
                MySqlCommand logado = new MySqlCommand("select imguserprovider,desprovider from tb_userprovider inner join tb_providers where tb_userprovider.idprovider ='" + GlobalLogin.idprestador + "' and tb_providers.idprovider = '" + GlobalLogin.idprestador + "';", con);
                MySqlDataReader resultado = logado.ExecuteReader();

                if (resultado.Read())
                {
                    labelWelcome.Text = "bem vindo, " + resultado["desprovider"].ToString();

                    try
                    {
                        string imagem = Convert.ToString(DateTime.Now.ToFileTime());
                        byte[] bimage = (byte[])resultado["imguserprovider"];
                        System.IO.FileStream fs = new FileStream(imagem, FileMode.CreateNew, FileAccess.Write);
                        fs.Write(bimage, 0, bimage.Length - 1);
                        fs.Close();
                        pictureBoxWelcome.Image = Image.FromFile(imagem);
                        resultado.Close();
                    }
                    catch
                    {
                        pictureBoxWelcome.Image = Image.FromFile("semFoto.png"); //pasta debug
                    }
                }
                else
                    MessageBox.Show("Erro.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();
        }

        #region Buttons Side Menu
        private void bHome_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            bCadastrarServico.BackColor = Color.Silver;
            bCadastrarServico.ForeColor = Color.White;
            Form9 form9 = new Form9();

            if (Application.OpenForms["Form9"] != null)
                MessageBox.Show("A janela de cadastrar serviço já está aberta.");
            else
                form9.Show();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Orcamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(pedidos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRetirarPagamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RetirarPagamento);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bConfiguracao_Click(object sender, EventArgs e)
        {
            if (bMeusDados.Visible == false)
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.AliceBlue;
                bMeusDados.Visible = true;
                bALterarMeusDados.Visible = true;
                bRedefinirSenha.Visible = true;
            }
            else
            {
                this.bConfiguracao.BackColor = System.Drawing.Color.White;
                bMeusDados.Visible = false;
                bALterarMeusDados.Visible = false;
                bRedefinirSenha.Visible = false;
            }
        }

        private void bMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(MeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bALterarMeusDados_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(ALterarMeusDados);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bRedefinirSenha_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(RedefinirSenha);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Home()
        {
            Application.Run(new Form3());
        }

        private void Servicos()
        {
            Application.Run(new Form6());
        }

        private void Orcamento()
        {
            Application.Run(new Form8());
        }

        private void pedidos()
        {
            Application.Run(new Form4());
        }

        private void RetirarPagamento()
        {
            Application.Run(new Form10());
        }

        private void MeusDados()
        {
            Application.Run(new Form5());
        }

        private void ALterarMeusDados()
        {
            Application.Run(new Form7());
        }

        private void RedefinirSenha()
        {
            Application.Run(new Form11());
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            if (f==0)
            {
                textBoxSA.PasswordChar = char.Parse("\0");
                textBoxSN.PasswordChar = char.Parse("\0");
                textBoxSNR.PasswordChar = char.Parse("\0");
                f = 1;
                button1.BackColor = Color.Gainsboro;
            }
            else
            {
                textBoxSA.PasswordChar = char.Parse("•");
                textBoxSN.PasswordChar = char.Parse("•");
                textBoxSNR.PasswordChar = char.Parse("•");
                f = 0;
                button1.BackColor = Color.Transparent;
            }
        }

        private void bAltsen_Click(object sender, EventArgs e)
        {
            string password = textBoxSN.Text;
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(password);
            bool verify = BCrypt.Net.BCrypt.Verify(password, passwordHash);

            if (textBoxSN.Text == textBoxSNR.Text)
            {
                if (verify == true)
                    try
                    {
                        con.Open();
                        MySqlCommand update_tb_usersproviderspasswordsrecoveries = new MySqlCommand("insert into tb_usersproviderspasswordsrecoveries (iduserprovider,dtrecovery) values ('" + GlobalLogin.iduserprestador + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "');", con);
                        update_tb_usersproviderspasswordsrecoveries.ExecuteNonQuery();
                        con.Close();
                        verify = true;
                    }
                    catch (Exception ex)
                    {
                        verify = false;
                        MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    con.Close();

                if (verify == true)
                {
                    try
                    {

                        con.Open();
                        MySqlCommand update_Provider = new MySqlCommand("update tb_userprovider set despassword = '" + passwordHash + "' where idprovider = '" + GlobalLogin.idprestador + "';", con);
                        update_Provider.ExecuteNonQuery();
                        MessageBox.Show("Senha redefinida com sucesso!", "Sistema");
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    con.Close();
                }
                    
            }
            else
                MessageBox.Show("Erro!\nNova senha e repita nova senha são diferentes");
        }
    }
}

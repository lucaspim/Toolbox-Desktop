﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using Correios;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Toolbox
{
    public partial class Form2 : Form
    {
        MySqlConnection con;
        Thread nt;
        int cepFlag = 0,f=0;
        bool verifyFlags = false;
        CorreiosApi correiosApi = new CorreiosApi();

        public Form2()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            panelCadastro.Location = new Point(this.Size.Width / 2 - panelCadastro.Size.Width / 2, this.Size.Height / 2 - panelCadastro.Size.Height / 2);
            panelCadastro.Anchor = AnchorStyles.None;
        }

        private void bCadastrar_Click(object sender, EventArgs e)
        {
            if ((textBoxBairro.Text == "") || (textBoxCidade.Text == "") || (textBoxNome.Text == "") || (textBoxEstado.Text == "") || (textBoxCNPJ.Text == "") || (textBoxTelefone.Text == "") || (textBoxUsername.Text == "") || (textBoxSenha.Text == "") || (textBoxCEP.Text == "") || (textBoxRua.Text == "") || (textBoxNumero.Text == "") || (textBoxContato.Text == "") || (textBoxPais.Text == ""))
            {
                MessageBox.Show("Algum dado está faltanto", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                verifyFlags = false;
            }
            else
                verifyFlags = true;

            if (textBoxCNPJ.Text.Length == 14)
                if (IsCnpj(textBoxCNPJ.Text) == true)
                    verifyFlags = true;
                else
                {
                    verifyFlags = false;
                    textBoxCNPJ.Focus();
                    MessageBox.Show("CNPJ inválido, por favor inserir um válido");
                }

            if (pictureBoxCadastro.Image == null)
                pictureBoxCadastro.Image = Image.FromFile("semFoto.png");

            if (IsValidEmail(textBoxUsername.Text) == true)
                verifyFlags = true;
            else
            {
                verifyFlags = false;
                MessageBox.Show("Email incorreto, por favor verifica-se de digitar o endereço de email corretamente");
            }

            if (IsValidEmail(textBoxContato.Text) == true)
                verifyFlags = true;
            else
            {
                verifyFlags = false;
                MessageBox.Show("Email de contato incorreto, por favor verifica-se de digitar o endereço de email corretamente");
            }

            if (IsDigitsOnly(textBoxNumero.Text) == true)
                verifyFlags = true;
            else
            {
                verifyFlags = false;
                MessageBox.Show("Número de endereço incorreto, por favor certifique-se de digitar números somente");
            }

            if (IsDigitsOnly(textBoxTelefone.Text) == true)
                verifyFlags = true;
            else
            {
                verifyFlags = false;
                MessageBox.Show("Número de telefone incorreto, por favor certifique-se de digitar números somente");
            }

            if (verifyFlags==true && cepFlag==1)
            {
                if (checkBoxTSPP.Checked == true)
                {
                    try
                    {
                        string password = textBoxSenha.Text;
                        string passwordHash = BCrypt.Net.BCrypt.HashPassword(password);
                        bool verify = BCrypt.Net.BCrypt.Verify(password, passwordHash);

                        if (verify == true)
                        {
                            con.Open();
                            MySqlCommand inserirempresa = new MySqlCommand("call registering_UserProvider('" + int.Parse(textBoxCEP.Text) + "','" + textBoxRua.Text + "','" + int.Parse(textBoxNumero.Text) + "','" + textBoxCidade.Text + "','" + textBoxEstado.Text + "','" + "Brasil" + "', '" + textBoxBairro.Text + "', '" + textBoxComplemento.Text + "', '" + textBoxCNPJ.Text + "', '" + textBoxNome.Text + "', '" + int.Parse(textBoxTelefone.Text) + "', '" + textBoxUsername.Text + "', '" + passwordHash + "', '" + textBoxContato.Text + "', '" + "@foto" + "');", con);
                            
                            inserirempresa.Parameters.AddWithValue("foto", ConverterFotoParaArray());
                            inserirempresa.ExecuteNonQuery();

                            MessageBox.Show("Prestador, "+textBoxNome.Text+" cadastrado com sucesso!!");

                            textBoxBairro.Clear();
                            textBoxCEP.Clear();
                            textBoxCidade.Clear();
                            textBoxCNPJ.Clear();
                            textBoxComplemento.Clear();
                            textBoxEstado.Clear();
                            textBoxNome.Clear();
                            textBoxNumero.Clear();
                            textBoxRua.Clear();
                            textBoxSenha.Clear();
                            textBoxTelefone.Clear();
                            textBoxUsername.Clear();
                            textBoxPais.Clear();
                            textBoxContato.Clear();
                            pictureBoxCadastro.Image = null;
                            con.Close();
                            this.Close();
                            nt = new Thread(novoForm1);
                            nt.SetApartmentState(ApartmentState.STA);
                            nt.Start();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha no cadastro\nErro: " + ex.Message + "\n" + ex.ToString());
                    }
                }
                else
                    MessageBox.Show("Por favor leia e aceite os Termos de Serviço e Política de Privacidade");
            }
        }

        private byte[] ConverterFotoParaArray()
        {
            using (var stream = new System.IO.MemoryStream())
            {
                pictureBoxCadastro.Image.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
                stream.Seek(0, System.IO.SeekOrigin.Begin);
                byte[] bArray = new byte[stream.Length];
                stream.Read(bArray, 0, System.Convert.ToInt32(stream.Length));
                return bArray;
            }
        }

        private void bVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(novoForm1);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void novoForm1()
        {
            Application.Run(new Form1());
        }

        private void bEscolherFoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Title = "Abrir Foto";
            dialog.Filter = "Images types (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg" + "|All files (*.*)|*.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pictureBoxCadastro.Image = new Bitmap(dialog.OpenFile());

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Não foi possivel carregar a foto: " + ex.Message);
                }
            }
            dialog.Dispose();
        }

        private void textBoxNome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxCNPJ.Focus();
            }
        }

        private void textBoxCNPJ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxTelefone.Focus();
            }
        }

        private void textBoxTelefone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxContato.Focus();
            }
        }

        private void textBoxUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxSenha.Focus();
            }
        }

        private void textBoxSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxCEP.Focus();
            }
        }

        private void textBoxRua_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxBairro.Focus();
            }
        }

        private void textBoxCidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxRua.Focus();
            }
        }

        private void textBoxCEP_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (string.IsNullOrEmpty(textBoxCEP.Text))
                {
                    MessageBox.Show("O campo de CEP está vazio", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    try
                    {
                        var retorno = correiosApi.consultaCEP(textBoxCEP.Text);
                        if (retorno is null)
                        {
                            cepFlag = 0;
                            MessageBox.Show("CEP não encontrado", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        textBoxBairro.Text = retorno.bairro;
                        textBoxCidade.Text = retorno.cidade;
                        textBoxEstado.Text = retorno.uf;
                        textBoxRua.Text = retorno.end;
                        textBoxPais.Text = "Brasil";
                        textBoxComplemento.Text = retorno.complemento;
                        cepFlag = 1;
                    }
                    catch (System.ServiceModel.FaultException)
                    {
                        cepFlag = 0;
                        MessageBox.Show("CEP invalido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                textBoxNumero.Focus();
            }
        }

        private void textBoxNumero_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxComplemento.Focus();
            }
        }

        private void textBoxBairro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxPais.Focus();
            }
        }

        private void textBoxEstado_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxComplemento.Focus();
            }
        }

        private void textBoxComplemento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bEscolherFoto_Click( sender, e);
            }
        }

        private void textBoxCEP_TextChanged(object sender, EventArgs e)
        {
            if (textBoxCEP.Text.Length == 8)
            {
                if (string.IsNullOrEmpty(textBoxCEP.Text))
                {
                    MessageBox.Show("O campo de CEP está vazio", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    
                    try
                    {
                        var retorno = correiosApi.consultaCEP(textBoxCEP.Text);
                        if (retorno is null)
                        {
                            cepFlag = 0;
                            MessageBox.Show("CEP não encontrado", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        textBoxBairro.Text = retorno.bairro;
                        textBoxCidade.Text = retorno.cidade;
                        textBoxEstado.Text = retorno.uf;
                        textBoxRua.Text = retorno.end;
                        textBoxPais.Text = "Brasil";
                        textBoxComplemento.Text = retorno.complemento;
                        cepFlag = 1;
                    }
                    catch (System.ServiceModel.FaultException)
                    {
                        cepFlag = 0;
                        MessageBox.Show("CEP invalido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void textBoxContato_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxUsername.Focus();
            }
        }

        private void textBoxPais_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxEstado.Focus();
            }
        }

        private void textBoxCNPJ_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (f == 0)
            {
                textBoxSenha.PasswordChar = char.Parse("\0");
                f = 1;
                button1.BackColor = Color.Gainsboro;
            }
            else
            {
                textBoxSenha.PasswordChar = char.Parse("•");
                f = 0;
                button1.BackColor = Color.Transparent;
            }
        }

        public static bool IsCnpj(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int soma;
            int resto;
            string digito;
            string tempCnpj;
            cnpj = cnpj.Trim();
            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");
            if (cnpj.Length != 14)
                return false;
            tempCnpj = cnpj.Substring(0, 12);
            soma = 0;
            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCnpj = tempCnpj + digito;
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            return cnpj.EndsWith(digito);
        }

        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));
                string DomainMapper(Match match)
                {
                    var idn = new IdnMapping();

                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                return false;
            }
            catch (ArgumentException e)
            {
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }
            return true;
        }
    }
}

namespace Correios
{
    public interface ICorreiosApi :
        ICorreiosApiAsync,
        ICorreiosApiSync
    {
    }
}